/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Message {
  id: string;
  role: "user" | "model";
  content: string;
  timestamp: string;
  image?: string | null;
}

export interface Conversation {
  id: string;
  title: string;
  pin: boolean;
  folder: string;
  messages: Message[];
  createdAt: string;
}

export interface Memory {
  id: string;
  content: string;
  category: string;
  pinned: boolean;
  date: string;
}

export interface Task {
  id: string;
  name: string;
  status: "running" | "completed" | "failed";
  progress: number;
  logs: string[];
  type: string;
  priority?: "low" | "medium" | "high" | "critical";
  deadline?: string; // ISO string representing deadline timestamp
  category?: string; // e.g. Work, Personal, Maintenance
  timestamp: string;
}

export interface FileRecord {
  id: string;
  name: string;
  size: number;
  type: string;
  url: string;
  timestamp: string;
}

export interface SystemMetrics {
  cpu: number;
  ram: number;
  gpu: number;
  battery: number;
  networkSpeed: string;
  temperature: string;
}

export interface Subsystems {
  hologrid: string;
  arcCore: string;
  mainframe: string;
  sentinel: string;
}

export interface Diagnostics {
  integrity: string;
  subsystems: Subsystems;
}

export interface SystemStatus {
  status: string;
  activeKey: boolean;
  uptime: number;
  serverMetrics: SystemMetrics;
  voiceActive: boolean;
  diagnostics: Diagnostics;
  activeTasksCount: number;
}

export interface AppSettings {
  geminiApiKey?: string;
  appearance: {
    theme: "cyberpunk" | "nebula" | "omega-classic" | "stealth";
    mode?: "dark" | "light" | "system";
    glow: boolean;
    soundEnabled: boolean;
    powerSaveMode?: boolean;
  };
  ai: {
    model: string;
    temperature: number;
    voiceName: "Zephyr" | "Kore" | "Puck" | "Charon" | "Fenrir";
    speechRate?: number;
  };
  security: {
    protocolLevel: string;
  };
  systemControl?: {
    enabled: boolean;
    osType: "android" | "windows" | "both";
    openAppAction: boolean;
    readNotifications: boolean;
    autoTypeWhatsapp: boolean;
    clapSensitivity: number;
    wakeTriggers: {
      oral: boolean;
      write: boolean;
      clap: boolean;
      nameWake: boolean;
    };
  };
}

export interface Toast {
  id: string;
  message: string;
  type: "success" | "error" | "info" | "warning";
  duration?: number;
}

export interface RecentActivity {
  id: string;
  type: "task_started" | "diagnostics_run" | "webcam_accessed" | "system_event" | "file_action";
  event: string;
  timestamp: string;
  details?: string;
}

export interface ForecastItem {
  time: string;
  temperature: string;
  conditions: string;
  iconType: "sunny" | "cloudy" | "rainy" | "snowy" | "stormy" | "windy";
}

export interface WeatherData {
  location: string;
  temperature: string;
  conditions: string;
  humidity: string;
  wind: string;
  uvIndex?: string;
  details: string;
  iconType: "sunny" | "cloudy" | "rainy" | "snowy" | "stormy" | "windy";
  simulated?: boolean;
  forecast?: ForecastItem[];
}

