/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { create } from "zustand";
import { api } from "../services/api";
import { firestoreService } from "../services/firestoreService";
import { classifyRequest, AgentCategory } from "../utils/agentClassifier";
import { 
  Conversation, 
  Memory, 
  Task, 
  FileRecord, 
  SystemStatus, 
  AppSettings,
  Message,
  Toast,
  RecentActivity
} from "../types";

interface JarvisState {
  // Conversational state
  conversations: Conversation[];
  activeConversationId: string | null;
  chatLoading: boolean;
  chatError: string | null;

  // Memories state
  memories: Memory[];
  memoriesLoading: boolean;

  // Tasks state
  tasks: Task[];
  tasksLoading: boolean;

  // Files state
  files: FileRecord[];
  filesLoading: boolean;

  // System State & Metrics
  systemStatus: SystemStatus | null;
  metricsHistory: { cpu: number[]; ram: number[]; gpu: number[] };
  systemLoading: boolean;
  diagnosticsReport: string | null;
  diagnosticsLoading: boolean;

  // App Settings
  settings: AppSettings | null;

  // Voice Interaction State
  isListening: boolean;
  isSpeaking: boolean;
  waveformMode: "idle" | "listening" | "speaking" | "thinking";
  micPermissionGranted: boolean;
  voiceCommandsHistory: string[];

  // Vision state
  capturedImage: string | null;
  visionAnalysis: string | null;
  visionLoading: boolean;

  // Global UI State
  activeTab: "chat" | "memory" | "tasks" | "files" | "settings" | "vision" | "companion";
  isFullScreenChat: boolean;
  tabSyncLoading: boolean;

  // User session
  currentUser: any | null;

  // Battery status
  batteryLevel: number | null;
  batteryCharging: boolean;
  batterySupported: boolean;

  // Actions
  setCurrentUser: (user: any | null) => void;
  setBatteryInfo: (level: number | null, charging: boolean, supported: boolean) => void;
  setTab: (tab: "chat" | "memory" | "tasks" | "files" | "settings" | "vision" | "companion") => void;
  setFullScreenChat: (enabled: boolean) => void;
  
  // Chat Actions
  fetchConversations: () => Promise<void>;
  startConversation: (title?: string) => Promise<string>;
  deleteConversation: (id: string) => Promise<void>;
  selectConversation: (id: string) => void;
  sendMessage: (text: string, image?: string | null) => Promise<void>;
  appendLocalChatMessage: (userText: string, replyText: string) => Promise<void>;
  togglePinConversation: (id: string) => Promise<void>;

  // Memory Actions
  fetchMemories: () => Promise<void>;
  addMemory: (content: string, category: string) => Promise<void>;
  deleteMemory: (id: string) => Promise<void>;
  clearMemories: () => Promise<void>;
  togglePinMemory: (id: string) => Promise<void>;

  // Task Actions
  fetchTasks: () => Promise<void>;
  addTask: (name: string, type: string, priority?: string, deadline?: string, category?: string) => Promise<void>;
  cancelTask: (id: string) => Promise<void>;
  retryTask: (id: string) => Promise<void>;

  // File Actions
  fetchFiles: () => Promise<void>;
  uploadFile: (name: string, type: string, base64Data: string) => Promise<void>;
  deleteFile: (id: string) => Promise<void>;

  // Voice Actions
  startListening: () => void;
  stopListening: () => void;
  setListeningState: (isListening: boolean) => void;
  speakText: (text: string) => Promise<void>;
  stopSpeaking: () => void;
  addVoiceCommandToHistory: (command: string) => void;
  clearVoiceCommandsHistory: () => void;

  // Vision Actions
  setCapturedImage: (image: string | null) => void;
  analyzeCapturedImage: (prompt?: string) => Promise<void>;

  // System Actions
  fetchSystemStatus: () => Promise<void>;
  runDiagnostics: () => Promise<void>;
  clearDiagnosticsReport: () => void;
  fetchSettings: () => Promise<void>;
  saveSettings: (settings: AppSettings) => Promise<void>;

  // Toast Notifications state & actions
  toasts: Toast[];
  addToast: (message: string, type?: "success" | "error" | "info" | "warning", duration?: number) => void;
  removeToast: (id: string) => void;

  // Recent Activities
  recentActivities: RecentActivity[];
  addRecentActivity: (event: string, type: RecentActivity["type"], details?: string) => void;
}

function executeSystemControlCommand(text: string, store: any): boolean {
  // Classify the incoming command
  const analysis = classifyRequest(text);

  // If it's a knowledge question, let it fall through to Gemini or offline chat solver
  if (analysis.category === AgentCategory.KNOWLEDGE_QUESTIONS) {
    return false;
  }

  // Load permissions from localStorage to maintain "one time" authorizations
  const savedPerms = localStorage.getItem("jarvis_agent_permissions_v2");
  const agentPermissions = savedPerms ? JSON.parse(savedPerms) : {
    microphone: "prompt",
    accessibility: "prompt",
    fileSystem: "prompt",
    screen: "prompt",
    appControl: "prompt",
    browserAutomation: "prompt"
  };

  const permissionKey = analysis.requiredPermission;
  const cleanCmd = text.toLowerCase().trim();

  if (permissionKey && permissionKey !== "none") {
    const currentStatus = agentPermissions[permissionKey] || "prompt";
    
    if (currentStatus === "prompt") {
      const authmsg = `Sir, I have intercepted your operating request for '${analysis.action}' but security privileges for '${permissionKey}' are currently unverified. Please navigate to the Companion tab to authorize this node. Once granted, I can perform direct actions without searching.`;
      
      store.speakText("Handshake protocol required, Sir. Please authorize this register in our Companion tab.");
      store.addToast(`Security privilege '${permissionKey}' is unverified.`, "warning");
      store.appendLocalChatMessage(text, authmsg);
      return true;
    } else if (currentStatus === "denied") {
      const denymsg = `Access denied, Sir. The required security privilege for '${permissionKey}' is currently marked as Denied. Action aborted.`;
      
      store.speakText("Access denied, Sir. Secure registers are locked.");
      store.addToast("Local operation aborted: Access Denied.", "error");
      store.appendLocalChatMessage(text, denymsg);
      return true;
    }
  }

  // Permission is GRANTED! Execute direct operating simulation
  const execMsg = `${analysis.replyText}\n\n[OPERATING MODE LOGS]:\n` + analysis.executionLogs.join("\n");
  store.appendLocalChatMessage(text, execMsg);
  store.speakText(analysis.replyText);

  // Execute actual corresponding actions
  if (analysis.category === AgentCategory.DEVICE_CONTROL) {
    if (cleanCmd.includes("chrome") || cleanCmd.includes("browser")) {
      window.open("https://www.google.com", "_blank");
    } else if (cleanCmd.includes("vs code") || cleanCmd.includes("vscode")) {
      window.open("https://vscode.dev", "_blank");
    } else if (cleanCmd.includes("spotify")) {
      window.open("https://open.spotify.com", "_blank");
    }
    store.addToast(`Device Command Executed: ${analysis.action}`, "success");
    store.addRecentActivity("Device Control", "system_event", `PyAutoGUI automation: ${analysis.action}`);
    store.addTask(analysis.action, "Device_Control", "high", undefined, "Automation");
  }
  else if (analysis.category === AgentCategory.FILE_OPERATIONS) {
    if (cleanCmd.includes("create")) {
      const folderName = analysis.target || "Physics Notes";
      store.uploadFile(`${folderName}_dir.json`, "directory", "eyI3YW5pc2giOiAiSmFydmlzIn0=").catch((e: any) => {
        console.warn("Folder sync skipped:", e);
      });
    }
    store.addToast(`File Command Executed: ${analysis.action}`, "success");
    store.addRecentActivity("File Operation", "file_action", `Local Node FS: ${analysis.action}`);
    store.addTask(analysis.action, "File_System", "medium", undefined, "Records");
  }
  else if (analysis.category === AgentCategory.BROWSER_AUTOMATION) {
    if (cleanCmd.includes("youtube")) {
      window.open("https://www.youtube.com", "_blank");
    } else if (cleanCmd.includes("gmail")) {
      window.open("https://mail.google.com", "_blank");
    } else if (cleanCmd.includes("search")) {
      const q = encodeURIComponent(analysis.target);
      window.open(`https://www.youtube.com/results?search_query=${q}`, "_blank");
    }
    store.addToast(`Browser Automation Triggered: ${analysis.action}`, "success");
    store.addRecentActivity("Browser Automation", "system_event", `Playwright Headless Sequence: ${analysis.action}`);
    store.addTask(analysis.action, "Browser_Automation", "high", undefined, "Automation");
  }
  else if (analysis.category === AgentCategory.DEVELOPMENT_MODE) {
    store.addToast(`Development Command Executed: ${analysis.action}`, "success");
    store.addRecentActivity("Dev Server started", "task_started", `Terminal daemon: ${analysis.action}`);
    store.addTask(analysis.action, "Terminal_Daemon", "high", undefined, "Development");
  }

  return true;
}

function executeVoiceCommand(transcript: string, store: any): boolean {
  const text = transcript.toLowerCase().trim();
  console.log("[JARVIS VOICE COMMANDS] Checking command:", text);

  // Run Omega Neural Link / System Control Interceptor
  if (executeSystemControlCommand(text, store)) {
    return true;
  }

  // Tab Switching - Memory Vault
  if (
    text.includes("switch to memory") || 
    text.includes("show memory") || 
    text.includes("open memory") || 
    text.includes("show memory vault") ||
    text.includes("memory tab") ||
    text.includes("go to memory")
  ) {
    store.setTab("memory");
    store.addToast("Switching to Memory Vault, Sir.", "info");
    store.speakText("Switching to Memory Vault, Sir.");
    return true;
  }
  
  // Tab Switching - Chat Console
  if (
    text.includes("switch to chat") || 
    text.includes("show chat") || 
    text.includes("open chat") || 
    text.includes("show console") || 
    text.includes("show chat console") ||
    text.includes("chat tab") ||
    text.includes("go to chat")
  ) {
    store.setTab("chat");
    store.addToast("Switching to Chat Console, Sir.", "info");
    store.speakText("Switching to Chat Console, Sir.");
    return true;
  }
  
  // Tab Switching - Tasks Tab
  if (
    text.includes("switch to task") || 
    text.includes("switch to tasks") || 
    text.includes("show task") || 
    text.includes("show tasks") || 
    text.includes("open task") || 
    text.includes("open tasks") || 
    text.includes("monitor processes") || 
    text.includes("show task monitor") ||
    text.includes("task tab") ||
    text.includes("tasks tab") ||
    text.includes("go to task") ||
    text.includes("go to tasks")
  ) {
    store.setTab("tasks");
    store.addToast("Opening Task Monitor, Sir.", "info");
    store.speakText("Opening Task Monitor, Sir.");
    return true;
  }
  
  // Tab Switching - Files Tab
  if (
    text.includes("switch to file") || 
    text.includes("switch to files") || 
    text.includes("show file") || 
    text.includes("show files") || 
    text.includes("open file") || 
    text.includes("open files") || 
    text.includes("filer records") || 
    text.includes("file tab") ||
    text.includes("files tab") ||
    text.includes("go to file") ||
    text.includes("go to files")
  ) {
    store.setTab("files");
    store.addToast("Opening Filer Records, Sir.", "info");
    store.speakText("Opening Filer Records, Sir.");
    return true;
  }
  
  // Tab Switching - Settings Tab
  if (
    text.includes("switch to settings") || 
    text.includes("show settings") || 
    text.includes("open settings") || 
    text.includes("mainframe preferences") ||
    text.includes("settings tab") ||
    text.includes("go to settings")
  ) {
    store.setTab("settings");
    store.addToast("Opening System Settings, Sir.", "info");
    store.speakText("Opening System Settings, Sir.");
    return true;
  }

  // Tab Switching - Vision Tab
  if (
    text.includes("switch to vision") || 
    text.includes("show vision") || 
    text.includes("open vision") || 
    text.includes("vision center") ||
    text.includes("vision tab") ||
    text.includes("go to vision") ||
    text.includes("engage optical") ||
    text.includes("activate camera")
  ) {
    store.setTab("vision");
    store.addToast("Switching to Optical Vision Center, Sir.", "info");
    store.speakText("Opening Vision Center, Sir. Engaging primary optical diagnostics.");
    return true;
  }

  // Full Screen Chat
  if (text.includes("full screen chat") || text.includes("maximize chat") || text.includes("go full screen") || text.includes("expand chat")) {
    store.setFullScreenChat(true);
    store.setTab("chat");
    store.addToast("Expanding chat terminal to full screen, Sir.", "info");
    store.speakText("Expanding chat terminal, Sir.");
    return true;
  }
  if (text.includes("exit full screen") || text.includes("minimize chat") || text.includes("exit chat full screen") || text.includes("normal screen")) {
    store.setFullScreenChat(false);
    store.addToast("Exiting full screen mode, Sir.", "info");
    store.speakText("Restoring standard interface matrix, Sir.");
    return true;
  }

  // Theme Modes
  if (text.includes("switch to light mode") || text.includes("enable light mode") || text.includes("turn on light mode") || text.includes("light theme")) {
    if (store.settings) {
      const newSettings = { ...store.settings, appearance: { ...store.settings.appearance, mode: "light" as const } };
      store.saveSettings(newSettings);
      store.speakText("Protocols updated, Sir. Activating high-contrast clean room light mode.");
      return true;
    }
  }
  if (text.includes("switch to dark mode") || text.includes("enable dark mode") || text.includes("turn on dark mode") || text.includes("dark theme")) {
    if (store.settings) {
      const newSettings = { ...store.settings, appearance: { ...store.settings.appearance, mode: "dark" as const } };
      store.saveSettings(newSettings);
      store.speakText("Protocols updated, Sir. Activating stealth dark mode.");
      return true;
    }
  }
  if (text.includes("switch to system mode") || text.includes("system theme") || text.includes("follow system theme") || text.includes("default mode")) {
    if (store.settings) {
      const newSettings = { ...store.settings, appearance: { ...store.settings.appearance, mode: "system" as const } };
      store.saveSettings(newSettings);
      store.speakText("Protocols updated, Sir. Synchronizing visual matrix with client operating system.");
      return true;
    }
  }

  // Sound Synth Controls
  if (text.includes("mute acoustics") || text.includes("disable sound") || text.includes("turn off sound") || text.includes("mute sound")) {
    if (store.settings) {
      const newSettings = { ...store.settings, appearance: { ...store.settings.appearance, soundEnabled: false } };
      store.saveSettings(newSettings);
      store.speakText("Sound synthesizer muted, Sir.");
      return true;
    }
  }
  if (text.includes("unmute acoustics") || text.includes("enable sound") || text.includes("turn on sound") || text.includes("unmute sound")) {
    if (store.settings) {
      const newSettings = { ...store.settings, appearance: { ...store.settings.appearance, soundEnabled: true } };
      store.saveSettings(newSettings);
      store.speakText("Acoustics chimes and synthesized speech enabled, Sir.");
      return true;
    }
  }

  // Diagnostics Trigger
  if (
    text.includes("run diagnostics") || 
    text.includes("start diagnostics") || 
    text.includes("system diagnostic") || 
    text.includes("sweep diagnostics") ||
    text.includes("trigger diagnostics") ||
    text.includes("diagnostics sweep") ||
    text.includes("run diagnostic") ||
    text.includes("diagnostic sweep") ||
    text.includes("initiate diagnostics") ||
    text === "/diagnostics" ||
    text === "/diagnostic" ||
    text === "/diag"
  ) {
    store.runDiagnostics();
    return true;
  }

  // Clear Memory Trigger
  if (
    text.includes("clear memory") || 
    text.includes("clear memories") || 
    text.includes("wipe memory") || 
    text.includes("wipe memories") || 
    text.includes("erase memory") || 
    text.includes("erase memories") ||
    text === "/clear" ||
    text === "/clear-memory" ||
    text === "/clearmemory" ||
    text === "/clear_memory" ||
    text === "/wipe"
  ) {
    store.clearMemories();
    return true;
  }

  // Task Monitor Trigger
  if (
    text.includes("open task monitor") ||
    text.includes("task monitor") ||
    text === "/tasks" ||
    text === "/task" ||
    text === "/processes" ||
    text === "/monitor"
  ) {
    store.setTab("tasks");
    store.addToast("Opening Task Monitor, Sir.", "info");
    store.speakText("Opening Task Monitor, Sir.");
    return true;
  }

  if (text.includes("clear diagnostics") || text.includes("close diagnostics")) {
    store.clearDiagnosticsReport();
    store.addToast("Diagnostics modal cleared.", "info");
    store.speakText("Clearing report, Sir.");
    return true;
  }

  // New Simulation
  if (text.includes("clear chat") || text.includes("new chat") || text.includes("start new simulation") || text.includes("reset simulation")) {
    store.startConversation();
    store.setTab("chat");
    store.addToast("New simulation session initialized, Sir.", "success");
    store.speakText("New simulation session initialized, Sir.");
    return true;
  }

  return false;
}

export const useJarvisStore = create<JarvisState>((set, get) => ({
  conversations: [],
  activeConversationId: null,
  chatLoading: false,
  chatError: null,

  memories: [],
  memoriesLoading: false,

  tasks: [],
  tasksLoading: false,

  files: [],
  filesLoading: false,

  systemStatus: null,
  metricsHistory: { cpu: Array(20).fill(15), ram: Array(20).fill(25), gpu: Array(20).fill(18) },
  systemLoading: false,
  diagnosticsReport: null,
  diagnosticsLoading: false,

  settings: null,

  isListening: false,
  isSpeaking: false,
  waveformMode: "idle",
  micPermissionGranted: false,
  voiceCommandsHistory: (() => {
    try {
      const saved = localStorage.getItem("jarvis_voice_commands_history");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  })(),

  capturedImage: null,
  visionAnalysis: null,
  visionLoading: false,

  activeTab: "chat",
  isFullScreenChat: false,
  tabSyncLoading: false,

  currentUser: (() => {
    try {
      const saved = localStorage.getItem("jarvis_user");
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  })(),

  batteryLevel: null,
  batteryCharging: false,
  batterySupported: false,

  setCurrentUser: (user) => {
    try {
      if (user) {
        localStorage.setItem("jarvis_user", JSON.stringify(user));
      } else {
        localStorage.removeItem("jarvis_user");
      }
    } catch (e) {
      console.error("Local storage user save error:", e);
    }
    set({ currentUser: user });
  },

  setBatteryInfo: (level, charging, supported) => {
    set({ batteryLevel: level, batteryCharging: charging, batterySupported: supported });
  },

  setTab: (tab) => {
    const currentTab = get().activeTab;
    if (currentTab === tab) return;

    set({ tabSyncLoading: true, activeTab: tab });

    const soundEnabled = get().settings?.appearance?.soundEnabled;
    let voiceLine = "";
    if (tab === "chat") {
      voiceLine = "Chat console online, Sir. Cognitive core stands ready.";
    } else if (tab === "memory") {
      voiceLine = "Core memory vault decrypted. Retrieving secure experience logs, Sir.";
    } else if (tab === "tasks") {
      voiceLine = "Process thread monitor active. Compiling background subroutines, Sir.";
    } else if (tab === "files") {
      voiceLine = "Accessing decentralized file registry. Decrypting telemetry assets, Sir.";
    } else if (tab === "settings") {
      voiceLine = "Mainframe preferences panel online, Sir. Modifying core parameters.";
    } else if (tab === "vision") {
      voiceLine = "Optical vision center online, Sir. Engaging primary telemetry scanners.";
    } else if (tab === "companion") {
      voiceLine = "Advanced companion systems online, Sir. All premium cognitive nodes synchronized.";
    }

    if (soundEnabled && voiceLine) {
      get().speakText(voiceLine);
    }

    setTimeout(() => {
      set({ tabSyncLoading: false });
    }, 800);
  },
  setFullScreenChat: (enabled) => set({ isFullScreenChat: enabled }),

  toasts: [],
  addToast: (message, type = "info", duration = 4000) => {
    const id = Math.random().toString(36).substring(2, 9);
    const newToast: Toast = { id, message, type, duration };
    set((state) => ({ toasts: [...state.toasts, newToast] }));
    if (duration > 0) {
      setTimeout(() => {
        get().removeToast(id);
      }, duration);
    }
  },
  removeToast: (id) => {
    set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) }));
  },

  recentActivities: [
    {
      id: "act-1",
      type: "system_event",
      event: "Arc Core Synced",
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      details: "Mainframe flux chamber balanced at 100%"
    },
    {
      id: "act-2",
      type: "diagnostics_run",
      event: "Baseline Diagnostics",
      timestamp: new Date(Date.now() - 1800000).toISOString(),
      details: "All sub-grids evaluated optimal"
    },
    {
      id: "act-3",
      type: "system_event",
      event: "Security Protocol Upgraded",
      timestamp: new Date(Date.now() - 900000).toISOString(),
      details: "Jarvis Protocol Level set to Secure"
    }
  ],
  addRecentActivity: (event, type, details) => {
    const newActivity: RecentActivity = {
      id: "act-" + Math.random().toString(36).substring(2, 11),
      type,
      event,
      timestamp: new Date().toISOString(),
      details
    };
    set((state) => ({
      recentActivities: [newActivity, ...state.recentActivities].slice(0, 30)
    }));
  },

  // Chat Actions
  fetchConversations: async () => {
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        const data = await firestoreService.getConversations(user.id);
        set({ conversations: data });
        if (data.length > 0 && !get().activeConversationId) {
          set({ activeConversationId: data[0].id });
        }
      } else {
        const data = await api.getConversations();
        set({ conversations: data });
        if (data.length > 0 && !get().activeConversationId) {
          set({ activeConversationId: data[0].id });
        }
      }
    } catch (e) {
      console.error("Error fetching conversations:", e);
    }
  },

  startConversation: async (title) => {
    try {
      const user = get().currentUser;
      const cleanTitle = title || "New Simulation Session";
      let newConv: any;
      if (user && user.authSource === "firebase_auth") {
        newConv = {
          id: "c_" + Date.now().toString() + "_" + Math.random().toString(36).substring(2, 6),
          title: cleanTitle,
          pin: false,
          folder: "Default",
          messages: [],
          createdAt: new Date().toISOString()
        };
        await firestoreService.saveConversation(user.id, newConv);
      } else {
        newConv = await api.createConversation(cleanTitle);
      }
      set((state) => ({
        conversations: [newConv, ...state.conversations],
        activeConversationId: newConv.id,
      }));
      return newConv.id;
    } catch (e) {
      console.error("Error starting conversation:", e);
      return "";
    }
  },

  deleteConversation: async (id) => {
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        await firestoreService.deleteConversation(user.id, id);
      } else {
        await api.deleteConversation(id);
      }
      set((state) => {
        const conversations = state.conversations.filter((c) => c.id !== id);
        let activeId = state.activeConversationId;
        if (activeId === id) {
          activeId = conversations.length > 0 ? conversations[0].id : null;
        }
        return { conversations, activeConversationId: activeId };
      });
    } catch (e) {
      console.error("Error deleting conversation:", e);
    }
  },

  selectConversation: (id) => {
    set({ activeConversationId: id });
  },

  sendMessage: async (text, image) => {
    // Intercept client-side control commands (e.g. voice or typed instructions)
    if (executeVoiceCommand(text, get())) {
      return;
    }

    let activeId = get().activeConversationId;
    if (!activeId) {
      activeId = await get().startConversation(text.substring(0, 30));
    }

    if (!activeId) return;

    set({ chatLoading: true, chatError: null, waveformMode: "thinking" });

    // Instantly show user message locally for amazing snappy UX
    const userMsg: Message = {
      id: "local_u_" + Date.now().toString(),
      role: "user",
      content: text,
      timestamp: new Date().toISOString(),
      image: image || null
    };

    set((state) => ({
      conversations: state.conversations.map((c) => {
        if (c.id === activeId) {
          return { ...c, messages: [...c.messages, userMsg] };
        }
        return c;
      })
    }));

    try {
      const settings = get().settings;
      const model = settings?.ai?.model || "gemini-3.5-flash";
      const user = get().currentUser;
      
      // Check if user has enabled Maps Grounding toggle in local state/UI or Settings
      const useMapsGrounding = (settings?.ai as any)?.useMapsGrounding || false;
      const location = (settings?.ai as any)?.location || null;

      const data = await api.sendChatMessage(
        activeId, 
        text, 
        image, 
        model, 
        useMapsGrounding, 
        location
      );

      set((state) => ({
        conversations: state.conversations.map((c) => {
          if (c.id === activeId) {
            return data.conversation;
          }
          return c;
        }),
        chatLoading: false,
        waveformMode: "speaking"
      }));

      // Firebase Sync backup
      if (user && user.authSource === "firebase_auth") {
        await firestoreService.saveConversation(user.id, data.conversation);
      }

      // Acknowledge speaking and synthesize JARVIS speech response elegantly
      if (get().settings?.appearance?.soundEnabled) {
        await get().speakText(data.reply);
      } else {
        set({ waveformMode: "idle" });
      }

      // Automatically refresh memories and tasks since they might have updated on the backend via user commands!
      get().fetchMemories();
      get().fetchTasks();

    } catch (e: any) {
      console.error("Chat message sending error:", e);
      set({ 
        chatLoading: false, 
        chatError: e?.message || "Protocol transmission failure.",
        waveformMode: "idle" 
      });
      get().addToast(e?.message || "Protocol transmission failure.", "error");
    }
  },

  appendLocalChatMessage: async (userText, replyText) => {
    let activeId = get().activeConversationId;
    if (!activeId) {
      activeId = await get().startConversation(userText.substring(0, 30));
    }
    if (!activeId) return;

    const userMsg: Message = {
      id: "local_u_" + Date.now().toString(),
      role: "user",
      content: userText,
      timestamp: new Date().toISOString(),
      image: null
    };
    const jarvisMsg: Message = {
      id: "local_j_" + Date.now().toString(),
      role: "model",
      content: replyText,
      timestamp: new Date().toISOString(),
      image: null
    };

    set((state) => ({
      conversations: state.conversations.map((c) => {
        if (c.id === activeId) {
          const updatedMessages = [...c.messages, userMsg, jarvisMsg];
          const updatedConv = { ...c, messages: updatedMessages };
          
          // Save to firestore if logged in
          const userObj = get().currentUser;
          if (userObj && userObj.authSource === "firebase_auth") {
            firestoreService.saveConversation(userObj.id, updatedConv);
          }
          
          return updatedConv;
        }
        return c;
      })
    }));
  },

  togglePinConversation: async (id) => {
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        const conv = get().conversations.find((c) => c.id === id);
        if (conv) {
          const updated = { ...conv, pin: !conv.pin };
          await firestoreService.saveConversation(user.id, updated);
          set((state) => ({
            conversations: state.conversations.map((c) => (c.id === id ? updated : c)),
          }));
        }
      } else {
        const updated = await api.togglePinConversation(id);
        set((state) => ({
          conversations: state.conversations.map((c) => (c.id === id ? updated : c)),
        }));
      }
    } catch (e) {
      console.error("Error pinning conversation:", e);
    }
  },

  // Memories Actions
  fetchMemories: async () => {
    set({ memoriesLoading: true });
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        const data = await firestoreService.getMemories(user.id);
        set({ memories: data, memoriesLoading: false });
      } else {
        const data = await api.getMemories();
        set({ memories: data, memoriesLoading: false });
      }
    } catch (e) {
      console.error("Error fetching memories:", e);
      set({ memoriesLoading: false });
    }
  },

  addMemory: async (content, category) => {
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        const newMem = {
          id: "m_" + Date.now().toString() + "_" + Math.random().toString(36).substring(2, 6),
          content,
          category: category || "General",
          pinned: false,
          date: new Date().toISOString()
        };
        await firestoreService.saveMemory(user.id, newMem);
        set((state) => ({ memories: [newMem, ...state.memories] }));
      } else {
        const newMem = await api.createMemory(content, category);
        set((state) => ({ memories: [newMem, ...state.memories] }));
      }
      get().addToast("Memory logged in vault.", "success");
    } catch (e: any) {
      console.error("Error adding memory:", e);
      get().addToast("Failed to record memory.", "error");
    }
  },

  deleteMemory: async (id) => {
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        await firestoreService.deleteMemory(user.id, id);
        set((state) => ({ memories: state.memories.filter((m) => m.id !== id) }));
      } else {
        await api.deleteMemory(id);
        set((state) => ({ memories: state.memories.filter((m) => m.id !== id) }));
      }
      get().addToast("Memory record erased from core.", "warning");
    } catch (e: any) {
      console.error("Error deleting memory:", e);
      get().addToast("Failed to delete memory.", "error");
    }
  },
  
  clearMemories: async () => {
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        await firestoreService.clearAllMemories(user.id);
        set({ memories: [] });
      } else {
        await api.clearMemories();
        set({ memories: [] });
      }
      get().addToast("All core memories erased from database.", "warning");
      get().addRecentActivity("Memory Cleared", "system_event", "Unified core memory database wiped securely");
      
      if (get().settings?.appearance?.soundEnabled) {
        await get().speakText("Mainframe memory database has been securely wiped, Sir.");
      }
    } catch (e: any) {
      console.error("Error clearing memories:", e);
      get().addToast("Failed to wipe memories from mainframe.", "error");
    }
  },

  togglePinMemory: async (id) => {
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        const mem = get().memories.find((m) => m.id === id);
        if (mem) {
          const updated = { ...mem, pinned: !mem.pinned };
          await firestoreService.saveMemory(user.id, updated);
          set((state) => ({
            memories: state.memories.map((m) => (m.id === id ? updated : m)),
          }));
          get().addToast(updated.pinned ? "Memory pinned to core registry." : "Memory unpinned.", "info");
        }
      } else {
        const updated = await api.togglePinMemory(id);
        set((state) => ({
          memories: state.memories.map((m) => (m.id === id ? updated : m)),
        }));
        get().addToast(updated.pinned ? "Memory pinned to core registry." : "Memory unpinned.", "info");
      }
    } catch (e: any) {
      console.error("Error pinning memory:", e);
      get().addToast("Failed to update memory pin state.", "error");
    }
  },

  // Task Actions
  fetchTasks: async () => {
    set({ tasksLoading: true });
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        const data = await firestoreService.getTasks(user.id);
        set({ tasks: data, tasksLoading: false });
      } else {
        const data = await api.getTasks();
        set({ tasks: data, tasksLoading: false });
      }
    } catch (e) {
      console.error("Error fetching tasks:", e);
      set({ tasksLoading: false });
    }
  },

  addTask: async (name, type, priority, deadline, category) => {
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        const newTask: Task = {
          id: "t_" + Date.now().toString() + "_" + Math.random().toString(36).substring(2, 6),
          name,
          status: "running",
          progress: 0,
          logs: ["Task initialized via Firebase secure node."],
          type: type || "Automation",
          priority: (priority || "medium") as any,
          deadline,
          category,
          timestamp: new Date().toISOString()
        };
        await firestoreService.saveTask(user.id, newTask);
        set((state) => ({ tasks: [newTask, ...state.tasks] }));
      } else {
        const newTask = await api.createTask(name, "running", 0, ["Task initialized."], type, priority, deadline, category);
        set((state) => ({ tasks: [newTask, ...state.tasks] }));
      }
      get().addToast("Process thread initialized successfully.", "success");
      get().addRecentActivity(`Task Started: ${name}`, "task_started", `Deployed sub-thread of type: ${type}`);
    } catch (e: any) {
      console.error("Error adding task:", e);
      get().addToast("Failed to deploy task thread.", "error");
    }
  },

  cancelTask: async (id) => {
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        const task = get().tasks.find((t) => t.id === id);
        if (task) {
          const updated = { ...task, status: "cancelled" as const };
          await firestoreService.saveTask(user.id, updated);
          set((state) => ({
            tasks: state.tasks.map((t) => (t.id === id ? updated : t)),
          }));
        }
      } else {
        const updated = await api.triggerTaskAction(id, "cancel");
        set((state) => ({
          tasks: state.tasks.map((t) => (t.id === id ? updated : t)),
        }));
      }
      get().addToast("Process thread terminated.", "warning");
    } catch (e: any) {
      console.error("Error cancelling task:", e);
      get().addToast("Failed to terminate task thread.", "error");
    }
  },

  retryTask: async (id) => {
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        const task = get().tasks.find((t) => t.id === id);
        if (task) {
          const updated = { ...task, status: "running" as const, progress: 0, logs: ["Process thread restarted."] };
          await firestoreService.saveTask(user.id, updated);
          set((state) => ({
            tasks: state.tasks.map((t) => (t.id === id ? updated : t)),
          }));
        }
      } else {
        const updated = await api.triggerTaskAction(id, "retry");
        set((state) => ({
          tasks: state.tasks.map((t) => (t.id === id ? updated : t)),
        }));
      }
      get().addToast("Process thread retrying...", "info");
    } catch (e: any) {
      console.error("Error retrying task:", e);
      get().addToast("Failed to retry task thread.", "error");
    }
  },

  // File Actions
  fetchFiles: async () => {
    set({ filesLoading: true });
    try {
      const data = await api.getFiles();
      set({ files: data, filesLoading: false });
    } catch (e) {
      console.error("Error fetching files:", e);
      set({ filesLoading: false });
    }
  },

  uploadFile: async (name, type, base64Data) => {
    try {
      const newFile = await api.uploadFile(name, type, base64Data);
      set((state) => ({ files: [newFile, ...state.files] }));
      get().addToast("Telemetry file successfully uploaded and decrypted.", "success");
      get().addRecentActivity(`File Uploaded: ${name}`, "file_action", `Decrypted payload sectors of type: ${type}`);
    } catch (e: any) {
      console.error("Error uploading file:", e);
      get().addToast("File upload failed.", "error");
      throw e;
    }
  },

  deleteFile: async (id) => {
    try {
      await api.deleteFile(id);
      set((state) => ({ files: state.files.filter((f) => f.id !== id) }));
      get().addToast("Telemetry file erased from repository.", "warning");
      get().addRecentActivity(`File Erased: ID ${id.substring(0, 8)}`, "file_action", `Secured sector memory sectors deallocated`);
    } catch (e: any) {
      console.error("Error deleting file:", e);
      get().addToast("Failed to delete file record.", "error");
    }
  },

  // Voice Interaction Core
  startListening: () => {
    set({ isListening: true, waveformMode: "listening" });
    try {
      // Handle HTML5 Web Speech API for voice triggers
      if (typeof window !== "undefined" && ("webkitSpeechRecognition" in window || "SpeechRecognition" in window)) {
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = "en-US";

        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          if (transcript && transcript.trim() !== "") {
            get().addVoiceCommandToHistory(transcript);
            get().sendMessage(transcript);
          }
        };

        recognition.onerror = (event: any) => {
          if (event.error === "no-speech") {
            console.warn("[Voice Core] Standby: No vocal input detected within timeout.");
          } else {
            console.error("Speech Recognition Error:", event.error);
            get().addToast(`Speech recognition warning: ${event.error}`, "warning");
          }
          set({ isListening: false, waveformMode: "idle" });
        };

        recognition.onend = () => {
          set({ isListening: false });
          if (get().waveformMode === "listening") {
            set({ waveformMode: "idle" });
          }
        };

        recognition.start();
      } else {
        console.warn("Speech recognition not supported in this browser.");
        // Simulated response voice entry
        setTimeout(() => {
          const simCmd = "System baseline diagnostic override.";
          get().addVoiceCommandToHistory(simCmd);
          get().sendMessage(simCmd);
          set({ isListening: false, waveformMode: "idle" });
        }, 3000);
      }
    } catch (e) {
      console.warn("Speech recognition initialization failed or blocked:", e);
      setTimeout(() => {
        const simCmd = "System baseline diagnostic override.";
        get().addVoiceCommandToHistory(simCmd);
        get().sendMessage(simCmd);
        set({ isListening: false, waveformMode: "idle" });
      }, 3000);
    }
  },

  stopListening: () => {
    set({ isListening: false, waveformMode: "idle" });
  },

  setListeningState: (isListening) => {
    set({ isListening, waveformMode: isListening ? "listening" : "idle" });
  },

  speakText: async (text) => {
    get().stopSpeaking();
    set({ isSpeaking: true, waveformMode: "speaking" });

    try {
      const voice = get().settings?.ai?.voiceName || "Zephyr";
      const cleanText = text.replace(/[*#_`]/g, ""); // Strip markdown noise
      const data = await api.synthesizeSpeech(cleanText, voice);

      if (data.audio) {
        // Decode and play PCM or standard media
        const audioBytes = atob(data.audio);
        const arrayBuffer = new ArrayBuffer(audioBytes.length);
        const uint8Array = new Uint8Array(arrayBuffer);
        for (let i = 0; i < audioBytes.length; i++) {
          uint8Array[i] = audioBytes.charCodeAt(i);
        }
        
        const mimeType = (data.mimeType || "").toLowerCase();
        let finalAudioData = uint8Array;
        let finalMimeType = data.mimeType || "audio/mp3";

        // If returned data is raw PCM, wrap it in a WAV container so standard browser <audio> can play it
        if (mimeType.includes("pcm")) {
          let sampleRate = 24000;
          const match = mimeType.match(/rate=(\d+)/);
          if (match) {
            sampleRate = parseInt(match[1], 10);
          }
          
          // Generate 44-byte WAV header
          const wavBuffer = new ArrayBuffer(44 + uint8Array.length);
          const view = new DataView(wavBuffer);
          
          view.setUint32(0, 0x46464952, true); // "RIFF"
          view.setUint32(4, 36 + uint8Array.length, true);
          view.setUint32(8, 0x45564157, true); // "WAVE"
          view.setUint32(12, 0x20746d66, true); // "fmt "
          view.setUint32(16, 16, true); // subchunk1 size (16 for PCM)
          view.setUint16(20, 1, true); // audio format (1 = PCM)
          view.setUint16(22, 1, true); // num channels (1 = mono)
          view.setUint32(24, sampleRate, true); // sample rate
          view.setUint32(28, sampleRate * 1 * 16 / 8, true); // byte rate (sampleRate * channels * bits/sample / 8)
          view.setUint16(32, 1 * 16 / 8, true); // block align
          view.setUint16(34, 16, true); // bits per sample (16)
          view.setUint32(36, 0x61746164, true); // "data"
          view.setUint32(40, uint8Array.length, true); // data size
          
          const finalWavArray = new Uint8Array(wavBuffer);
          finalWavArray.set(uint8Array, 44);
          
          finalAudioData = finalWavArray;
          finalMimeType = "audio/wav";
        }

        const blob = new Blob([finalAudioData], { type: finalMimeType });
        const audioUrl = URL.createObjectURL(blob);
        
        const audio = new Audio(audioUrl);
        (window as any).jarvisActiveAudio = audio;
        
        // Set playbackRate if speechRate is customized
        const rate = get().settings?.ai?.speechRate || 1.0;
        try {
          audio.playbackRate = rate;
        } catch (e) {
          console.warn("Failed to set audio playback rate:", e);
        }
        
        audio.onended = () => {
          set({ isSpeaking: false, waveformMode: "idle" });
        };
        audio.onerror = () => {
          set({ isSpeaking: false, waveformMode: "idle" });
        };
        await audio.play();
        return;
      }
    } catch (err) {
      console.error("Synthesize API failed, falling back to Web Speech Synthesis API:", err);
    }

    // High fidelity browser vocalizer fallback
    try {
      if (typeof window !== "undefined" && "speechSynthesis" in window && typeof SpeechSynthesisUtterance !== "undefined") {
        const cleanText = text.replace(/[*#_`]/g, ""); // Strip markdown noise
        const utterance = new SpeechSynthesisUtterance(cleanText);
        
        // Let's find an elegant British male voice to suit JARVIS!
        const voices = window.speechSynthesis.getVoices() || [];
        const britishVoice = voices.find(v => v.lang.startsWith("en-GB") && v.name.toLowerCase().includes("male")) ||
                             voices.find(v => v.lang.startsWith("en-GB")) ||
                             voices.find(v => v.lang.startsWith("en"));
        
        if (britishVoice) utterance.voice = britishVoice;
        utterance.rate = get().settings?.ai?.speechRate || 1.05; // Slightly faster for Jarvis cyber-intelligence feel by default
        utterance.pitch = 0.95; // Slightly lower pitch for that rich baritone resonance

        utterance.onend = () => {
          set({ isSpeaking: false, waveformMode: "idle" });
        };
        utterance.onerror = () => {
          set({ isSpeaking: false, waveformMode: "idle" });
        };

        (window as any).jarvisActiveSpeechUtterance = utterance;
        window.speechSynthesis.speak(utterance);
      } else {
        // Offline fallback end state
        setTimeout(() => {
          set({ isSpeaking: false, waveformMode: "idle" });
        }, 4000);
      }
    } catch (e) {
      console.warn("Speech synthesis fallback blocked or failed:", e);
      setTimeout(() => {
        set({ isSpeaking: false, waveformMode: "idle" });
      }, 3000);
    }
  },

  stopSpeaking: () => {
    // Stop custom HTML Audio
    if ((window as any).jarvisActiveAudio) {
      try {
        (window as any).jarvisActiveAudio.pause();
        (window as any).jarvisActiveAudio = null;
      } catch (e) {}
    }
    // Stop Web Speech
    try {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    } catch (e) {
      console.warn("speechSynthesis.cancel blocked or failed:", e);
    }
    set({ isSpeaking: false, waveformMode: "idle" });
  },

  addVoiceCommandToHistory: (command: string) => {
    if (!command || command.trim() === "") return;
    const trimmed = command.trim();
    set((state) => {
      // Filter out duplicate to keep the list unique, then insert at top
      const filtered = state.voiceCommandsHistory.filter(
        (c) => c.toLowerCase() !== trimmed.toLowerCase()
      );
      const updated = [trimmed, ...filtered].slice(0, 30);
      try {
        localStorage.setItem("jarvis_voice_commands_history", JSON.stringify(updated));
      } catch (e) {
        console.error("Failed to save voice command history:", e);
      }
      return { voiceCommandsHistory: updated };
    });
  },

  clearVoiceCommandsHistory: () => {
    set({ voiceCommandsHistory: [] });
    try {
      localStorage.removeItem("jarvis_voice_commands_history");
    } catch (e) {
      console.error("Failed to clear voice command history:", e);
    }
  },

  // Vision Actions
  setCapturedImage: (image) => set({ capturedImage: image, visionAnalysis: null }),
  
  analyzeCapturedImage: async (prompt) => {
    const img = get().capturedImage;
    if (!img) return;

    set({ visionLoading: true, visionAnalysis: null });
    get().addToast("Executing real-time telemetry scan...", "info");
    try {
      const data = await api.analyzeVision(img, prompt);
      set({ visionAnalysis: data.result, visionLoading: false });
      get().addToast("Visual scan analysis completed.", "success");

      if (get().settings?.appearance?.soundEnabled) {
        await get().speakText(data.result);
      }
    } catch (e: any) {
      console.error("Vision Analyze error:", e);
      set({ 
        visionAnalysis: `Error executing core telemetry scan: ${e?.message || e}`, 
        visionLoading: false 
      });
      get().addToast("Visual scan analysis failed.", "error");
    }
  },

  // System Diagnostics
  fetchSystemStatus: async () => {
    try {
      let data;
      try {
        data = await api.getSystemStatus();
      } catch (fetchError) {
        console.warn("Server connection offline or booting. Utilizing local system status telemetry fallback.", fetchError);
        // High fidelity fallback matching the server response
        const mockCpu = Math.floor(10 + Math.random() * 15);
        const mockRam = Math.floor(40 + Math.random() * 10);
        const mockGpu = Math.floor(15 + Math.random() * 20);
        data = {
          status: "SECURE (OFFLINE)",
          activeKey: false,
          uptime: (typeof performance !== "undefined" && performance.now) ? performance.now() / 1000 : 300,
          serverMetrics: {
            cpu: mockCpu,
            ram: mockRam,
            gpu: mockGpu,
            battery: 100,
            networkSpeed: "--- Mbps",
            temperature: "34°C"
          },
          voiceActive: true,
          diagnostics: {
            integrity: "98%",
            subsystems: {
              hologrid: "OFFLINE",
              arcCore: "STABLE",
              mainframe: "LOCAL_MIRROR",
              sentinel: "SECURE"
            }
          },
          activeTasksCount: 0
        };
      }

      set((state) => {
        // Roll metrics history
        const limit = 20;
        const newCpu = [...state.metricsHistory.cpu.slice(1), data.serverMetrics.cpu];
        const newRam = [...state.metricsHistory.ram.slice(1), data.serverMetrics.ram];
        const newGpu = [...state.metricsHistory.gpu.slice(1), data.serverMetrics.gpu];

        return {
          systemStatus: data,
          metricsHistory: { cpu: newCpu, ram: newRam, gpu: newGpu }
        };
      });
    } catch (e) {
      console.error("Error updating system status state:", e);
    }
  },

  runDiagnostics: async () => {
    set({ diagnosticsLoading: true, diagnosticsReport: null });
    get().addToast("Initiating comprehensive diagnostics sweep...", "info");
    get().addRecentActivity("Diagnostics Run", "diagnostics_run", "Comprehensive telemetry sweep initiated");
    try {
      const res = await api.runDiagnostics();
      set({ diagnosticsReport: res.report, diagnosticsLoading: false });
      get().addToast("System diagnostic scan complete.", "success");
      
      // Voice synthesize if sound is enabled
      if (get().settings?.appearance?.soundEnabled) {
        const lineMatch = res.report.match(/\*\*OVERALL SYSTEM HEALTH:\s*([^\*]+)\*\*/i) || res.report.match(/health[\w\s]*:\s*([\d\.%]+)/i);
        const health = lineMatch ? lineMatch[1] : "nominal";
        await get().speakText(`Diagnostics sweep completed, Sir. Overall system health is evaluated at ${health}.`);
      }
    } catch (e: any) {
      console.error("Diagnostics sweep failed:", e);
      set({ diagnosticsLoading: false });
      get().addToast("Critical failure during diagnostics sweep: " + (e.message || e), "error");
    }
  },

  clearDiagnosticsReport: () => {
    set({ diagnosticsReport: null });
  },

  fetchSettings: async () => {
    try {
      const user = get().currentUser;
      let data: any;
      if (user && user.authSource === "firebase_auth") {
        data = await firestoreService.getSettings(user.id);
        if (!data) {
          data = await api.getSettings();
        }
      } else {
        data = await api.getSettings();
      }
      if (data && !data.systemControl) {
        data.systemControl = {
          enabled: false,
          osType: "both",
          openAppAction: true,
          readNotifications: true,
          autoTypeWhatsapp: true,
          clapSensitivity: 50,
          wakeTriggers: {
            oral: true,
            write: true,
            clap: false,
            nameWake: true
          }
        };
      }
      set({ settings: data });
    } catch (e) {
      console.error("Error fetching settings:", e);
    }
  },

  saveSettings: async (settings) => {
    try {
      const user = get().currentUser;
      if (user && user.authSource === "firebase_auth") {
        await firestoreService.saveSettings(user.id, settings);
      } else {
        await api.saveSettings(settings);
      }
      set({ settings });
      get().addToast("Core preferences successfully saved.", "success");
    } catch (e: any) {
      console.error("Error saving settings:", e);
      get().addToast("Failed to save core preferences.", "error");
    }
  }
}));
