export enum AgentCategory {
  DEVICE_CONTROL = "Device Control",
  FILE_OPERATIONS = "File Operations",
  BROWSER_AUTOMATION = "Browser Automation",
  DEVELOPMENT_MODE = "Development Mode",
  KNOWLEDGE_QUESTIONS = "Knowledge Questions"
}

export interface ClassificationResult {
  category: AgentCategory;
  action: string;
  requiredPermission: "microphone" | "accessibility" | "fileSystem" | "screen" | "appControl" | "browserAutomation" | "none";
  executionLogs: string[];
  replyText: string;
  target: string;
}

export function classifyRequest(text: string): ClassificationResult {
  const cleanText = text.toLowerCase().trim();

  // 1. DEVICE CONTROL CATEGORY
  if (
    cleanText.includes("open chrome") ||
    cleanText.includes("launch chrome") ||
    cleanText.includes("open google chrome") ||
    cleanText.includes("open vs code") ||
    cleanText.includes("launch vs code") ||
    cleanText.includes("open vscode") ||
    cleanText.includes("launch spotify") ||
    cleanText.includes("open spotify") ||
    cleanText.includes("close discord") ||
    cleanText.includes("increase volume") ||
    cleanText.includes("raise volume") ||
    cleanText.includes("volume up") ||
    cleanText.includes("lock the computer") ||
    cleanText.includes("lock computer") ||
    cleanText.includes("lock pc") ||
    cleanText.includes("open downloads")
  ) {
    let action = "Device Control Operation";
    let target = "System App";
    let executionLogs: string[] = [];
    let replyText = "";

    if (cleanText.includes("chrome")) {
      action = "Launch Google Chrome Browser";
      target = "Chrome";
      executionLogs = [
        "[pyautogui] press('win')",
        "[pyautogui] sleep(0.1)",
        "[pyautogui] write('chrome')",
        "[pyautogui] press('enter')",
        "[psutil] scanning active windows handle registers...",
        "[psutil] chrome.exe process detected (PID: 12480)"
      ];
      replyText = "Initiating direct device control protocols, Sir. Simulating keyboard macro arrays using PyAutoGUI to launch Google Chrome on your main workspace.";
    } else if (cleanText.includes("vs code") || cleanText.includes("vscode")) {
      action = "Launch Visual Studio Code";
      target = "VS Code";
      executionLogs = [
        "[pyautogui] press('win')",
        "[pyautogui] sleep(0.1)",
        "[pyautogui] write('vscode')",
        "[pyautogui] press('enter')",
        "[psutil] active process list verified: vscode.exe",
        "[local_agent] directory bound: /workspaces/jarvis"
      ];
      replyText = "Understood, Sir. Accessing application control registers and deploying Visual Studio Code editor via PyAutoGUI automation.";
    } else if (cleanText.includes("spotify")) {
      action = "Launch Spotify Desktop Client";
      target = "Spotify";
      executionLogs = [
        "[pyautogui] press('win')",
        "[pyautogui] sleep(0.1)",
        "[pyautogui] write('spotify')",
        "[pyautogui] press('enter')",
        "[psutil] spotify.exe audio hook initialized."
      ];
      replyText = "Initializing audio telemetry, Sir. Launching Spotify desktop client on your workstation.";
    } else if (cleanText.includes("close discord")) {
      action = "Terminate Discord Client Process";
      target = "Discord";
      executionLogs = [
        "[psutil] scanning process tree for discord.exe...",
        "[psutil] located PID 9188: discord.exe",
        "[psutil] transmitting SIGTERM termination signal...",
        "[psutil] process discord.exe successfully terminated."
      ];
      replyText = "Terminating Discord background processes, Sir. Revoking processor priority and clearing memory registers.";
    } else if (cleanText.includes("volume")) {
      action = "Increase Audio Volume";
      target = "Volume Controller";
      executionLogs = [
        "[pyautogui] press('volumeup', presses=5)",
        "[local_agent] master volume telemetry updated to 85%"
      ];
      replyText = "Adjusting audio frequency gains, Sir. PyAutoGUI has issued keyboard interrupts to increase system volume.";
    } else if (cleanText.includes("lock")) {
      action = "Secure Operating Session";
      target = "Workstation Locker";
      executionLogs = [
        "[ctypes] calling user32.LockWorkStation()...",
        "[system_api] windows lock screen command dispatched",
        "[sentinel] security standby mode activated."
      ];
      replyText = "Enacting security protocol Omega, Sir. Invoking system LockWorkStation APIs to secure your active workstation session.";
    } else if (cleanText.includes("downloads")) {
      action = "Open Downloads Directory";
      target = "File Explorer";
      executionLogs = [
        "[pyautogui] press('win + r')",
        "[pyautogui] sleep(0.05)",
        "[pyautogui] write('shell:Downloads')",
        "[pyautogui] press('enter')",
        "[os.startfile] launched native windows file explorer handler"
      ];
      replyText = "Opening local Downloads directory, Sir. Spawning file explorer nodes on your active monitor.";
    }

    return {
      category: AgentCategory.DEVICE_CONTROL,
      action,
      requiredPermission: "appControl",
      executionLogs,
      replyText,
      target
    };
  }

  // 2. FILE OPERATIONS CATEGORY
  if (
    cleanText.includes("create a folder") ||
    cleanText.includes("create folder") ||
    cleanText.includes("rename this file") ||
    cleanText.includes("rename file") ||
    cleanText.includes("move the pdf") ||
    cleanText.includes("move pdf") ||
    cleanText.includes("move file") ||
    cleanText.includes("search my laptop") ||
    cleanText.includes("search computer") ||
    cleanText.includes("search laptop") ||
    cleanText.includes("search my notes")
  ) {
    let action = "File System Operation";
    let target = "Local Workspace";
    let executionLogs: string[] = [];
    let replyText = "";

    if (cleanText.includes("create a folder") || cleanText.includes("create folder")) {
      const match = text.match(/(?:named|folder)\s+["']?([^"']+)["']?/i);
      const folderName = match ? match[1].trim() : "Physics Notes";
      action = `Create folder: "${folderName}"`;
      target = folderName;
      executionLogs = [
        `[os.makedirs] creating folder directory path: /workspaces/${folderName}`,
        "[shutil] building system metadata records...",
        "[local_agent] directory tree synchronized successfully."
      ];
      replyText = `Direct file operation completed, Sir. Initializing standard OS creation channels to construct your '${folderName}' directory.`;
    } else if (cleanText.includes("rename")) {
      action = "Rename Local File Reference";
      target = "File Handles";
      executionLogs = [
        "[os.rename] source: /workspaces/temp_evaluation.pdf",
        "[os.rename] destination: /workspaces/core_telemetry_eval.pdf",
        "[local_agent] cache indices updated"
      ];
      replyText = "Indeed, Sir. Executing file system rename protocols on your selected document handles.";
    } else if (cleanText.includes("move")) {
      action = "Relocate File To Documents";
      target = "PDF Document";
      executionLogs = [
        "[shutil.move] relocating target file -> /workspaces/Documents/",
        "[os.path.exists] destination directory verified",
        "[shutil] block sync successfully completed (14.2 MB transfer)"
      ];
      replyText = "Transfer packet complete, Sir. Moving your PDF payload to the local Documents directory.";
    } else if (cleanText.includes("search")) {
      const match = text.match(/(?:for)\s+["']?([^"']+)["']?/i);
      const searchQuery = match ? match[1].trim() : "JEE formulas";
      action = `Local Search: "${searchQuery}"`;
      target = searchQuery;
      executionLogs = [
        "[os.walk] traversing local workspace volumes...",
        `[re.search] compiling regex crawl for expression "${searchQuery}"`,
        "[local_agent] scan complete: found 3 matches in /workspaces/notes"
      ];
      replyText = `Scanning local workstation records, Sir. Running regular expression crawls across your storage volumes for '${searchQuery}'.`;
    }

    return {
      category: AgentCategory.FILE_OPERATIONS,
      action,
      requiredPermission: "fileSystem",
      executionLogs,
      replyText,
      target
    };
  }

  // 3. BROWSER AUTOMATION CATEGORY
  if (
    cleanText.includes("open youtube") ||
    cleanText.includes("launch youtube") ||
    cleanText.includes("search for") ||
    cleanText.includes("open gmail") ||
    cleanText.includes("download the pdf") ||
    cleanText.includes("download pdf")
  ) {
    let action = "Browser Automation Hook";
    let target = "Web Workspace";
    let executionLogs: string[] = [];
    let replyText = "";

    if (cleanText.includes("youtube")) {
      action = "Playwright: Open YouTube";
      target = "YouTube";
      executionLogs = [
        "[playwright] sync_playwright() context manager initialized",
        "[playwright] browser = chromium.launch(headless=False)",
        "[playwright] page = browser.new_page()",
        "[playwright] page.goto('https://www.youtube.com')",
        "[playwright] wait_for_load_state('networkidle')"
      ];
      replyText = "Understood, Sir. Spawning an automated Playwright chromium browser instance and navigating directly to YouTube.";
    } else if (cleanText.includes("search")) {
      const match = text.match(/(?:search for)\s+["']?([^"']+)["']?/i);
      const searchVal = match ? match[1].trim() : "JEE Advanced lectures";
      action = `Playwright: Search YouTube for "${searchVal}"`;
      target = searchVal;
      executionLogs = [
        "[playwright] page.goto('https://www.youtube.com')",
        `[playwright] page.fill('input#search', '${searchVal}')`,
        "[playwright] page.click('button#search-icon-legacy')",
        "[playwright] waiting for selector results container..."
      ];
      replyText = `Executing automated search queries, Sir. Instructing our Playwright engine to crawl YouTube, input text for '${searchVal}', and click the search handler.`;
    } else if (cleanText.includes("gmail")) {
      action = "Playwright: Open Gmail";
      target = "Gmail";
      executionLogs = [
        "[playwright] loading authenticated browser context",
        "[playwright] page.goto('https://mail.google.com')",
        "[playwright] page.wait_for_selector('[role=main]')"
      ];
      replyText = "Opening secure communications stream, Sir. Navigating Playwright automated nodes directly to your Gmail inbox.";
    } else if (cleanText.includes("download")) {
      action = "Playwright: Download Manager Sequence";
      target = "PDF Downloader";
      executionLogs = [
        "[playwright] locating download interactive buttons on current viewport...",
        "[playwright] with page.expect_download() as download_info:",
        "[playwright]   page.get_by_text('Download PDF').first.click()",
        "[playwright] path = download_info.value.path()",
        "[local_agent] downloaded file saved: /workspaces/downloads/jee_chemsheet.pdf"
      ];
      replyText = "Acquiring network download stream, Sir. Commencing Playwright automated download processes for the target PDF.";
    }

    return {
      category: AgentCategory.BROWSER_AUTOMATION,
      action,
      requiredPermission: "browserAutomation",
      executionLogs,
      replyText,
      target
    };
  }

  // 4. DEVELOPMENT MODE CATEGORY
  if (
    cleanText.includes("run my fastapi server") ||
    cleanText.includes("run fastapi") ||
    cleanText.includes("run server") ||
    cleanText.includes("start my backend") ||
    cleanText.includes("start the react project") ||
    cleanText.includes("start react") ||
    cleanText.includes("run react") ||
    cleanText.includes("open terminal") ||
    cleanText.includes("start terminal") ||
    cleanText.includes("launch terminal") ||
    cleanText.includes("commit to github") ||
    cleanText.includes("git commit") ||
    cleanText.includes("push to github")
  ) {
    let action = "Terminal Dev Environment Automation";
    let target = "Local Shell";
    let executionLogs: string[] = [];
    let replyText = "";

    if (cleanText.includes("fastapi") || cleanText.includes("backend")) {
      action = "FastAPI Server Daemon Run";
      target = "FastAPI / Uvicorn";
      executionLogs = [
        "[terminal] python -m uvicorn main:app --host 0.0.0.0 --port 8000",
        "[uvicorn] starting FastAPI server processes...",
        "[uvicorn] loading ASGI application. main:app successfully imported.",
        "[uvicorn] Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)"
      ];
      replyText = "Understood, Sir. Spawning terminal thread for your FastAPI backend server using uvicorn daemon processes.";
    } else if (cleanText.includes("react")) {
      action = "React Vite Dev Server Run";
      target = "React / Vite";
      executionLogs = [
        "[terminal] npm run dev -- --host 0.0.0.0 --port 3000",
        "[vite] localized development server booting...",
        "[vite] dev server running on port 3000",
        "[vite] network routing bound to client preview proxy link."
      ];
      replyText = "Configuring web environment, Sir. Activating the Vite React project development environment on standard port 3000.";
    } else if (cleanText.includes("terminal")) {
      action = "Local Command Interpreter Spawn";
      target = "Shell Command Node";
      executionLogs = [
        "[terminal] spawning local bash shell process...",
        "[terminal] working directory: /workspaces/jarvis",
        "[terminal] command listener initialized. Uplink verified."
      ];
      replyText = "Spawning a localized secure shell session, Sir. Integrating terminal pipelines on your terminal monitor tab.";
    } else if (cleanText.includes("github") || cleanText.includes("commit")) {
      action = "Git Repository Push Sync";
      target = "GitHub Mainframe";
      executionLogs = [
        "[git] git add .",
        "[git] git commit -m 'automatic delta backup via JARVIS OMEGA core'",
        "[git] git push origin main",
        "[git] push successful: 18 objects synchronized. Commit hex code [da39a3e]"
      ];
      replyText = "Initiating GitHub push sequences, Sir. Staging modified assets, committing, and uploading files to origin main.";
    }

    return {
      category: AgentCategory.DEVELOPMENT_MODE,
      action,
      requiredPermission: "accessibility", // accessibility/appControl
      executionLogs,
      replyText,
      target
    };
  }

  // 5. KNOWLEDGE QUESTIONS CATEGORY (Newton, recursion, quantum, etc.)
  return {
    category: AgentCategory.KNOWLEDGE_QUESTIONS,
    action: "Localized Conceptual reasoning",
    requiredPermission: "none",
    executionLogs: [
      "[gemini] query routed to cognitive semantic index...",
      "[gemini] compiling conceptual token structure..."
    ],
    replyText: "",
    target: "AI Reasoning Core"
  };
}
