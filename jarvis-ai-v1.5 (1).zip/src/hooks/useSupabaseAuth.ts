import { useState, useEffect, useCallback } from "react";
import { createClient } from "@supabase/supabase-js";
import { useJarvisStore } from "../stores/jarvisStore";
import { api } from "../services/api";

let supabaseClient: any = null;

/**
 * Lazy initialization helper for Supabase Client to prevent crashes on startup
 * if environment variables are not yet populated.
 */
export function getSupabaseClient() {
  const url = (import.meta as any).env.VITE_SUPABASE_URL;
  const anonKey = (import.meta as any).env.VITE_SUPABASE_ANON_KEY;
  
  if (!url || !anonKey || url === "MY_SUPABASE_URL" || url.trim() === "" || anonKey.trim() === "") {
    return null;
  }
  
  if (!supabaseClient) {
    supabaseClient = createClient(url, anonKey);
  }
  return supabaseClient;
}

export function useSupabaseAuth() {
  const { currentUser, setCurrentUser, addToast, addRecentActivity } = useJarvisStore();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [supabaseStatus, setSupabaseStatus] = useState<{
    configured: boolean;
    url: string;
    anonKey: string;
    sqlTableHelp: string;
  }>({
    configured: false,
    url: "MISSING",
    anonKey: "MISSING",
    sqlTableHelp: ""
  });

  // Verify status of client-side and server-side configurations
  const checkConfigStatus = useCallback(async () => {
    try {
      const clientSide = getSupabaseClient() !== null;
      const response = await api.getSupabaseStatus().catch(() => null);
      
      setSupabaseStatus({
        configured: clientSide || (response?.configured ?? false),
        url: ((import.meta as any).env.VITE_SUPABASE_URL ? "CONFIGURED" : (response?.url ?? "MISSING")),
        anonKey: ((import.meta as any).env.VITE_SUPABASE_ANON_KEY ? "CONFIGURED" : (response?.anonKey ?? "MISSING")),
        sqlTableHelp: response?.sqlTableHelp || `-- 1. CREATE USER TABLE SCRIPT
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone_code TEXT,
  phone_no TEXT,
  password TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. RESOLVE ROW-LEVEL SECURITY (RLS) ERROR
-- If using SUPABASE_ANON_KEY, you must either disable RLS or add policies:

-- OPTION A: Disable RLS completely for testing/development (Easiest & Recommended)
ALTER TABLE users DISABLE ROW LEVEL SECURITY;

-- OPTION B: Keep RLS enabled but add public access policies
-- CREATE POLICY "Allow public insert" ON users FOR INSERT WITH CHECK (true);
-- CREATE POLICY "Allow public read" ON users FOR SELECT USING (true);`
      });
    } catch (err) {
      console.error("Error checking Supabase configuration status:", err);
    }
  }, []);

  useEffect(() => {
    checkConfigStatus();
  }, [checkConfigStatus]);

  // Handle Session Persistence on Mount
  useEffect(() => {
    const supabase = getSupabaseClient();
    if (!supabase) return;

    // Listen to Supabase auth state changes if client-side is configured
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event: string, session: any) => {
        if (session?.user) {
          const userPayload = {
            id: session.user.id,
            name: session.user.user_metadata?.name || session.user.email?.split("@")[0] || "Cognitive Pilot",
            email: session.user.email,
            phoneCode: session.user.user_metadata?.phoneCode || "+91",
            phoneNo: session.user.user_metadata?.phoneNo || "",
            createdAt: session.user.created_at || new Date().toISOString()
          };
          setCurrentUser(userPayload);
        } else if (event === "SIGNED_OUT") {
          setCurrentUser(null);
        }
      }
    );

    return () => {
      subscription?.unsubscribe();
    };
  }, [setCurrentUser]);

  /**
   * Register a new user
   */
  const signup = async (params: {
    name: string;
    email: string;
    phoneCode: string;
    phoneNo: string;
    password: string;
  }) => {
    setIsLoading(true);
    setError(null);
    try {
      const supabase = getSupabaseClient();
      
      if (supabase) {
        // Direct Client-Side Supabase Auth Signup
        const { data, error: signupError } = await supabase.auth.signUp({
          email: params.email,
          password: params.password,
          options: {
            data: {
              name: params.name,
              phoneCode: params.phoneCode,
              phoneNo: params.phoneNo
            }
          }
        });

        if (signupError) throw signupError;

        // Also insert into public users table if configured
        try {
          await supabase.from("users").insert([{
            id: data.user?.id || crypto.randomUUID(),
            name: params.name,
            email: params.email,
            phone_code: params.phoneCode,
            phone_no: params.phoneNo,
            password: params.password, // For simulation matching
            created_at: new Date().toISOString()
          }]);
        } catch (dbErr) {
          console.warn("Could not insert directly to users table, auth created:", dbErr);
        }

        addToast("Identity registered successfully via Supabase client.", "success");
        return { success: true, message: "Identity authorized via Supabase client. Please check your email to verify if required." };
      } else {
        // Fallback to our secure server-side API proxy
        const response = await api.signup(params);
        if (response.success) {
          if (response.warning) {
            addToast(response.message || "Cognitive identity logged locally with sync warning.", "info");
          } else {
            addToast(response.message || "Cognitive identity logged successfully.", "success");
          }
          return response;
        } else {
          throw new Error("Failed to register identity through mainframe proxy.");
        }
      }
    } catch (err: any) {
      const errMsg = err?.message || "Biometric credential registration failed.";
      setError(errMsg);
      addToast(errMsg, "error");
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Log in an existing user
   */
  const login = async (credentials: { email: string; password: string }) => {
    setIsLoading(true);
    setError(null);
    try {
      const supabase = getSupabaseClient();
      const userEmail = credentials.email.trim();
      
      if (supabase) {
        // Direct Client-Side Supabase Auth Login
        const { data, error: loginError } = await supabase.auth.signInWithPassword({
          email: credentials.email,
          password: credentials.password
        });

        if (loginError) throw loginError;

        if (data?.user) {
          const userPayload = {
            id: data.user.id,
            name: data.user.user_metadata?.name || data.user.email?.split("@")[0] || "Cognitive Pilot",
            email: data.user.email,
            phoneCode: data.user.user_metadata?.phoneCode || "+91",
            phoneNo: data.user.user_metadata?.phoneNo || "",
            createdAt: data.user.created_at || new Date().toISOString(),
            authSource: "supabase_client"
          };
          setCurrentUser(userPayload);
          addToast("Secure link established via client-side Supabase.", "success");
          
          // Send notification email and log telemetry
          if (userPayload.email) {
            api.sendLoginEmail(userPayload.email)
              .then((emailRes) => {
                if (emailRes.simulated) {
                  addToast(`📬 Simulated notification: "Login successful. Thank you to join." Sent to ${userPayload.email}`, "info");
                } else {
                  addToast(`📬 Live Email Dispatched: "Login successful. Thank you to join." Sent to ${userPayload.email}`, "success");
                }
              })
              .catch((emailErr) => {
                console.error("Email API failure:", emailErr);
                addToast(`📬 Simulated notification: "Login successful. Thank you to join." Sent to ${userPayload.email}`, "info");
              });
          }

          addRecentActivity(
            "Security Notification Sent",
            "system_event",
            `Welcome back dispatch secure-transmitted to ${userPayload.email}`
          );
          
          return { success: true, user: userPayload };
        }
        throw new Error("No user records returned.");
      } else {
        // Fallback to our secure server-side API proxy
        const response = await api.login(credentials);
        if (response.success && response.user) {
          setCurrentUser(response.user);
          addToast("Access granted. Mainframe neural connection synced.", "success");
          
          // Send notification email and log telemetry
          const finalEmail = response.user.email || userEmail;
          if (finalEmail) {
            api.sendLoginEmail(finalEmail)
              .then((emailRes) => {
                if (emailRes.simulated) {
                  addToast(`📬 Simulated notification: "Login successful. Thank you to join." Sent to ${finalEmail}`, "info");
                } else {
                  addToast(`📬 Live Email Dispatched: "Login successful. Thank you to join." Sent to ${finalEmail}`, "success");
                }
              })
              .catch((emailErr) => {
                console.error("Email API failure:", emailErr);
                addToast(`📬 Simulated notification: "Login successful. Thank you to join." Sent to ${finalEmail}`, "info");
              });
          }

          addRecentActivity(
            "Security Notification Sent",
            "system_event",
            `Welcome back dispatch secure-transmitted to ${finalEmail}`
          );
          
          return response;
        } else {
          throw new Error("Invalid authorization signature coordinates.");
        }
      }
    } catch (err: any) {
      const errMsg = err?.message || "Authentication credentials denied.";
      setError(errMsg);
      addToast(errMsg, "error");
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Terminate active cognitive session
   */
  const logout = async () => {
    setIsLoading(true);
    try {
      const supabase = getSupabaseClient();
      if (supabase) {
        await supabase.auth.signOut();
      }
      setCurrentUser(null);
      addToast("Mainframe link terminated successfully.", "info");
    } catch (err: any) {
      console.error("Error signing out:", err);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    currentUser,
    isLoading,
    error,
    supabaseStatus,
    signup,
    login,
    logout,
    checkSession: checkConfigStatus
  };
}
