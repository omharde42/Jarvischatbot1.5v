import { useState, useEffect } from "react";
import { 
  getAuth, 
  onAuthStateChanged, 
  signInWithPopup, 
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile,
  GoogleAuthProvider
} from "firebase/auth";
import { app, auth, db, googleProvider } from "../lib/firebase";
import { doc, getDoc, setDoc, collection, getDocs, deleteDoc, updateDoc } from "firebase/firestore";
import { useJarvisStore } from "../stores/jarvisStore";

export function useFirebaseAuth() {
  const { setCurrentUser, addToast, addRecentActivity } = useJarvisStore();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Synchronize state when auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setIsLoading(true);
      if (firebaseUser) {
        const userPayload = {
          id: firebaseUser.uid,
          name: firebaseUser.displayName || firebaseUser.email?.split("@")[0] || "Cognitive Pilot",
          email: firebaseUser.email,
          photoURL: firebaseUser.photoURL || "",
          createdAt: firebaseUser.metadata.creationTime || new Date().toISOString(),
          authSource: "firebase_auth"
        };
        
        setCurrentUser(userPayload);
        
        // Check if user document exists in Firestore, if not create it
        try {
          const userDocRef = doc(db, "users", firebaseUser.uid);
          const userDoc = await getDoc(userDocRef);
          
          if (!userDoc.exists()) {
            await setDoc(userDocRef, {
              uid: firebaseUser.uid,
              email: firebaseUser.email,
              displayName: firebaseUser.displayName || userPayload.name,
              photoURL: firebaseUser.photoURL || "",
              createdAt: new Date().toISOString()
            });
            console.log("[FIREBASE FIRESTORE] Created new user profile in Firestore");
          }
        } catch (dbErr) {
          console.error("[FIREBASE FIRESTORE ERROR] Syncing user profile:", dbErr);
        }
      } else {
        setCurrentUser(null);
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [setCurrentUser]);

  /**
   * Log in with Google Sign-In
   */
  const loginWithGoogle = async () => {
    setIsLoading(true);
    setError(null);
    try {
      console.log("[FIREBASE AUTH] Attempting Google Sign-In via popup");
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      
      const userPayload = {
        id: user.uid,
        name: user.displayName || user.email?.split("@")[0] || "Cognitive Pilot",
        email: user.email,
        photoURL: user.photoURL || "",
        createdAt: user.metadata.creationTime || new Date().toISOString(),
        authSource: "firebase_auth"
      };

      setCurrentUser(userPayload);
      addToast(`Access granted. Google profile linked for ${userPayload.name}.`, "success");
      addRecentActivity(
        "Google Auth Successful",
        "system_event",
        `Biometric link synced for account: ${userPayload.email}`
      );
      return { success: true, user: userPayload };
    } catch (err: any) {
      console.error("[FIREBASE AUTH ERROR] Google Sign-In failed:", err);
      let errMsg = err?.message || "Google Authentication failed.";
      if (err?.code === "auth/popup-blocked") {
        errMsg = "Google Sign-In popup was blocked by browser. Please open the app in a new tab or try Email/Password login.";
      } else if (err?.code === "auth/iframe-directory-access-denied") {
        errMsg = "Authentication denied within this preview frame. Please click 'Open in New Tab' above to sign in securely.";
      }
      setError(errMsg);
      addToast(errMsg, "error");
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Sign up with Email and Password
   */
  const signupWithEmail = async (params: {
    name: string;
    email: string;
    phoneCode: string;
    phoneNo: string;
    password: string;
  }) => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await createUserWithEmailAndPassword(auth, params.email, params.password);
      const user = result.user;
      
      // Update profile with name
      await updateProfile(user, { displayName: params.name });

      // Save user record to firestore
      const userDocRef = doc(db, "users", user.uid);
      await setDoc(userDocRef, {
        uid: user.uid,
        email: params.email,
        displayName: params.name,
        phoneCode: params.phoneCode,
        phoneNo: params.phoneNo,
        createdAt: new Date().toISOString()
      });

      const userPayload = {
        id: user.uid,
        name: params.name,
        email: params.email,
        phoneCode: params.phoneCode,
        phoneNo: params.phoneNo,
        createdAt: new Date().toISOString(),
        authSource: "firebase_auth"
      };

      setCurrentUser(userPayload);
      addToast("Biometric credential registered via Firebase Secure Auth.", "success");
      addRecentActivity(
        "Identity Registered",
        "system_event",
        `New authorized user profile created: ${userPayload.email}`
      );
      return { success: true, user: userPayload };
    } catch (err: any) {
      console.error("[FIREBASE AUTH ERROR] Sign up failed:", err);
      const errMsg = err?.message || "Biometric credential registration failed.";
      setError(errMsg);
      addToast(errMsg, "error");
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Log in with Email and Password
   */
  const loginWithEmail = async (credentials: { email: string; password: string }) => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await signInWithEmailAndPassword(auth, credentials.email, credentials.password);
      const user = result.user;
      
      const userPayload = {
        id: user.uid,
        name: user.displayName || user.email?.split("@")[0] || "Cognitive Pilot",
        email: user.email,
        createdAt: user.metadata.creationTime || new Date().toISOString(),
        authSource: "firebase_auth"
      };

      setCurrentUser(userPayload);
      addToast("Access granted. Firebase secure handshake synchronized.", "success");
      addRecentActivity(
        "Secure Handshake Synced",
        "system_event",
        `Session initiated for secure node: ${userPayload.email}`
      );
      return { success: true, user: userPayload };
    } catch (err: any) {
      console.error("[FIREBASE AUTH ERROR] Login failed:", err);
      const errMsg = err?.message || "Invalid authentication signature coordinates.";
      setError(errMsg);
      addToast(errMsg, "error");
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Sign out the active user session
   */
  const logout = async () => {
    setIsLoading(true);
    try {
      await signOut(auth);
      setCurrentUser(null);
      addToast("Mainframe link terminated successfully.", "info");
      addRecentActivity("Session Terminated", "system_event", "Secure terminal socket closed");
    } catch (err: any) {
      console.error("[FIREBASE AUTH ERROR] Log out failed:", err);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    error,
    loginWithGoogle,
    signupWithEmail,
    loginWithEmail,
    logout
  };
}
