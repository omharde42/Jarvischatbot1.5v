/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  Conversation, 
  Memory, 
  Task, 
  FileRecord, 
  SystemStatus, 
  AppSettings,
  WeatherData
} from "../types";

const API_BASE = ""; // Relative calls since backend and frontend are on same port 3000

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const headers = {
    "Content-Type": "application/json",
    ...(options?.headers || {}),
  };

  const response = await fetch(url, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => "Unknown error");
    throw new Error(`HTTP Error ${response.status}: ${errorText}`);
  }

  return response.json() as Promise<T>;
}

export const api = {
  // System Metrics
  getSystemStatus: () => request<SystemStatus>(`${API_BASE}/api/status`),
  runDiagnostics: () => request<{ report: string }>(`${API_BASE}/api/diagnostics/run`, { method: "POST" }),

  // Conversations (Chat)
  getConversations: () => request<Conversation[]>(`${API_BASE}/api/conversations`),
  createConversation: (title?: string) => 
    request<Conversation>(`${API_BASE}/api/conversations`, {
      method: "POST",
      body: JSON.stringify({ title }),
    }),
  deleteConversation: (id: string) => 
    request<{ success: boolean }>(`${API_BASE}/api/conversations/${id}`, {
      method: "DELETE",
    }),
  togglePinConversation: (id: string) => 
    request<Conversation>(`${API_BASE}/api/conversations/${id}/pin`, {
      method: "POST",
    }),
  sendChatMessage: (conversationId: string, message: string, image?: string | null, model?: string) => 
    request<{ reply: string; conversation: Conversation }>(`${API_BASE}/api/chat`, {
      method: "POST",
      body: JSON.stringify({ conversationId, message, image, model }),
    }),

  // Memory
  getMemories: () => request<Memory[]>(`${API_BASE}/api/memories`),
  createMemory: (content: string, category?: string, pinned?: boolean) => 
    request<Memory>(`${API_BASE}/api/memories`, {
      method: "POST",
      body: JSON.stringify({ content, category, pinned }),
    }),
  deleteMemory: (id: string) => 
    request<{ success: boolean }>(`${API_BASE}/api/memories/${id}`, {
      method: "DELETE",
    }),
  clearMemories: () => 
    request<{ success: boolean }>(`${API_BASE}/api/memories/clear`, {
      method: "POST",
    }),
  togglePinMemory: (id: string) => 
    request<Memory>(`${API_BASE}/api/memories/${id}/pin`, {
      method: "POST",
    }),

  // Tasks
  getTasks: () => request<Task[]>(`${API_BASE}/api/tasks`),
  createTask: (name: string, status?: string, progress?: number, logs?: string[], type?: string, priority?: string, deadline?: string, category?: string) => 
    request<Task>(`${API_BASE}/api/tasks`, {
      method: "POST",
      body: JSON.stringify({ name, status, progress, logs, type, priority, deadline, category }),
    }),
  triggerTaskAction: (id: string, action: "cancel" | "retry") => 
    request<Task>(`${API_BASE}/api/tasks/${id}/action`, {
      method: "POST",
      body: JSON.stringify({ action }),
    }),

  // Files
  getFiles: () => request<FileRecord[]>(`${API_BASE}/api/files`),
  uploadFile: (name: string, type: string, base64Data: string) => 
    request<FileRecord>(`${API_BASE}/api/files/upload`, {
      method: "POST",
      body: JSON.stringify({ name, type, data: base64Data }),
    }),
  deleteFile: (id: string) => 
    request<{ success: boolean }>(`${API_BASE}/api/files/${id}`, {
      method: "DELETE",
    }),

  // TTS
  synthesizeSpeech: (text: string, voice?: string) => 
    request<{ audio?: string; mimeType?: string; fallback?: boolean }>(`${API_BASE}/api/voice/tts`, {
      method: "POST",
      body: JSON.stringify({ text, voice }),
    }),

  // Vision
  analyzeVision: (image: string, prompt?: string) => 
    request<{ result: string; simulated?: boolean }>(`${API_BASE}/api/vision/analyze`, {
      method: "POST",
      body: JSON.stringify({ image, prompt }),
    }),

  // Audio transcription (Gemini 3.5-Flash)
  transcribeAudio: (base64Audio: string, mimeType?: string) =>
    request<{ text: string }>(`${API_BASE}/api/voice/transcribe`, {
      method: "POST",
      body: JSON.stringify({ audio: base64Audio, mimeType }),
    }),

  // Settings
  getSettings: () => request<AppSettings>(`${API_BASE}/api/settings`),
  saveSettings: (settings: AppSettings) => 
    request<{ success: boolean }>(`${API_BASE}/api/settings`, {
      method: "POST",
      body: JSON.stringify(settings),
    }),

  // Weather
  getWeather: (latitude?: number, longitude?: number, locationQuery?: string) =>
    request<WeatherData>(`${API_BASE}/api/weather`, {
      method: "POST",
      body: JSON.stringify({ latitude, longitude, locationQuery }),
    }),

  // Authentication Protocols
  getSupabaseStatus: () => 
    request<{ configured: boolean; url: string; anonKey: string; sqlTableHelp: string }>(`${API_BASE}/api/auth/supabase-status`),
  login: (credentials: any) =>
    request<{ success: boolean; user: any; authSource?: string }>(`${API_BASE}/api/auth/login`, {
      method: "POST",
      body: JSON.stringify(credentials),
    }),
  sendLoginEmail: (email: string) =>
    request<{ success: boolean; simulated?: boolean; message?: string }>(`${API_BASE}/api/auth/send-login-email`, {
      method: "POST",
      body: JSON.stringify({ email }),
    }),
  signup: (userData: any) =>
    request<{ success: boolean; message: string; warning?: boolean }>(`${API_BASE}/api/auth/signup`, {
      method: "POST",
      body: JSON.stringify(userData),
    }),
};
