import { db } from "../lib/firebase";
import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  getDocs, 
  deleteDoc, 
  query, 
  orderBy 
} from "firebase/firestore";
import { Conversation, Memory, Task, AppSettings } from "../types";

export const firestoreService = {
  /**
   * Fetch all conversations for a user
   */
  getConversations: async (userId: string): Promise<Conversation[]> => {
    try {
      const q = query(
        collection(db, "users", userId, "conversations"),
        orderBy("createdAt", "desc")
      );
      const querySnapshot = await getDocs(q);
      const list: Conversation[] = [];
      querySnapshot.forEach((doc) => {
        list.push(doc.data() as Conversation);
      });
      return list;
    } catch (e) {
      console.error("[FIRESTORE SERVICE] Error fetching conversations:", e);
      return [];
    }
  },

  /**
   * Save or update a conversation
   */
  saveConversation: async (userId: string, conversation: Conversation): Promise<void> => {
    try {
      const docRef = doc(db, "users", userId, "conversations", conversation.id);
      await setDoc(docRef, {
        ...conversation,
        createdAt: conversation.createdAt || new Date().toISOString()
      }, { merge: true });
    } catch (e) {
      console.error("[FIRESTORE SERVICE] Error saving conversation:", e);
    }
  },

  /**
   * Delete a conversation
   */
  deleteConversation: async (userId: string, conversationId: string): Promise<void> => {
    try {
      const docRef = doc(db, "users", userId, "conversations", conversationId);
      await deleteDoc(docRef);
    } catch (e) {
      console.error("[FIRESTORE SERVICE] Error deleting conversation:", e);
    }
  },

  /**
   * Fetch all tasks for a user
   */
  getTasks: async (userId: string): Promise<Task[]> => {
    try {
      const q = query(
        collection(db, "users", userId, "tasks"),
        orderBy("timestamp", "desc")
      );
      const querySnapshot = await getDocs(q);
      const list: Task[] = [];
      querySnapshot.forEach((doc) => {
        list.push(doc.data() as Task);
      });
      return list;
    } catch (e) {
      console.error("[FIRESTORE SERVICE] Error fetching tasks:", e);
      return [];
    }
  },

  /**
   * Save or update a task
   */
  saveTask: async (userId: string, task: Task): Promise<void> => {
    try {
      const docRef = doc(db, "users", userId, "tasks", task.id);
      await setDoc(docRef, task, { merge: true });
    } catch (e) {
      console.error("[FIRESTORE SERVICE] Error saving task:", e);
    }
  },

  /**
   * Delete or clear tasks
   */
  deleteTask: async (userId: string, taskId: string): Promise<void> => {
    try {
      const docRef = doc(db, "users", userId, "tasks", taskId);
      await deleteDoc(docRef);
    } catch (e) {
      console.error("[FIRESTORE SERVICE] Error deleting task:", e);
    }
  },

  /**
   * Fetch all memories for a user
   */
  getMemories: async (userId: string): Promise<Memory[]> => {
    try {
      const q = query(
        collection(db, "users", userId, "memories"),
        orderBy("date", "desc")
      );
      const querySnapshot = await getDocs(q);
      const list: Memory[] = [];
      querySnapshot.forEach((doc) => {
        list.push(doc.data() as Memory);
      });
      return list;
    } catch (e) {
      console.error("[FIRESTORE SERVICE] Error fetching memories:", e);
      return [];
    }
  },

  /**
   * Save or update a memory
   */
  saveMemory: async (userId: string, memory: Memory): Promise<void> => {
    try {
      const docRef = doc(db, "users", userId, "memories", memory.id);
      await setDoc(docRef, memory, { merge: true });
    } catch (e) {
      console.error("[FIRESTORE SERVICE] Error saving memory:", e);
    }
  },

  /**
   * Delete a memory
   */
  deleteMemory: async (userId: string, memoryId: string): Promise<void> => {
    try {
      const docRef = doc(db, "users", userId, "memories", memoryId);
      await deleteDoc(docRef);
    } catch (e) {
      console.error("[FIRESTORE SERVICE] Error deleting memory:", e);
    }
  },

  /**
   * Clear all memories for a user
   */
  clearAllMemories: async (userId: string): Promise<void> => {
    try {
      const q = collection(db, "users", userId, "memories");
      const querySnapshot = await getDocs(q);
      querySnapshot.forEach(async (docSnap) => {
        await deleteDoc(doc(db, "users", userId, "memories", docSnap.id));
      });
    } catch (e) {
      console.error("[FIRESTORE SERVICE] Error clearing memories:", e);
    }
  },

  /**
   * Fetch app settings for a user
   */
  getSettings: async (userId: string): Promise<AppSettings | null> => {
    try {
      const docRef = doc(db, "users", userId, "settings", "core_settings");
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return docSnap.data() as AppSettings;
      }
      return null;
    } catch (e) {
      console.error("[FIRESTORE SERVICE] Error fetching settings:", e);
      return null;
    }
  },

  /**
   * Save app settings
   */
  saveSettings: async (userId: string, settings: AppSettings): Promise<void> => {
    try {
      const docRef = doc(db, "users", userId, "settings", "core_settings");
      await setDoc(docRef, settings, { merge: true });
    } catch (e) {
      console.error("[FIRESTORE SERVICE] Error saving settings:", e);
    }
  }
};
