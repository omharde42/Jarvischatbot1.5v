/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useRef } from "react";
import { motion } from "motion/react";
import { useJarvisStore } from "./stores/jarvisStore";
import { 
  MessageSquare, 
  Brain, 
  Cpu, 
  Download,
  Copy,
  Check,
  HardDrive, 
  Settings as SettingsIcon,
  Wifi, 
  Battery, 
  BatteryCharging,
  Mic, 
  Camera, 
  StopCircle, 
  Volume2, 
  VolumeX, 
  ShieldCheck, 
  ExternalLink,
  RefreshCw,
  Search,
  Video,
  Activity,
  AlertCircle,
  User,
  Smartphone,
  Monitor,
  Eye,
  Sparkles
} from "lucide-react";
import AICore from "./components/AICore";
import ChatTab from "./components/ChatTab";
import MemoryTab from "./components/MemoryTab";
import TasksTab from "./components/TasksTab";
import FilesTab from "./components/FilesTab";
import SettingsTab from "./components/SettingsTab";
import VisionTab from "./components/VisionTab";
import CompanionTab from "./components/CompanionTab";
import ToastNotification from "./components/ToastNotification";
import MarkdownRenderer from "./components/MarkdownRenderer";
import GlobalSearch from "./components/GlobalSearch";
import { EnvironmentalCard } from "./components/EnvironmentalCard";
import AuthScreen from "./components/AuthScreen";
import LandingPage from "./components/LandingPage";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 15 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      type: "spring",
      stiffness: 120,
      damping: 15,
    },
  },
};

export default function App() {
  const {
    activeTab,
    setTab,
    systemStatus,
    metricsHistory,
    fetchSystemStatus,
    fetchSettings,
    fetchConversations,
    settings,
    isListening,
    startListening,
    stopListening,
    isSpeaking,
    stopSpeaking,
    speakText,
    capturedImage,
    setCapturedImage,
    analyzeCapturedImage,
    visionAnalysis,
    visionLoading,
    sendMessage,
    tasks,
    addToast,
    diagnosticsReport,
    diagnosticsLoading,
    runDiagnostics,
    clearDiagnosticsReport,
    isFullScreenChat,
    setFullScreenChat,
    tabSyncLoading,
    addRecentActivity,
    recentActivities,
    batteryLevel,
    batteryCharging,
    batterySupported,
    setBatteryInfo,
    currentUser,
    setCurrentUser
  } = useJarvisStore();

  const [currentTime, setCurrentTime] = useState<string>("");
  const [currentDate, setCurrentDate] = useState<string>("");
  const [showCameraStream, setShowCameraStream] = useState(false);
  const [customPortalUrl, setCustomPortalUrl] = useState("");
  const [hasInitiatedSession, setHasInitiatedSession] = useState(false);
  const [copiedReport, setCopiedReport] = useState(false);

  // Dynamic peak amplification for isSpeaking voice wave animation
  const [peakAmplitudes, setPeakAmplitudes] = useState<number[]>([1, 1, 1, 1, 1, 1, 1]);

  const [listeningSeconds, setListeningSeconds] = useState(0);

  useEffect(() => {
    if (!isListening) {
      setListeningSeconds(0);
      return;
    }

    const interval = setInterval(() => {
      setListeningSeconds((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [isListening]);

  // System-wide keyboard shortcut listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Toggle microphone: Ctrl + Space
      if (e.ctrlKey && e.code === "Space") {
        e.preventDefault();
        if (isListening) {
          stopListening();
          addToast("Microphone deactivated via keyboard shortcut", "info");
        } else {
          startListening();
          addToast("Microphone activated via keyboard shortcut", "success");
        }
      }

      // Run Diagnostics: Ctrl + Shift + D
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "d") {
        e.preventDefault();
        runDiagnostics();
        addToast("System diagnostics sweep initiated via keyboard shortcut", "warning");
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isListening, startListening, stopListening, runDiagnostics, addToast]);

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, "0");
    const s = (secs % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  useEffect(() => {
    if (!isSpeaking) {
      setPeakAmplitudes([1, 1, 1, 1, 1, 1, 1]);
      return;
    }

    const interval = setInterval(() => {
      setPeakAmplitudes(
        Array.from({ length: 7 }, () => {
          const rand = Math.random();
          if (rand > 0.75) {
            // Peak detected: Amplify up to 1.8x
            return 1.4 + Math.random() * 0.4;
          } else if (rand < 0.2) {
            // Low valley
            return 0.4 + Math.random() * 0.3;
          }
          // Normal fluctuation
          return 0.8 + Math.random() * 0.4;
        })
      );
    }, 120);

    return () => clearInterval(interval);
  }, [isSpeaking]);

  useEffect(() => {
    let batteryObj: any = null;

    const updateBatteryInfo = (b: any) => {
      setBatteryInfo(Math.round(b.level * 100), b.charging, true);
    };

    const handleLevelChange = () => {
      if (batteryObj) {
        const lvl = Math.round(batteryObj.level * 100);
        setBatteryInfo(lvl, batteryObj.charging, true);
        addRecentActivity(
          "Auxiliary Power Level Updated",
          "system_event",
          `Device battery reserve updated to ${lvl}%`
        );
      }
    };

    const handleChargingChange = () => {
      if (batteryObj) {
        const lvl = Math.round(batteryObj.level * 100);
        setBatteryInfo(lvl, batteryObj.charging, true);
        addRecentActivity(
          batteryObj.charging ? "Battery Charging" : "Battery Discharging",
          "system_event",
          batteryObj.charging ? "Power source connected to ARC reactor" : "Main power source disconnected"
        );
      }
    };

    const nav = navigator as any;
    if (nav.getBattery) {
      nav.getBattery().then((battery: any) => {
        batteryObj = battery;
        updateBatteryInfo(battery);
        
        battery.addEventListener("levelchange", handleLevelChange);
        battery.addEventListener("chargingchange", handleChargingChange);
      }).catch((err: any) => {
        console.warn("Battery Status API check failed:", err);
        setBatteryInfo(null, false, false);
      });
    } else {
      setBatteryInfo(null, false, false);
    }

    return () => {
      if (batteryObj) {
        batteryObj.removeEventListener("levelchange", handleLevelChange);
        batteryObj.removeEventListener("chargingchange", handleChargingChange);
      }
    };
  }, [setBatteryInfo]);

  const resolvedMode = React.useMemo(() => {
    const m = settings?.appearance?.mode || "dark";
    if (m === "system") {
      if (typeof window !== "undefined" && window.matchMedia) {
        return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      }
      return "dark";
    }
    return m;
  }, [settings?.appearance?.mode]);

  const isLight = resolvedMode === "light";
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const handleLaunchPortal = (name: string, url: string) => {
    let targetUrl = url.trim();
    if (!targetUrl) return;
    if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
      targetUrl = "https://" + targetUrl;
    }
    try {
      window.open(targetUrl, "_blank");
    } catch (e) {
      console.warn("Popup blocked or failed:", e);
    }
    addToast(`Secure portal connection established to ${name || targetUrl}.`, "success");
  };

  useEffect(() => {
    // Initial fetch
    fetchSettings();
    fetchConversations();
  }, [currentUser]);

  useEffect(() => {
    // Timers
    const timeInterval = setInterval(() => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour12: false }));
      setCurrentDate(now.toLocaleDateString([], { weekday: "short", month: "short", day: "2-digit", year: "numeric" }));
    }, 1000);

    return () => {
      clearInterval(timeInterval);
    };
  }, []);

  // Dynamic metrics updates based on ARC Power Save status
  useEffect(() => {
    const isPowerSaveActive = settings?.appearance?.powerSaveMode && batteryLevel !== null && batteryLevel < 15;
    const intervalDuration = isPowerSaveActive ? 16000 : 4000; // 16s under power save, 4s normally

    // Fetch immediately on config change
    fetchSystemStatus();

    const metricsInterval = setInterval(() => {
      fetchSystemStatus();
    }, intervalDuration);

    return () => {
      clearInterval(metricsInterval);
    };
  }, [fetchSystemStatus, settings?.appearance?.powerSaveMode, batteryLevel]);

  // Support Escape key to close the diagnostics modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        clearDiagnosticsReport();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [clearDiagnosticsReport]);

  // Real Acoustical Clap Detection
  useEffect(() => {
    const isClapWakeEnabled = settings?.systemControl?.enabled && settings?.systemControl?.wakeTriggers?.clap;
    if (!isClapWakeEnabled) return;

    let audioContext: AudioContext | null = null;
    let microphone: MediaStreamAudioSourceNode | null = null;
    let processor: ScriptProcessorNode | null = null;
    let localStream: MediaStream | null = null;

    const initClapDetection = async () => {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return;
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        localStream = stream;
        
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        audioContext = new AudioContextClass();
        microphone = audioContext.createMediaStreamSource(stream);
        
        processor = audioContext.createScriptProcessor(2048, 1, 1);
        
        let lastPeakTime = 0;
        const sensitivity = settings?.systemControl?.clapSensitivity ?? 50;
        // Map sensitivity directly: higher sensitivity = lower peak threshold
        const threshold = 0.95 - (sensitivity / 100) * 0.8;

        processor.onaudioprocess = (e) => {
          const inputData = e.inputBuffer.getChannelData(0);
          let maxVal = 0;
          for (let i = 0; i < inputData.length; i++) {
            const val = Math.abs(inputData[i]);
            if (val > maxVal) maxVal = val;
          }

          if (maxVal > threshold) {
            const now = Date.now();
            if (now - lastPeakTime > 400) {
              lastPeakTime = now;
              console.log("[Acoustic Pulse] Peak amplitude spike detected:", maxVal);
              
              if (!isListening) {
                addToast("Acoustic wake signal detected! Booting JARVIS...", "success");
                startListening();
              }
            }
          }
        };

        microphone.connect(processor);
        processor.connect(audioContext.destination);
      } catch (err) {
        console.warn("Acoustic microphone access blocked or unsuited for clap wake:", err);
      }
    };

    initClapDetection();

    return () => {
      try {
        if (processor) processor.disconnect();
        if (microphone) microphone.disconnect();
        if (audioContext && audioContext.state !== "closed") audioContext.close();
        if (localStream) localStream.getTracks().forEach(t => t.stop());
      } catch (e) {
        console.error("Error tearing down clap audio nodes:", e);
      }
    };
  }, [settings?.systemControl?.enabled, settings?.systemControl?.wakeTriggers?.clap, settings?.systemControl?.clapSensitivity, isListening]);

  // Continuous Wake-Word Sentinel ("JARVIS")
  useEffect(() => {
    const isNameWakeEnabled = settings?.systemControl?.enabled && settings?.systemControl?.wakeTriggers?.nameWake;
    if (!isNameWakeEnabled || isListening) return;

    let sentinelRecognition: any = null;
    let isActive = true;

    const startSentinel = () => {
      if (!isActive) return;
      try {
        if (typeof window !== "undefined" && ("webkitSpeechRecognition" in window || "SpeechRecognition" in window)) {
          const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
          sentinelRecognition = new SpeechRecognition();
          sentinelRecognition.continuous = false;
          sentinelRecognition.interimResults = false;
          sentinelRecognition.lang = "en-US";

          sentinelRecognition.onresult = (event: any) => {
            const transcript = event.results[0][0].transcript.toLowerCase();
            console.log("[Sentinel Grid] Heard:", transcript);
            
            if (transcript.includes("jarvis") || transcript.includes("wake up") || transcript.includes("omega core")) {
              addToast("Neural Link wake-word match: JARVIS activated!", "success");
              speakText("Awaiting your command, Sir.");
              startListening();
            }
          };

          sentinelRecognition.onend = () => {
            if (isActive && !isListening) {
              setTimeout(startSentinel, 1000);
            }
          };

          sentinelRecognition.onerror = (e: any) => {
            if (e.error !== "no-speech") {
              console.warn("[Sentinel Grid] Speech recognition warning:", e.error);
            }
          };

          sentinelRecognition.start();
        }
      } catch (err) {
        console.warn("[Sentinel Grid] Web Speech API continuous Sentinel blocked:", err);
      }
    };

    const timer = setTimeout(startSentinel, 2000);

    return () => {
      isActive = false;
      clearTimeout(timer);
      try {
        if (sentinelRecognition) {
          sentinelRecognition.onend = null;
          sentinelRecognition.abort();
        }
      } catch (e) {
        console.error("Error stopping Sentinel recognition:", e);
      }
    };
  }, [settings?.systemControl?.enabled, settings?.systemControl?.wakeTriggers?.nameWake, isListening]);

  const handleDownloadReport = () => {
    if (!diagnosticsReport) return;
    const element = document.createElement("a");
    const file = new Blob([diagnosticsReport], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `jarvis_diagnostics_report_${Date.now()}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    addToast("Diagnostic report compiled and downloaded as plaintext log, Sir.", "success");
  };

  const handleCopyReport = async () => {
    if (!diagnosticsReport) return;
    try {
      await navigator.clipboard.writeText(diagnosticsReport);
      setCopiedReport(true);
      addToast("Diagnostic report copied to clipboard, Sir.", "success");
      setTimeout(() => {
        setCopiedReport(false);
      }, 2000);
    } catch (err) {
      addToast("Failed to copy report to clipboard.", "error");
    }
  };

  // Web Camera Vision capture
  const handleStartCamera = async () => {
    setShowCameraStream(true);
    setCapturedImage(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      addRecentActivity("WebCam Accessed", "webcam_accessed", "Optic visual telemetry stream online");
    } catch (e) {
      console.error("Camera access failed:", e);
    }
  };

  const handleCaptureCamera = () => {
    const video = videoRef.current;
    if (!video) return;

    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const base64 = canvas.toDataURL("image/jpeg");
      setCapturedImage(base64);
      addRecentActivity("WebCam Captured", "webcam_accessed", "Visual screenshot payload stored in buffer");
      
      // Stop stream
      const stream = video.srcObject as MediaStream;
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      setShowCameraStream(false);
    }
  };

  const handleCloseCamera = () => {
    const video = videoRef.current;
    if (video) {
      const stream = video.srcObject as MediaStream;
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    }
    setShowCameraStream(false);
  };

  // Simple quick visual sparkline charts for HUD with smooth motion interpolation
  const renderSparkline = (data: number[], color: string) => {
    if (data.length === 0) return null;
    const max = 100;
    const width = 140;
    const height = 30;
    const pathD = data.map((val, idx) => {
      const x = (idx / (data.length - 1)) * width;
      const y = height - (val / max) * height;
      return `${idx === 0 ? "M" : "L"} ${x} ${y}`;
    }).join(" ");

    const isPowerSaveActive = settings?.appearance?.powerSaveMode && batteryLevel !== null && batteryLevel < 15;

    return (
      <svg width={width} height={height} className="overflow-visible">
        <motion.path
          fill="none"
          stroke={color}
          strokeWidth="1.5"
          animate={{ d: pathD }}
          transition={
            isPowerSaveActive
              ? { duration: 0 }
              : { type: "spring", stiffness: 70, damping: 14, mass: 0.6 }
          }
          className="shadow-[0_0_10px_currentColor]"
        />
      </svg>
    );
  };

  const activeRunningTasks = tasks.filter(t => t.status === "running");

  if (!currentUser) {
    if (!hasInitiatedSession) {
      return <LandingPage onEnterProtocol={() => setHasInitiatedSession(true)} />;
    }
    return (
      <AuthScreen 
        onLoginSuccess={setCurrentUser} 
        onBackToLanding={() => setHasInitiatedSession(false)} 
      />
    );
  }

  return (
    <div
      id="jarvis_desktop_assistant"
      className={`min-h-screen ${
        isLight ? "bg-slate-50 text-slate-900" : "bg-[#03050b] text-slate-100"
      } flex flex-col font-sans relative scanline p-2 sm:p-4 overflow-visible xl:overflow-y-auto xl:overflow-hidden xl:h-screen ${
        isLight ? "light-cyber-grid" : "cyber-grid"
      } animate-fade-slide-up transition-colors duration-500`}
    >
      
      {/* Top Banner Telemetry HUD */}
      <header
        className={`flex flex-col sm:flex-row items-center justify-between px-4 py-2 ${
          isLight
            ? "bg-white/90 border-slate-300 shadow-md shadow-slate-200/50"
            : "bg-slate-950/80 border-cyan-500/20 shadow-lg shadow-cyan-950/20"
        } rounded-xl mb-4 backdrop-blur-md z-30 gap-2 transition-colors duration-500`}
      >
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 rounded-lg ${
            isLight ? "bg-cyan-50 border-cyan-500 text-cyan-600" : "bg-cyan-950/15 border-cyan-400 text-cyan-400"
          } border flex items-center justify-center font-display font-black text-lg shadow-[0_0_10px_rgba(34,211,238,0.3)] animate-pulse`}>
            J
          </div>
          <div>
            <h1 className={`font-display font-extrabold text-xs tracking-[0.25em] ${
              isLight ? "text-cyan-600" : "text-cyan-400"
            }`}>
              JARVIS AI // COGNITIVE CORE
            </h1>
            <p className="text-[9px] font-mono text-slate-500 tracking-wider">
              ONLINE INTEGRATED HOLOGRAPHIC ENVIRONMENT
            </p>
          </div>
        </div>

        {/* Global telemetry search utility */}
        <div className="flex-1 max-w-xs sm:max-w-sm md:max-w-md mx-2 sm:mx-4">
          <GlobalSearch isLight={resolvedMode === "light"} />
        </div>

        {/* HUD clock */}
        <div className="flex items-center gap-6 font-mono text-[10px]">
          <div className="text-right hidden md:block">
            <span className="text-slate-500">DATE:</span>{" "}
            <span className={isLight ? "text-slate-700" : "text-slate-300"}>{currentDate || "LOADING"}</span>
          </div>
          <div className="text-right">
            <span className="text-slate-500">COORDINATES:</span>{" "}
            <span className={`${isLight ? "text-cyan-600" : "text-cyan-400"} font-bold tracking-widest`}>{currentTime || "00:00:00"} UTC</span>
          </div>
          <div className={`flex items-center gap-1.5 px-2 py-0.5 border ${
            isLight ? "border-green-300 bg-green-50" : "border-cyan-500/10 bg-slate-900"
          } rounded`}>
            <ShieldCheck className="w-3.5 h-3.5 text-green-500" />
            <span className="text-green-500 font-bold uppercase text-[9px]">SECURE</span>
          </div>

          {currentUser && (
            <div className={`flex items-center gap-2 px-2 py-0.5 border ${
              isLight ? "border-slate-300 bg-slate-100" : "border-cyan-500/10 bg-slate-900"
            } rounded`}>
              <User className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span className={`font-bold uppercase text-[9px] max-w-[100px] truncate ${isLight ? "text-slate-700" : "text-cyan-200"}`}>
                PILOT: {currentUser.name}
              </span>
              <button
                onClick={() => {
                  setCurrentUser(null);
                  addToast("Biometric signature disconnected.", "info");
                }}
                className="text-rose-400 hover:text-rose-500 font-extrabold uppercase text-[9px] cursor-pointer ml-1 border-l border-cyan-500/20 pl-1.5 active:scale-95 transition-all"
                title="Disconnect Pilot"
              >
                OUT
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Main 3-Column Workspace Frame */}
      <main className="flex-1 grid grid-cols-1 xl:grid-cols-12 gap-4 overflow-visible xl:overflow-hidden relative min-h-0 z-10">
        
        {/* COLUMN 1: LEFT NAVIGATION RAIL */}
        {!isFullScreenChat && (
          <nav className={`xl:col-span-2 flex xl:flex-col gap-2 ${
            isLight ? "bg-white/80 border-slate-300/80 shadow-md shadow-slate-200/40" : "bg-slate-950/70 border-cyan-500/15 shadow-lg"
          } rounded-xl p-2 sm:p-2.5 backdrop-blur-sm justify-between sm:justify-start overflow-x-auto xl:overflow-x-visible xl:overflow-y-auto scrollbar-none transition-colors duration-500`}>
          <div className="w-full flex xl:flex-col gap-2 xl:space-y-1 overflow-visible scrollbar-none py-1.5 sm:py-0">
            <div className="hidden xl:block pb-2.5 border-b border-cyan-500/10 mb-2">
              <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Mainframe Nodes</span>
            </div>

            <button
              onClick={() => setTab("chat")}
              className={`w-auto xl:w-full flex-shrink-0 flex items-center gap-2.5 sm:gap-3 px-3 py-2 sm:py-2.5 rounded-lg border transition-all text-left cursor-pointer whitespace-nowrap ${
                activeTab === "chat"
                  ? isLight
                    ? "bg-cyan-100/50 border-cyan-400 text-cyan-700 shadow-[0_0_10px_rgba(6,182,212,0.15)]"
                    : "bg-cyan-950/20 border-cyan-500/50 text-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.15)]"
                  : isLight
                    ? "border-transparent hover:bg-slate-100/80 text-slate-500 hover:text-slate-800"
                    : "border-transparent hover:bg-slate-900/50 text-slate-400 hover:text-slate-200"
              }`}
            >
              <MessageSquare className="w-4 h-4 flex-shrink-0" />
              <span className="text-xs font-display font-medium tracking-wider uppercase">Chat Console</span>
            </button>

            <button
              onClick={() => setTab("memory")}
              className={`w-auto xl:w-full flex-shrink-0 flex items-center gap-2.5 sm:gap-3 px-3 py-2 sm:py-2.5 rounded-lg border transition-all text-left cursor-pointer whitespace-nowrap ${
                activeTab === "memory"
                  ? isLight
                    ? "bg-cyan-100/50 border-cyan-400 text-cyan-700 shadow-[0_0_10px_rgba(6,182,212,0.15)]"
                    : "bg-cyan-950/20 border-cyan-500/50 text-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.15)]"
                  : isLight
                    ? "border-transparent hover:bg-slate-100/80 text-slate-500 hover:text-slate-800"
                    : "border-transparent hover:bg-slate-900/50 text-slate-400 hover:text-slate-200"
              }`}
            >
              <Brain className="w-4 h-4 flex-shrink-0" />
              <span className="text-xs font-display font-medium tracking-wider uppercase">Memory Vault</span>
            </button>

            <button
              onClick={() => setTab("tasks")}
              className={`w-auto xl:w-full flex-shrink-0 flex items-center gap-2.5 sm:gap-3 px-3 py-2 sm:py-2.5 rounded-lg border transition-all text-left cursor-pointer whitespace-nowrap ${
                activeTab === "tasks"
                  ? isLight
                    ? "bg-cyan-100/50 border-cyan-400 text-cyan-700 shadow-[0_0_10px_rgba(6,182,212,0.15)]"
                    : "bg-cyan-950/20 border-cyan-500/50 text-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.15)]"
                  : isLight
                    ? "border-transparent hover:bg-slate-100/80 text-slate-500 hover:text-slate-800"
                    : "border-transparent hover:bg-slate-900/50 text-slate-400 hover:text-slate-200"
              }`}
            >
              <Cpu className="w-4 h-4 flex-shrink-0" />
              <span className="text-xs font-display font-medium tracking-wider uppercase">Task Monitor</span>
            </button>

            <button
              onClick={() => setTab("files")}
              className={`w-auto xl:w-full flex-shrink-0 flex items-center gap-2.5 sm:gap-3 px-3 py-2 sm:py-2.5 rounded-lg border transition-all text-left cursor-pointer whitespace-nowrap ${
                activeTab === "files"
                  ? isLight
                    ? "bg-cyan-100/50 border-cyan-400 text-cyan-700 shadow-[0_0_10px_rgba(6,182,212,0.15)]"
                    : "bg-cyan-950/20 border-cyan-500/50 text-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.15)]"
                  : isLight
                    ? "border-transparent hover:bg-slate-100/80 text-slate-500 hover:text-slate-800"
                    : "border-transparent hover:bg-slate-900/50 text-slate-400 hover:text-slate-200"
              }`}
            >
              <HardDrive className="w-4 h-4 flex-shrink-0" />
              <span className="text-xs font-display font-medium tracking-wider uppercase">Filer Records</span>
            </button>

            <button
              onClick={() => setTab("vision")}
              className={`w-auto xl:w-full flex-shrink-0 flex items-center gap-2.5 sm:gap-3 px-3 py-2 sm:py-2.5 rounded-lg border transition-all text-left cursor-pointer whitespace-nowrap ${
                activeTab === "vision"
                  ? isLight
                    ? "bg-cyan-100/50 border-cyan-400 text-cyan-700 shadow-[0_0_10px_rgba(6,182,212,0.15)]"
                    : "bg-cyan-950/20 border-cyan-500/50 text-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.15)]"
                  : isLight
                    ? "border-transparent hover:bg-slate-100/80 text-slate-500 hover:text-slate-800"
                    : "border-transparent hover:bg-slate-900/50 text-slate-400 hover:text-slate-200"
              }`}
            >
              <Eye className="w-4 h-4 flex-shrink-0" />
              <span className="text-xs font-display font-medium tracking-wider uppercase">Vision Center</span>
            </button>

            <button
              onClick={() => setTab("companion")}
              className={`w-auto xl:w-full flex-shrink-0 flex items-center gap-2.5 sm:gap-3 px-3 py-2 sm:py-2.5 rounded-lg border transition-all text-left cursor-pointer whitespace-nowrap ${
                activeTab === "companion"
                  ? isLight
                    ? "bg-cyan-100/50 border-cyan-400 text-cyan-700 shadow-[0_0_10px_rgba(6,182,212,0.15)]"
                    : "bg-cyan-950/20 border-cyan-500/50 text-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.15)]"
                  : isLight
                    ? "border-transparent hover:bg-slate-100/80 text-slate-500 hover:text-slate-800"
                    : "border-transparent hover:bg-slate-900/50 text-slate-400 hover:text-slate-200"
              }`}
            >
              <Sparkles className="w-4 h-4 flex-shrink-0 text-cyan-400" />
              <span className="text-xs font-display font-medium tracking-wider uppercase">Companion Hub</span>
            </button>

            <button
              onClick={() => setTab("settings")}
              className={`w-auto xl:w-full flex-shrink-0 flex items-center gap-2.5 sm:gap-3 px-3 py-2 sm:py-2.5 rounded-lg border transition-all text-left cursor-pointer whitespace-nowrap ${
                activeTab === "settings"
                  ? isLight
                    ? "bg-cyan-100/50 border-cyan-400 text-cyan-700 shadow-[0_0_10px_rgba(6,182,212,0.15)]"
                    : "bg-cyan-950/20 border-cyan-500/50 text-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.15)]"
                  : isLight
                    ? "border-transparent hover:bg-slate-100/80 text-slate-500 hover:text-slate-800"
                    : "border-transparent hover:bg-slate-900/50 text-slate-400 hover:text-slate-200"
              }`}
            >
              <SettingsIcon className="w-4 h-4 flex-shrink-0" />
              <span className="text-xs font-display font-medium tracking-wider uppercase">Settings</span>
            </button>
          </div>

          {/* Quick Portal Launcher HUD */}
          <div className={`hidden xl:flex flex-col gap-3.5 mt-auto pt-4 border-t ${
            isLight ? "border-slate-300" : "border-cyan-500/15"
          }`}>
            <div className="space-y-1">
              <span className={`text-[9px] font-mono ${
                isLight ? "text-cyan-600" : "text-cyan-400"
              } uppercase tracking-widest block font-bold`}>SYSTEM PORTALS</span>
              <span className="text-[8px] font-mono text-slate-500 block">Launch external apps & web platforms</span>
            </div>

            {/* Quick Presets Grid */}
            <div className="grid grid-cols-2 gap-1.5">
              {[
                { name: "Google", url: "https://www.google.com" },
                { name: "GitHub", url: "https://www.github.com" },
                { name: "YouTube", url: "https://www.youtube.com" },
                { name: "Gemini", url: "https://gemini.google.com" }
              ].map((portal) => (
                <button
                  key={portal.name}
                  onClick={() => handleLaunchPortal(portal.name, portal.url)}
                  className={`px-2 py-1.5 text-[9px] font-mono border rounded transition-all text-center cursor-pointer flex items-center justify-center gap-1 ${
                    isLight
                      ? "border-slate-300 hover:border-cyan-500 bg-white hover:bg-cyan-50 text-slate-600 hover:text-cyan-600"
                      : "border-cyan-500/10 hover:border-cyan-400 hover:bg-cyan-500/5 text-slate-400 hover:text-cyan-300"
                  }`}
                >
                  <ExternalLink className="w-2.5 h-2.5" />
                  {portal.name}
                </button>
              ))}
            </div>

            {/* Custom URL Launcher Input */}
            <div className="space-y-1.5">
              <input
                type="text"
                value={customPortalUrl}
                onChange={(e) => setCustomPortalUrl(e.target.value)}
                placeholder="Enter custom URL..."
                className={`w-full rounded px-2 py-1 text-[10px] font-mono focus:outline-none transition-colors duration-200 ${
                  isLight
                    ? "bg-white border border-slate-300 focus:border-cyan-500 text-slate-800 placeholder-slate-400"
                    : "bg-slate-950/90 border border-cyan-500/10 focus:border-cyan-400 text-cyan-400 placeholder-slate-600"
                }`}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && customPortalUrl.trim()) {
                    handleLaunchPortal("", customPortalUrl);
                    setCustomPortalUrl("");
                  }
                }}
              />
              <button
                onClick={() => {
                  if (customPortalUrl.trim()) {
                    handleLaunchPortal("", customPortalUrl);
                    setCustomPortalUrl("");
                  }
                }}
                disabled={!customPortalUrl.trim()}
                className={`w-full py-1 text-[9px] font-mono border rounded transition-all disabled:opacity-30 disabled:pointer-events-none cursor-pointer uppercase tracking-wider font-extrabold ${
                  isLight
                    ? "border-cyan-500 bg-cyan-100 hover:bg-cyan-500 text-cyan-700 hover:text-white"
                    : "border-cyan-500 bg-cyan-950/20 hover:bg-cyan-400 hover:text-slate-950 text-cyan-400"
                }`}
              >
                OPEN PORTAL
              </button>
            </div>
          </div>
        </nav>
        )}

        {/* COLUMN 2: CENTER PANEL VIEW (Splits between holographic core on top, and active tab content below) */}
        <div className={`${isFullScreenChat ? "xl:col-span-12 xl:h-screen h-auto" : "xl:col-span-7 xl:h-full h-auto"} flex flex-col gap-4 overflow-y-auto min-h-0`}>
          
          {/* Top Half: Holographic Core Box */}
          {!isFullScreenChat && (
            <div className="h-[180px] sm:h-[240px] md:h-[280px] xl:h-[320px] flex-shrink-0 relative">
              <AICore />

              {/* Quick action bar floaters over core */}
              <div className="absolute bottom-4 right-4 flex items-center gap-2">
                {/* Reactive Visual Wave representing voice output frequency (synchronizes with isSpeaking state) */}
                <div 
                  className={`flex items-end gap-1 px-3 py-1.5 rounded-xl border h-[38px] transition-all duration-500 overflow-hidden backdrop-blur-md ${
                    isSpeaking 
                      ? isLight
                        ? "w-[96px] opacity-100 border-cyan-300 bg-cyan-50/90 shadow-[0_0_12px_rgba(6,182,212,0.2)]"
                        : "w-[96px] opacity-100 border-cyan-500/40 bg-slate-950/90 shadow-[0_0_18px_rgba(6,182,212,0.3)]"
                      : "w-0 px-0 border-transparent bg-transparent opacity-0 pointer-events-none"
                  }`}
                  title="JARVIS Synthesizer Voice Output Frequency"
                >
                  <div className="flex items-end gap-1 h-5 w-full justify-center">
                    {[12, 20, 15, 25, 8, 18, 11].map((h, i) => {
                      const delay = `${i * 0.1}s`;
                      const duration = `${0.45 + (i % 4) * 0.12}s`;
                      const amp = peakAmplitudes[i] ?? 1;
                      const finalHeight = Math.min(28, Math.max(3, Math.round(h * amp)));
                      return (
                        <span
                          key={i}
                          className={`w-0.75 rounded-full origin-bottom transition-all duration-150 ${
                            isLight ? "bg-cyan-500" : "bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.6)]"
                          }`}
                          style={{
                            height: `${finalHeight}px`,
                            animation: `voiceWave ${duration} ease-in-out infinite alternate`,
                            animationDelay: delay,
                          }}
                        />
                      );
                    })}
                  </div>
                </div>

                <button
                  onClick={handleStartCamera}
                  className="p-2.5 rounded-xl border border-cyan-500/35 hover:border-cyan-400 bg-slate-950/80 text-cyan-400 hover:scale-105 transition-all cursor-pointer shadow-lg"
                  title="Initiate Real-Time Visual Scanner Feed"
                >
                  <Camera className="w-4 h-4 animate-pulse" />
                </button>

                {isListening && (
                  <div 
                    className={`px-3 py-2 rounded-xl border font-mono text-[10px] flex items-center gap-1.5 animate-pulse transition-all backdrop-blur-md shadow-lg ${
                      isLight 
                        ? "border-red-300 bg-red-50/90 text-red-600"
                        : "border-red-500/40 bg-slate-950/90 text-red-400 shadow-[0_0_12px_rgba(239,68,68,0.2)]"
                    }`}
                    title="Active Listening Session Length"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                    <span className="font-bold tracking-wider">{formatDuration(listeningSeconds)}</span>
                  </div>
                )}

                {isListening ? (
                  <button
                    onClick={stopListening}
                    className="px-3.5 py-2.5 rounded-xl border border-red-500/50 bg-red-950/20 text-red-400 hover:scale-105 transition-all cursor-pointer shadow-lg font-mono text-[10px] flex items-center gap-2 relative overflow-hidden"
                  >
                    <StopCircle className="w-4 h-4 animate-spin" />
                    <span>STOP MIC</span>
                  </button>
                ) : (
                  <button
                    onClick={startListening}
                    className={`px-3.5 py-2.5 rounded-xl border hover:scale-105 transition-all cursor-pointer shadow-lg font-mono text-[10px] flex items-center gap-2 relative overflow-hidden ${
                      isSpeaking
                        ? "border-cyan-400 bg-cyan-950/50 text-cyan-300 animate-pulse shadow-[0_0_12px_rgba(34,211,238,0.3)]"
                        : "border-cyan-500/50 bg-cyan-950/20 text-cyan-400"
                    }`}
                    title={isSpeaking ? "JARVIS Vocalizing (Click to Stop Speech)" : "Engage Acoustics Microphone Input"}
                  >
                    {isSpeaking ? (
                      <Volume2 className="w-4 h-4 text-cyan-300 animate-bounce" />
                    ) : (
                      <Mic className="w-4 h-4" />
                    )}
                    <span>{isSpeaking ? "VOCALIZING" : "ENGAGE MIC"}</span>
                    {isSpeaking && (
                      <span className="absolute inset-0 rounded-xl border border-cyan-400/30 animate-ping opacity-60 pointer-events-none" />
                    )}
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Bottom Half: Active Navigation Tab Body */}
          <div className="flex-1 min-h-0 relative">
            {tabSyncLoading ? (
              <div className={`w-full h-full min-h-[300px] flex flex-col items-center justify-center p-8 border rounded-2xl ${
                isLight 
                  ? "bg-white/80 border-slate-300 shadow-lg text-cyan-700" 
                  : "bg-slate-950/80 border-cyan-500/20 shadow-2xl text-cyan-400"
              } font-mono relative overflow-hidden backdrop-blur-md`}>
                {/* Cyber scanner bar */}
                <div className="absolute top-0 left-0 w-full h-1 bg-cyan-500/50 animate-pulse"></div>
                
                {/* Micro dots grid */}
                <div className="absolute inset-0 bg-[radial-gradient(#22d3ee_1px,transparent_1px)] [background-size:16px_16px] opacity-5"></div>
                
                <div className="relative flex flex-col items-center gap-4 text-center z-10">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full border-4 border-cyan-500/10 border-t-cyan-500 animate-spin"></div>
                    <Cpu className="w-6 h-6 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-cyan-400 animate-pulse" />
                  </div>
                  
                  <div className="space-y-1.5">
                    <h4 className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400 animate-pulse">
                      {activeTab === "chat" && "RESOLVING NEURAL CHANNELS..."}
                      {activeTab === "memory" && "DECRYPTING CORE VAULT..."}
                      {activeTab === "tasks" && "MAPPING PROCESS SECTORS..."}
                      {activeTab === "files" && "RECONSTITUTING FILE REGISTRY..."}
                      {activeTab === "vision" && "CALIBRATING OPTICAL ARRAYS..."}
                      {activeTab === "settings" && "LOADING PARAMETER SCHEMAS..."}
                      {activeTab === "companion" && "INTEGRATING COMPANION NODES..."}
                    </h4>
                    <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">
                      Connection Integrity: 100% // Syncing telemetry...
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <>
                {activeTab === "chat" && <ChatTab />}
                {activeTab === "memory" && <MemoryTab />}
                {activeTab === "tasks" && <TasksTab />}
                {activeTab === "files" && <FilesTab />}
                {activeTab === "settings" && <SettingsTab />}
                {activeTab === "vision" && <VisionTab />}
                {activeTab === "companion" && <CompanionTab />}
              </>
            )}
          </div>
        </div>

        {/* COLUMN 3: RIGHT SYSTEM MONITOR DIAGNOSTIC SIDEBAR */}
        {!isFullScreenChat && (
        <aside className={`xl:col-span-3 flex flex-col gap-4 ${
          isLight ? "bg-white/80 border-slate-300/80 shadow-md shadow-slate-200/40" : "bg-slate-950/70 border-cyan-500/15 shadow-lg"
        } rounded-xl p-4 backdrop-blur-sm overflow-y-auto scrollbar-thin transition-colors duration-500`}>
          <div className="border-b border-cyan-500/15 pb-2">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block mb-0.5">Core Diagnostics</span>
            <h3 className="font-display font-bold text-xs text-slate-200 tracking-wider">TELEMETRY MAINFRAME</h3>
            
            <button
              onClick={() => runDiagnostics()}
              disabled={diagnosticsLoading}
              className={`w-full mt-2.5 py-2 px-2 border rounded-lg text-[10px] font-display font-bold tracking-wider transition-all uppercase cursor-pointer flex items-center justify-center gap-2 ${
                diagnosticsLoading
                  ? "bg-cyan-950/20 border-cyan-500/20 text-cyan-600 animate-pulse cursor-not-allowed"
                  : "bg-cyan-500/10 border-cyan-500/40 hover:bg-cyan-500/20 text-cyan-400 hover:text-cyan-300 shadow-[0_0_8px_rgba(6,182,212,0.1)] hover:shadow-[0_0_12px_rgba(6,182,212,0.25)]"
              }`}
            >
              <Activity className={`w-3.5 h-3.5 ${diagnosticsLoading ? "animate-spin" : "animate-pulse text-cyan-400"}`} />
              {diagnosticsLoading ? "COMPILING SCAN..." : "RUN DIAGNOSTICS"}
            </button>
          </div>

          {/* Metrics grids with canvas charts */}
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="space-y-4"
          >
            
            {/* CPU Metric */}
            <motion.div variants={cardVariants} className="p-3 border border-cyan-500/5 bg-slate-950/50 rounded-xl space-y-1.5">
              <div className="flex justify-between items-center text-xs">
                <span className="font-mono text-slate-400 text-[10px]">CPU_LOAD</span>
                <span className="text-cyan-400 font-bold font-mono">{systemStatus?.serverMetrics.cpu || 15}%</span>
              </div>
              <div className="flex justify-center">
                {renderSparkline(metricsHistory.cpu, "rgb(34, 211, 238)")}
              </div>
            </motion.div>

            {/* RAM Metric */}
            <motion.div variants={cardVariants} className="p-3 border border-cyan-500/5 bg-slate-950/50 rounded-xl space-y-1.5">
              <div className="flex justify-between items-center text-xs">
                <span className="font-mono text-slate-400 text-[10px]">RAM_BUFFERS</span>
                <span className="text-purple-400 font-bold font-mono">{systemStatus?.serverMetrics.ram || 25}%</span>
              </div>
              <div className="flex justify-center">
                {renderSparkline(metricsHistory.ram, "rgb(168, 85, 247)")}
              </div>
            </motion.div>

            {/* GPU Metric */}
            <motion.div variants={cardVariants} className="p-3 border border-cyan-500/5 bg-slate-950/50 rounded-xl space-y-1.5">
              <div className="flex justify-between items-center text-xs">
                <span className="font-mono text-slate-400 text-[10px]">GPU_THERMALS</span>
                <span className="text-pink-400 font-bold font-mono">{systemStatus?.serverMetrics.gpu || 18}%</span>
              </div>
              <div className="flex justify-center">
                {renderSparkline(metricsHistory.gpu, "rgb(236, 72, 153)")}
              </div>
            </motion.div>

            {/* Quick gauges (battery, connection, subsystems) */}
            <motion.div variants={cardVariants} className="p-3 border border-cyan-500/5 bg-slate-950/50 rounded-xl space-y-2.5 font-mono text-[10px]">
              <div className="flex items-center justify-between border-b border-cyan-500/5 pb-1.5">
                <div className="flex items-center gap-1.5 text-slate-400">
                  {batteryCharging ? (
                    <BatteryCharging className="w-3.5 h-3.5 text-yellow-400 animate-pulse" />
                  ) : (
                    <Battery className={`w-3.5 h-3.5 ${batteryLevel !== null && batteryLevel < 20 ? 'text-rose-500 animate-bounce' : 'text-cyan-400'}`} />
                  )}
                  <span className="uppercase tracking-wider">
                    {batterySupported ? "DEVICE CORE POWER" : "ARC CORE RESERVES"}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  {batteryCharging && (
                    <span className="text-[7px] text-yellow-500 bg-yellow-950/20 px-1 border border-yellow-500/20 rounded mr-1">
                      CHARGING
                    </span>
                  )}
                  <span className={`${batteryLevel !== null && batteryLevel < 20 ? 'text-rose-500 font-bold' : 'text-cyan-400 font-bold'}`}>
                    {batteryLevel !== null ? `${batteryLevel}%` : `${systemStatus?.serverMetrics.battery || 100}%`}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between border-b border-cyan-500/5 pb-1.5">
                <div className="flex items-center gap-1.5 text-slate-400">
                  <Wifi className="w-3.5 h-3.5 text-cyan-400" />
                  <span>SAT_COUPLING</span>
                </div>
                <span className="text-green-400">STABLE (867M)</span>
              </div>

              {/* Subsystems integrity */}
              <div className="space-y-1 pt-1.5">
                <span className="text-[8px] text-slate-500 block uppercase tracking-widest mb-1">Grid Integrities</span>
                <div className="grid grid-cols-2 gap-2 text-[9px]">
                  <div className="flex items-center justify-between px-2 py-1 bg-slate-950 rounded border border-cyan-500/5">
                    <span className="text-slate-500">HOLOS:</span>
                    <span className="text-green-400 font-semibold">{systemStatus?.diagnostics.subsystems.hologrid || "ONLINE"}</span>
                  </div>
                  <div className="flex items-center justify-between px-2 py-1 bg-slate-950 rounded border border-cyan-500/5">
                    <span className="text-slate-500">REACTR:</span>
                    <span className="text-green-400 font-semibold">{systemStatus?.diagnostics.subsystems.arcCore || "STABLE"}</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Omega Neural Link status and Simulator */}
            <motion.div variants={cardVariants} className={`p-3 border rounded-xl space-y-2.5 transition-all ${
              settings?.systemControl?.enabled 
                ? "border-cyan-500/20 bg-cyan-950/5 shadow-[inset_0_0_12px_rgba(6,182,212,0.05)]" 
                : "border-slate-800 bg-slate-950/40"
            }`}>
              <div className="flex items-center justify-between border-b border-cyan-500/10 pb-1.5">
                <div className="flex items-center gap-1.5">
                  <Smartphone className={`w-3.5 h-3.5 ${settings?.systemControl?.enabled ? "text-cyan-400 animate-pulse" : "text-slate-500"}`} />
                  <span className="text-[9px] font-mono font-bold text-slate-300 uppercase tracking-widest">Omega Neural Link</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    settings?.systemControl?.enabled ? "bg-green-400 animate-ping" : "bg-rose-500"
                  }`}></span>
                  <span className={`text-[8px] font-mono uppercase font-bold ${
                    settings?.systemControl?.enabled ? "text-green-400" : "text-rose-500"
                  }`}>
                    {settings?.systemControl?.enabled ? "ACTIVE" : "STANDBY"}
                  </span>
                </div>
              </div>

              <div className="font-mono text-[9px] space-y-1.5 text-slate-400">
                <div className="flex justify-between">
                  <span>CONTROL PRIVILEGE:</span>
                  <span className={settings?.systemControl?.enabled ? "text-green-400 font-bold" : "text-slate-500"}>
                    {settings?.systemControl?.enabled ? "PERSISTENT" : "UNAUTHORIZED"}
                  </span>
                </div>
                {settings?.systemControl?.enabled && (
                  <>
                    <div className="flex justify-between">
                      <span>CONNECTED NODES:</span>
                      <span className="text-cyan-400 font-semibold uppercase">
                        {settings?.systemControl?.osType === "android" ? "Android Node" : 
                         settings?.systemControl?.osType === "windows" ? "Windows 11" : "Android & Windows"}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>ACTIVE TRIGGERS:</span>
                      <div className="flex gap-1 text-[7px]">
                        {settings.systemControl.wakeTriggers.oral && <span className="bg-cyan-500/15 text-cyan-400 border border-cyan-500/20 px-1 rounded uppercase">Oral</span>}
                        {settings.systemControl.wakeTriggers.nameWake && <span className="bg-cyan-500/15 text-cyan-400 border border-cyan-500/20 px-1 rounded uppercase">JARVIS</span>}
                        {settings.systemControl.wakeTriggers.clap && <span className="bg-purple-500/15 text-purple-400 border border-purple-500/20 px-1 rounded uppercase">Clap</span>}
                        {settings.systemControl.wakeTriggers.write && <span className="bg-cyan-500/15 text-cyan-400 border border-cyan-500/20 px-1 rounded uppercase">Written</span>}
                      </div>
                    </div>

                    <div className="pt-1.5 border-t border-cyan-500/5 flex items-center justify-between gap-2">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-[8px] text-slate-500 uppercase leading-none">Hands-free simulation</span>
                        <span className="text-[7px] text-slate-600 leading-none">Simulate wake triggers</span>
                      </div>
                      <div className="flex gap-1.5">
                        {settings.systemControl.wakeTriggers.clap && (
                          <button
                            onClick={() => {
                              addToast("Simulating sudden high-decibel acoustical clap spike...", "info");
                              speakText("Acoustic wake-signal detected, Sir. Initializing speech processor.");
                              startListening();
                            }}
                            className="bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 hover:text-purple-300 border border-purple-500/30 text-[8px] font-bold px-2 py-1 rounded tracking-wider transition-colors cursor-pointer"
                          >
                            🔊 Sim Double-Clap
                          </button>
                        )}
                        {settings.systemControl.wakeTriggers.nameWake && (
                          <button
                            onClick={() => {
                              addToast("Transmitting vocal wake-word: 'JARVIS'", "info");
                              speakText("Indeed, Sir. What can I do for you?");
                              startListening();
                            }}
                            className="bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 hover:text-cyan-300 border border-cyan-500/30 text-[8px] font-bold px-2 py-1 rounded tracking-wider transition-colors cursor-pointer"
                          >
                            🎙️ Say 'JARVIS'
                          </button>
                        )}
                      </div>
                    </div>
                  </>
                )}
                {!settings?.systemControl?.enabled && (
                  <p className="text-[8px] text-slate-600 italic leading-relaxed">
                    Persistent system privilege and wake word listeners are offline. Synchronize the Omega Neural Link in System Settings tab, Sir.
                  </p>
                )}
              </div>
            </motion.div>

            {/* Running automation list in side panel */}
            <motion.div variants={cardVariants} className="p-3 border border-cyan-500/5 bg-slate-950/50 rounded-xl space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">Running Queue</span>
                <span className="w-2 h-2 bg-cyan-400 rounded-full animate-ping"></span>
              </div>
              
              <div className="space-y-1.5 max-h-40 overflow-y-auto scrollbar-thin">
                {activeRunningTasks.length === 0 ? (
                  <div className="text-center py-4 font-mono text-[9px] text-slate-600">No active threads</div>
                ) : (
                  activeRunningTasks.map((t) => (
                    <div key={t.id} className="p-2 rounded bg-slate-950 border border-cyan-500/10 font-mono text-[9px] space-y-1">
                      <div className="flex justify-between text-slate-300">
                        <span className="truncate max-w-[120px]">{t.name}</span>
                        <span className="text-cyan-400">{t.progress}%</span>
                      </div>
                      <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden">
                        <div className="bg-cyan-400 h-full rounded-full transition-all duration-500" style={{ width: `${t.progress}%` }} />
                      </div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>

            {/* Environmental Data Card */}
            <motion.div variants={cardVariants}>
              <EnvironmentalCard />
            </motion.div>

            {/* Recent Activity Log Panel */}
            <motion.div variants={cardVariants} className="p-3 border border-cyan-500/5 bg-slate-950/50 rounded-xl space-y-2.5">
              <div className="flex items-center justify-between border-b border-cyan-500/10 pb-1.5">
                <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">Recent Activity</span>
                <span className="text-[8px] font-mono text-cyan-400 bg-cyan-950/30 px-1.5 py-0.5 border border-cyan-500/20 rounded">
                  LIVE TELEMETRY
                </span>
              </div>
              
              <div className="space-y-2 max-h-52 overflow-y-auto scrollbar-thin">
                {recentActivities.length === 0 ? (
                  <div className="text-center py-4 font-mono text-[9px] text-slate-600">No active logs</div>
                ) : (
                  recentActivities.map((act) => {
                    const getIcon = (type: string) => {
                      switch (type) {
                        case "task_started":
                          return <Cpu className="w-3 h-3 text-amber-400" />;
                        case "diagnostics_run":
                          return <Activity className="w-3 h-3 text-cyan-400" />;
                        case "webcam_accessed":
                          return <Camera className="w-3 h-3 text-pink-400" />;
                        case "file_action":
                          return <HardDrive className="w-3 h-3 text-purple-400" />;
                        default:
                          return <ShieldCheck className="w-3 h-3 text-green-400" />;
                      }
                    };

                    const timeStr = new Date(act.timestamp).toLocaleTimeString([], { 
                      hour: "2-digit", 
                      minute: "2-digit", 
                      second: "2-digit", 
                      hour12: false 
                    });

                    return (
                      <div key={act.id} className="p-1.5 rounded bg-slate-950/60 border border-cyan-500/5 hover:border-cyan-500/10 transition-colors flex gap-2 items-start font-mono text-[9px]">
                        <div className="flex-shrink-0 mt-0.5 w-5 h-5 rounded-md bg-slate-900 border border-cyan-500/10 flex items-center justify-center">
                          {getIcon(act.type)}
                        </div>
                        <div className="flex-1 min-w-0 space-y-0.5">
                          <div className="flex justify-between items-center text-slate-300">
                            <span className="font-semibold truncate text-[9px]">{act.event}</span>
                            <span className="text-slate-500 text-[8px] flex-shrink-0">{timeStr}</span>
                          </div>
                          {act.details && (
                            <p className="text-slate-500 text-[8px] leading-tight break-words">{act.details}</p>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </motion.div>

          </motion.div>
        </aside>
        )}
      </main>

      {/* Holographic Webcam Scan Overlay Modal */}
      {showCameraStream && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-slate-950 border border-cyan-400 rounded-2xl overflow-hidden flex flex-col shadow-2xl relative shadow-cyan-950/40">
            {/* Cyber scanline bar */}
            <div className="absolute inset-x-0 top-1/2 h-1 bg-cyan-400 shadow-[0_0_15px_#22d3ee] animate-[bounce_3s_infinite]" />

            {/* Header */}
            <div className="px-4 py-3 bg-slate-900 border-b border-cyan-500/20 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Video className="w-4 h-4 text-cyan-400 animate-pulse" />
                <span className="font-display text-xs font-semibold tracking-widest uppercase text-slate-200">JARVIS Telemetry Webcam Scan</span>
              </div>
              <button
                onClick={handleCloseCamera}
                className="p-1 rounded bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                ×
              </button>
            </div>

            {/* Video Feed */}
            <div className="relative bg-black flex justify-center items-center overflow-hidden aspect-video">
              <video ref={videoRef} className="w-full h-full object-cover" />
            </div>

            {/* Capture action bar */}
            <div className="p-4 bg-slate-900 border-t border-cyan-500/20 flex items-center justify-between gap-3">
              <span className="text-[10px] font-mono text-slate-400 uppercase">STATUS: SYSTEM READY</span>
              <div className="flex gap-2">
                <button
                  onClick={handleCloseCamera}
                  className="px-4 py-1.5 border border-red-500/30 hover:border-red-400 bg-red-950/15 text-red-400 font-display text-xs rounded-lg cursor-pointer"
                >
                  CANCEL SCAN
                </button>
                <button
                  onClick={handleCaptureCamera}
                  className="px-5 py-1.5 border border-cyan-400 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-display text-xs rounded-lg shadow-[0_0_10px_rgba(6,182,212,0.3)] cursor-pointer"
                >
                  SNAP TELEMETRY
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Captured Image Analysis floater */}
      {capturedImage && (
        <div className="fixed bottom-6 right-6 z-40 w-80 bg-slate-950 border border-cyan-400 rounded-xl overflow-hidden shadow-2xl flex flex-col p-3 animate-in fade-in slide-in-from-bottom-5 duration-250">
          <div className="flex justify-between items-center mb-2 border-b border-cyan-500/10 pb-1.5">
            <span className="font-display font-medium text-[10px] text-cyan-400 uppercase tracking-widest">Visual Analysis Queue</span>
            <button
              onClick={() => setCapturedImage(null)}
              className="text-slate-500 hover:text-white font-bold text-xs"
            >
              ×
            </button>
          </div>
          <img src={capturedImage} alt="telemetry scan" className="w-full h-32 object-cover rounded-lg border border-cyan-500/10 mb-2.5" />
          
          <button
            onClick={() => analyzeCapturedImage()}
            disabled={visionLoading}
            className="w-full py-1.5 border border-cyan-400 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-display text-xs rounded-lg transition-all"
          >
            {visionLoading ? "DECRYPTING SIGS..." : "ANALYZE SCREEN OVERLAY"}
          </button>

          {visionAnalysis && (
            <div className="mt-3 bg-black/40 border border-cyan-500/5 p-2 rounded max-h-32 overflow-y-auto scrollbar-thin text-[9px] font-mono text-cyan-400 leading-normal">
              {visionAnalysis}
            </div>
          )}
        </div>
      )}

      {/* Dynamic Toast System Overlay */}
      <ToastNotification />

      {/* System Diagnostics Report Modal */}
      {diagnosticsReport && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-2xl bg-slate-950 border border-cyan-400/50 rounded-2xl overflow-hidden flex flex-col shadow-2xl relative shadow-cyan-950/40 max-h-[85vh]">
            
            {/* Ambient top border decoration */}
            <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_12px_#22d3ee]" />

            {/* Header */}
            <div className="px-6 py-4 bg-slate-900 border-b border-cyan-500/20 flex items-center justify-between flex-shrink-0">
              <div className="flex items-center gap-2.5">
                <Activity className="w-4 h-4 text-cyan-400 animate-pulse" />
                <div>
                  <span className="font-display text-xs font-black tracking-[0.2em] uppercase text-slate-200 block">SYSTEM DIAGNOSTIC PROFILE</span>
                  <span className="text-[9px] font-mono text-slate-500 tracking-wider block">SECURE TELEMETRY DECRYPTION IN PROGRESS</span>
                </div>
              </div>
              <button
                onClick={() => clearDiagnosticsReport()}
                className="px-2.5 py-1 text-[9px] font-mono border border-cyan-500/20 hover:border-cyan-400 bg-slate-800/50 hover:bg-cyan-500/5 text-slate-400 hover:text-cyan-300 rounded transition-all text-center cursor-pointer flex items-center justify-center gap-1 uppercase"
                title="Acknowledge & Close"
              >
                ACKNOWLEDGE [ESC]
              </button>
            </div>

            {/* Scrollable Report Content */}
            <div className="p-6 overflow-y-auto scrollbar-thin flex-1 bg-slate-950/95 relative">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-cyan-950/15 via-transparent to-transparent pointer-events-none" />
              <div className="relative">
                <MarkdownRenderer content={diagnosticsReport} />
              </div>
            </div>

            {/* Footer with actions */}
            <div className="p-4 bg-slate-900 border-t border-cyan-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3 flex-shrink-0">
              <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">
                COMPILED BY JARVIS PROJECTION MATRIX v91.8
              </span>
              <div className="flex items-center gap-3">
                <button
                  onClick={handleCopyReport}
                  className="px-4 py-2 border border-cyan-500/40 hover:border-cyan-400 bg-cyan-950/20 hover:bg-cyan-900/20 text-cyan-400 font-bold font-display text-xs rounded-xl transition-all uppercase cursor-pointer flex items-center gap-1.5"
                  title="Copy diagnostic report to clipboard"
                >
                  {copiedReport ? (
                    <Check className="w-3.5 h-3.5 text-green-400 animate-pulse" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copiedReport ? "Copied!" : "Copy Report"}</span>
                </button>
                <button
                  onClick={handleDownloadReport}
                  className="px-4 py-2 border border-cyan-500/40 hover:border-cyan-400 bg-cyan-950/20 hover:bg-cyan-900/20 text-cyan-400 font-bold font-display text-xs rounded-xl transition-all uppercase cursor-pointer flex items-center gap-1.5"
                  title="Download report as plain text file"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Report</span>
                </button>
                <button
                  onClick={() => clearDiagnosticsReport()}
                  className="px-6 py-2 border border-cyan-400 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-display text-xs rounded-xl shadow-[0_0_12px_rgba(6,182,212,0.35)] transition-all uppercase cursor-pointer"
                >
                  ACKNOWLEDGE REPORT
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
