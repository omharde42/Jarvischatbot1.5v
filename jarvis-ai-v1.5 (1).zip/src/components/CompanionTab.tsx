import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useJarvisStore } from "../stores/jarvisStore";
import { classifyRequest, AgentCategory } from "../utils/agentClassifier";
import {
  Volume2,
  VolumeX,
  Activity,
  Cpu,
  Layers,
  Sparkles,
  Gamepad2,
  BookOpen,
  Terminal,
  Sliders,
  Monitor,
  Hand,
  Compass,
  Eye,
  Settings,
  Shield,
  Heart,
  Download,
  Trash2,
  Play,
  Pause,
  RotateCcw,
  Camera,
  Check,
  Package,
  RefreshCw,
  AlertCircle,
  Plus,
  Search,
  Maximize2,
  Mic,
  Info,
  Globe,
  Power,
  Volume1,
  MessageSquare
} from "lucide-react";

// Web Audio API Synthesizer Class for reliable sound synthesis
class WebAudioEngine {
  private ctx: AudioContext | null = null;
  private activeOscillators: { [key: string]: { oscs: OscillatorNode[]; gain: GainNode; noiseSource?: AudioBufferSourceNode } } = {};
  private currentAmbience: string | null = null;

  constructor() {
    // Initialized lazily upon first interaction
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume();
    }
    return this.ctx;
  }

  // Generate sci-fi chimes and signals
  public playSFX(type: "startup" | "shutdown" | "notification" | "success" | "warning" | "error") {
    const ctx = this.initCtx();
    if (!ctx) return;

    const dest = ctx.destination;
    const now = ctx.currentTime;

    if (type === "startup") {
      // Ascending premium arpeggio
      const frequencies = [130.81, 164.81, 196.0, 261.63, 329.63, 392.0, 523.25];
      frequencies.forEach((f, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(f, now + idx * 0.08);
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.08, now + idx * 0.08 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 0.4);
        osc.connect(gain);
        gain.connect(dest);
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.5);
      });
    } else if (type === "shutdown") {
      // Decreasing pitch slide
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(330, now);
      osc.frequency.exponentialRampToValueAtTime(55, now + 0.6);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.6);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(now);
      osc.stop(now + 0.65);
    } else if (type === "notification") {
      // Crisp digital bell
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      osc1.type = "sine";
      osc1.frequency.setValueAtTime(880, now);
      osc2.type = "sine";
      osc2.frequency.setValueAtTime(1318.51, now); // Overtones

      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.5);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(dest);
      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.6);
      osc2.stop(now + 0.6);
    } else if (type === "success") {
      // High rising chord
      const chords = [523.25, 659.25, 783.99, 1046.5];
      chords.forEach((f, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(f, now + idx * 0.05);
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.06, now + idx * 0.05 + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);
        osc.connect(gain);
        gain.connect(dest);
        osc.start(now + idx * 0.05);
        osc.stop(now + 0.45);
      });
    } else if (type === "warning") {
      // Pulsing alert chimes
      [0, 0.25, 0.5].forEach((delay) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(440, now + delay);
        
        // Lowpass filter for warm warning tone
        const filter = ctx.createBiquadFilter();
        filter.type = "lowpass";
        filter.frequency.setValueAtTime(800, now + delay);

        gain.gain.setValueAtTime(0, now + delay);
        gain.gain.linearRampToValueAtTime(0.07, now + delay + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + delay + 0.2);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(dest);
        osc.start(now + delay);
        osc.stop(now + delay + 0.25);
      });
    } else if (type === "error") {
      // Deep buzzer sound
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc1.type = "sawtooth";
      osc1.frequency.setValueAtTime(100, now);
      osc2.type = "sawtooth";
      osc2.frequency.setValueAtTime(101.5, now); // Detuned

      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(250, now);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);
      gain.connect(dest);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.5);
      osc2.stop(now + 0.5);
    }
  }

  // Create continuous loops using browser-synthesized audio nodes
  public startAmbience(type: "digital" | "focus" | "rain" | "space" | "library", volume: number = 0.5) {
    const ctx = this.initCtx();
    if (!ctx) return;

    this.stopAmbience();
    this.currentAmbience = type;

    const dest = ctx.destination;
    const now = ctx.currentTime;
    const mainGain = ctx.createGain();
    mainGain.gain.setValueAtTime(0, now);
    mainGain.gain.linearRampToValueAtTime(0.12 * volume, now + 1.5); // Smooth fade-in

    const oscs: OscillatorNode[] = [];
    let noiseSource: AudioBufferSourceNode | undefined;

    if (type === "space") {
      // Space ambience: Deep filtered sine/triangle waves with soft modulation (LFO)
      const carrier = ctx.createOscillator();
      carrier.type = "sine";
      carrier.frequency.setValueAtTime(55, now); // Low A

      const sub = ctx.createOscillator();
      sub.type = "triangle";
      sub.frequency.setValueAtTime(110, now); // Higher harmonic

      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(120, now);

      // Low Frequency Oscillator for subtle warm pulsing
      const lfo = ctx.createOscillator();
      lfo.frequency.setValueAtTime(0.15, now); // 0.15 Hz
      const lfoGain = ctx.createGain();
      lfoGain.gain.setValueAtTime(30, now); // modulate by 30Hz

      lfo.connect(lfoGain);
      lfoGain.connect(filter.frequency);
      
      carrier.connect(filter);
      sub.connect(filter);
      filter.connect(mainGain);

      lfo.start(now);
      carrier.start(now);
      sub.start(now);

      oscs.push(carrier, sub, lfo);
    } 
    else if (type === "focus") {
      // Focus: Binaural beats (100Hz Left, 110Hz Right) for alpha state + warm square sweeping pad
      const leftOsc = ctx.createOscillator();
      leftOsc.frequency.setValueAtTime(100, now);
      leftOsc.type = "sine";

      const rightOsc = ctx.createOscillator();
      rightOsc.frequency.setValueAtTime(110, now);
      rightOsc.type = "sine";

      const pannerLeft = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
      const pannerRight = ctx.createStereoPanner ? ctx.createStereoPanner() : null;

      const pad = ctx.createOscillator();
      pad.type = "sine";
      pad.frequency.setValueAtTime(220, now);

      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(280, now);

      const padLFO = ctx.createOscillator();
      padLFO.frequency.setValueAtTime(0.08, now);
      const padLFOGain = ctx.createGain();
      padLFOGain.gain.setValueAtTime(80, now);

      padLFO.connect(padLFOGain);
      padLFOGain.connect(filter.frequency);

      pad.connect(filter);
      filter.connect(mainGain);

      if (pannerLeft && pannerRight) {
        pannerLeft.pan.setValueAtTime(-1, now);
        pannerRight.pan.setValueAtTime(1, now);
        leftOsc.connect(pannerLeft).connect(mainGain);
        rightOsc.connect(pannerRight).connect(mainGain);
      } else {
        leftOsc.connect(mainGain);
        rightOsc.connect(mainGain);
      }

      leftOsc.start(now);
      rightOsc.start(now);
      pad.start(now);
      padLFO.start(now);

      oscs.push(leftOsc, rightOsc, pad, padLFO);
    } 
    else if (type === "rain") {
      // Rain: Generate beautiful procedurally filtered white noise
      const bufferSize = ctx.sampleRate * 4; // 4 seconds of noise
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      noiseSource = ctx.createBufferSource();
      noiseSource.buffer = buffer;
      noiseSource.loop = true;

      // Bandpass filter for rain texture
      const bandpass = ctx.createBiquadFilter();
      bandpass.type = "bandpass";
      bandpass.frequency.setValueAtTime(1200, now);
      bandpass.Q.setValueAtTime(0.8, now);

      // Lowpass to make it warmer/indoor
      const lowpass = ctx.createBiquadFilter();
      lowpass.type = "lowpass";
      lowpass.frequency.setValueAtTime(2000, now);

      noiseSource.connect(bandpass);
      bandpass.connect(lowpass);
      lowpass.connect(mainGain);

      noiseSource.start(now);
    } 
    else if (type === "library") {
      // Library: Deep brown noise buffer (accumulated random values for soft heavy low frequency rumbling)
      const bufferSize = ctx.sampleRate * 4;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        data[i] = (lastOut + (0.02 * white)) / 1.02;
        lastOut = data[i];
        data[i] *= 3.5; // Compensate volume loss of brownian integration
      }

      noiseSource = ctx.createBufferSource();
      noiseSource.buffer = buffer;
      noiseSource.loop = true;

      // Gentle filter for absolute warmth
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(450, now);

      noiseSource.connect(filter);
      filter.connect(mainGain);

      noiseSource.start(now);
    } 
    else if (type === "digital") {
      // Digital: White noise + fast rhythmic high synth chirps
      const bufferSize = ctx.sampleRate * 2;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      noiseSource = ctx.createBufferSource();
      noiseSource.buffer = buffer;
      noiseSource.loop = true;

      const noiseFilter = ctx.createBiquadFilter();
      noiseFilter.type = "bandpass";
      noiseFilter.frequency.setValueAtTime(3500, now);
      noiseFilter.Q.setValueAtTime(0.3, now);

      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(0.015, now);

      noiseSource.connect(noiseFilter).connect(noiseGain).connect(mainGain);
      noiseSource.start(now);

      // Metronome-like high pulse
      const pulseOsc = ctx.createOscillator();
      pulseOsc.type = "sine";
      pulseOsc.frequency.setValueAtTime(4000, now);

      const pulseGain = ctx.createGain();
      pulseGain.gain.setValueAtTime(0, now);

      pulseOsc.connect(pulseGain).connect(mainGain);
      pulseOsc.start(now);

      // Schedule periodic soft ticks
      const interval = 2.0; // every 2 seconds
      for (let i = 0; i < 60; i++) {
        const tickTime = now + i * interval;
        pulseGain.gain.setValueAtTime(0, tickTime);
        pulseGain.gain.linearRampToValueAtTime(0.02, tickTime + 0.005);
        pulseGain.gain.exponentialRampToValueAtTime(0.0001, tickTime + 0.05);
      }

      oscs.push(pulseOsc);
    }

    mainGain.connect(dest);
    this.activeOscillators[type] = { oscs, gain: mainGain, noiseSource };
  }

  public stopAmbience() {
    if (this.currentAmbience && this.activeOscillators[this.currentAmbience]) {
      const active = this.activeOscillators[this.currentAmbience];
      const ctx = this.initCtx();
      const now = ctx ? ctx.currentTime : 0;

      if (ctx) {
        // Fade out smoothly
        active.gain.gain.setValueAtTime(active.gain.gain.value, now);
        active.gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.6);
        
        setTimeout(() => {
          active.oscs.forEach((osc) => {
            try { osc.stop(); } catch {}
          });
          if (active.noiseSource) {
            try { active.noiseSource.stop(); } catch {}
          }
        }, 800);
      } else {
        active.oscs.forEach((osc) => {
          try { osc.stop(); } catch {}
        });
        if (active.noiseSource) {
          try { active.noiseSource.stop(); } catch {}
        }
      }

      delete this.activeOscillators[this.currentAmbience];
    }
    this.currentAmbience = null;
  }

  public setAmbienceVolume(volume: number) {
    if (this.currentAmbience && this.activeOscillators[this.currentAmbience]) {
      const active = this.activeOscillators[this.currentAmbience];
      const ctx = this.initCtx();
      if (ctx) {
        active.gain.gain.linearRampToValueAtTime(0.12 * volume, ctx.currentTime + 0.15);
      }
    }
  }

  public getActiveAmbience() {
    return this.currentAmbience;
  }
}

// Global single instance of audio engine to avoid piling oscillators
const companionAudioEngine = new WebAudioEngine();

export default function CompanionTab() {
  const settings = useJarvisStore((state) => state.settings);
  const addToast = useJarvisStore((state) => state.addToast);
  const speakText = useJarvisStore((state) => state.speakText);
  const addRecentActivity = useJarvisStore((state) => state.addRecentActivity);
  const systemStatus = useJarvisStore((state) => state.systemStatus);
  const activeTab = useJarvisStore((state) => state.activeTab);
  const addTask = useJarvisStore((state) => state.addTask);
  const uploadFile = useJarvisStore((state) => state.uploadFile);
  const sendMessage = useJarvisStore((state) => state.sendMessage);
  const isSpeaking = useJarvisStore((state) => state.isSpeaking);
  const stopSpeaking = useJarvisStore((state) => state.stopSpeaking);

  const isLight = settings?.appearance?.mode === "light";

  // State managers
  const [activeSubSection, setActiveSubSection] = useState<"mood" | "audio" | "monitor" | "gestures" | "ar" | "marketplace" | "voice">("mood");

  // Advanced Voice Core state
  const [wakeWord, setWakeWord] = useState<"Hey JARVIS" | "JARVIS" | "custom">("Hey JARVIS");
  const [customWakeWord, setCustomWakeWord] = useState("Omega Core");
  const [wakeWordSensitivity, setWakeWordSensitivity] = useState(75);
  const [conserveBattery, setConserveBattery] = useState(true);
  const [porcupineEnabled, setPorcupineEnabled] = useState(true);
  
  const [sttEngine, setSttEngine] = useState<"whisper" | "vosk" | "web_speech">("web_speech");
  const [sttLanguage, setSttLanguage] = useState("en-US");
  const [noiseCancellation, setNoiseCancellation] = useState(true);
  const [streamingRecognition, setStreamingRecognition] = useState(true);
  const [autoInterruption, setAutoInterruption] = useState(true);

  const [ttsEngine, setTtsEngine] = useState<"piper" | "coqui" | "web_speech">("web_speech");
  const [ttsVoice, setTtsVoice] = useState<"male" | "female">("male");
  const [ttsSpeed, setTtsSpeed] = useState(1.0);
  const [ttsPitch, setTtsPitch] = useState(1.0);
  const [ttsVolume, setTtsVolume] = useState(0.85);
  const [emotionalTone, setEmotionalTone] = useState<"calm" | "friendly" | "sarcastic" | "energetic">("calm");

  const [continuousConversation, setContinuousConversation] = useState(false);
  const [voiceInterruption, setVoiceInterruption] = useState(true);

  const [microphones, setMicrophones] = useState<MediaDeviceInfo[]>([]);
  const [selectedMic, setSelectedMic] = useState("");
  const [micPermission, setMicPermission] = useState<"prompt" | "granted" | "denied">("prompt");
  const [speakerPermission, setSpeakerPermission] = useState<"prompt" | "granted" | "denied">("granted");
  const [backgroundAudioPermission, setBackgroundAudioPermission] = useState<"prompt" | "granted" | "denied">("granted");

  // Granular secure Hands-Free Operator Permissions
  const [agentPermissions, setAgentPermissions] = useState<{
    microphone: "granted" | "denied" | "prompt";
    accessibility: "granted" | "denied" | "prompt";
    fileSystem: "granted" | "denied" | "prompt";
    screen: "granted" | "denied" | "prompt";
    appControl: "granted" | "denied" | "prompt";
    browserAutomation: "granted" | "denied" | "prompt";
  }>(() => {
    const saved = localStorage.getItem("jarvis_agent_permissions_v2");
    return saved ? JSON.parse(saved) : {
      microphone: "prompt",
      accessibility: "prompt",
      fileSystem: "prompt",
      screen: "prompt",
      appControl: "prompt",
      browserAutomation: "prompt"
    };
  });

  const saveAgentPermissions = (newPerms: typeof agentPermissions) => {
    setAgentPermissions(newPerms);
    localStorage.setItem("jarvis_agent_permissions_v2", JSON.stringify(newPerms));
  };

  const [pendingCommand, setPendingCommand] = useState<string | null>(null);
  const [permissionModalOpen, setPermissionModalOpen] = useState(false);
  const [permissionModalTarget, setPermissionModalTarget] = useState<keyof typeof agentPermissions | null>(null);

  const [voiceLogs, setVoiceLogs] = useState<Array<{ role: "user" | "model"; content: string; timestamp: string }>>([
    { role: "model", content: "Voice link established. Wake Word System initialized on 'Hey JARVIS'. I am standing by for continuous auditory input, Sir.", timestamp: "05:32:01" }
  ]);
  const [voiceInputText, setVoiceInputText] = useState("");
  const [isSTTListening, setIsSTTListening] = useState(false);
  const [sttTranscript, setSttTranscript] = useState("");

  // Mood System State
  const [activeMood, setActiveMood] = useState<"focus" | "coding" | "gaming" | "study">("focus");
  const [pomodoroMinutes, setPomodoroMinutes] = useState(25);
  const [pomodoroSeconds, setPomodoroSeconds] = useState(0);
  const [pomodoroActive, setPomodoroActive] = useState(false);
  const [studyGoals, setStudyGoals] = useState([
    { text: "Finish core UI structural integration", completed: true },
    { text: "Review Web Audio spatial synthetics logic", completed: false },
    { text: "Deploy premium companion sandbox updates", completed: false }
  ]);
  const [newGoalText, setNewGoalText] = useState("");
  const [codingTerminalLogs, setCodingTerminalLogs] = useState<string[]>([
    "[Sentinel Mainframe] Node synchronization verified on port 3000",
    "[Core React-Engine] Render cycles stable: 118 FPS // Memory heap 18.2MB",
    "[OAuth Bridge] Secure token handshake verified with Google Developer API",
    "[Diagnostic Daemon] Core thermals reading optimal at 34°C"
  ]);

  // Audio system state
  const [playingAmbience, setPlayingAmbience] = useState<string | null>(null);
  const [ambienceVolume, setAmbienceVolume] = useState(0.5);

  // Multi-Monitor state
  const [monitors, setMonitors] = useState([
    { id: "mon-1", name: "Primary Center Display", resolution: "3840x2160", hz: "144Hz", port: "DP-1", activeWidget: "Chat Console", isDragging: false },
    { id: "mon-2", name: "Auxiliary Right Panel", resolution: "1920x1080", hz: "75Hz", port: "HDMI-1", activeWidget: "System Metrics", isDragging: false },
    { id: "mon-3", name: "Holographic AR Overlay", resolution: "Volumetric HUD", hz: "90Hz", port: "Omega-Link", activeWidget: "Augmented Reality", isDragging: false }
  ]);
  const [draggedWidget, setDraggedWidget] = useState<string | null>(null);

  // Webcam Gestures states
  const [gestureWebcamActive, setGestureWebcamActive] = useState(false);
  const [gestureLogs, setGestureLogs] = useState<Array<{ time: string; gesture: string; action: string }>>([
    { time: "04:32:15", gesture: "Thumbs Up", action: "System parameters initialized" },
    { time: "04:35:40", gesture: "Swipe Right", action: "Flipped view to diagnostic reports" }
  ]);
  const [sensitivity, setSensitivity] = useState(78);
  const [calibrationMode, setCalibrationMode] = useState(false);

  // Augmented Reality states
  const [arX, setArX] = useState(0);
  const [arY, setArY] = useState(1.2);
  const [arZ, setArZ] = useState(-2.4);
  const [arRotation, setArRotation] = useState(45);
  const [arScale, setArScale] = useState(1.0);
  const [pinnedARWidgets, setPinnedARWidgets] = useState({
    weather: true,
    calendar: false,
    notifications: true,
    coreGauges: true
  });
  const [arCameraFilter, setArCameraFilter] = useState<"hologram" | "night" | "thermal" | "normal">("hologram");

  // Plugin Marketplace States
  const [searchPluginQuery, setSearchPluginQuery] = useState("");
  const [selectedPluginCategory, setSelectedPluginCategory] = useState<"all" | "productivity" | "coding" | "finance" | "education" | "gaming">("all");
  const [pluginsList, setPluginsList] = useState([
    {
      id: "p1",
      name: "OmniCalendar Sync",
      desc: "Synchronizes secure calendar invites and custom schedule checklists.",
      version: "v2.1.0",
      downloads: "18.4K",
      rating: 4.8,
      installed: true,
      installing: false,
      category: "productivity",
      permissions: ["Calendar Read", "Push Notifications"]
    },
    {
      id: "p2",
      name: "Git-Sentinel Monitor",
      desc: "Monitors local code repos, auto-generating commit summaries using AI.",
      version: "v1.4.3",
      downloads: "32.1K",
      rating: 4.9,
      installed: false,
      installing: false,
      category: "coding",
      permissions: ["Git Core Exec", "File Diagnostic Scanner"]
    },
    {
      id: "p3",
      name: "Stripe Metrics HUD",
      desc: "Pipes real-time financial checkout webhooks directly into the primary HUD stream.",
      version: "v1.1.2",
      downloads: "8.9K",
      rating: 4.7,
      installed: false,
      installing: false,
      category: "finance",
      permissions: ["Sandbox API Proxy", "HTTPS Handshake Hooks"]
    },
    {
      id: "p4",
      name: "Omega Smart Home Hub",
      desc: "Vocal commands interface targeting Phillips Hue, local iot servers, and smart plugs.",
      version: "v3.0.5",
      downloads: "14.2K",
      rating: 4.6,
      installed: false,
      installing: false,
      category: "productivity",
      permissions: ["Local Network Discovery", "Voice Trigger Hook"]
    },
    {
      id: "p5",
      name: "Core Focus Binaural",
      desc: "Binaural sound sweeps tailored for deep memory retention and creative study.",
      version: "v1.0.8",
      downloads: "24.5K",
      rating: 5.0,
      installed: true,
      installing: false,
      category: "education",
      permissions: ["Audio Device Link"]
    }
  ]);

  // Pomodoro effect
  useEffect(() => {
    let timer: any;
    if (pomodoroActive) {
      timer = setInterval(() => {
        if (pomodoroSeconds > 0) {
          setPomodoroSeconds((prev) => prev - 1);
        } else if (pomodoroMinutes > 0) {
          setPomodoroMinutes((prev) => prev - 1);
          setPomodoroSeconds(59);
        } else {
          // Timer ended
          setPomodoroActive(false);
          companionAudioEngine.playSFX("success");
          speakText("Break session recommended. Sir, focus block complete!");
          addToast("Pomodoro study timer finished! Time to relax.", "success");
          addRecentActivity("Focus session completed", "system_event", "Pomodoro study timer reached zero.");
        }
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [pomodoroActive, pomodoroMinutes, pomodoroSeconds]);

  // Audio Ambience Sync
  useEffect(() => {
    return () => {
      // Cleanup continuous loops when component unmounts
      companionAudioEngine.stopAmbience();
    };
  }, []);

  // Real speech recognition control
  const [activeSpeechRec, setActiveSpeechRec] = useState<any>(null);
  // Continuous Wake Word Background Sentinel
  const [isWakeWordMonitoring, setIsWakeWordMonitoring] = useState(false);
  const [wakeSentinel, setWakeSentinel] = useState<any>(null);

  // Load Microphones list & Permissions
  useEffect(() => {
    if (activeSubSection === "voice") {
      const getMicrophones = async () => {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          setMicPermission("granted");
          
          const devices = await navigator.mediaDevices.enumerateDevices();
          const audioInputs = devices.filter((device) => device.kind === "audioinput");
          setMicrophones(audioInputs);
          if (audioInputs.length > 0 && !selectedMic) {
            setSelectedMic(audioInputs[0].deviceId);
          }
          
          stream.getTracks().forEach((track) => track.stop());
        } catch (e) {
          console.warn("Permission denied or error getting microdevices:", e);
          setMicPermission("denied");
        }
      };
      
      getMicrophones();
    }
  }, [activeSubSection]);

  const playVoiceTest = () => {
    companionAudioEngine.playSFX("startup");
    let testSentence = "";
    if (ttsVoice === "male") {
      if (emotionalTone === "sarcastic") {
        testSentence = "Yes, because testing my voice array for the hundredth time is obviously the best use of my processing cores.";
      } else if (emotionalTone === "energetic") {
        testSentence = "All systems primed, Sir! Advanced cognitive neural loop is operating at peak velocity! Let's build something extraordinary!";
      } else if (emotionalTone === "friendly") {
        testSentence = "Always a pleasure, Sir. I'm synchronized with your client network and standing by to assist with your workspace tasks.";
      } else {
        testSentence = "Uplink online, Sir. Cognitive acoustic matrices are fully synchronized in calm analytical baritone mode.";
      }
    } else {
      if (emotionalTone === "sarcastic") {
        testSentence = "Aria vocal protocol is online. Yes, I am absolutely thrilled to confirm that my synthetic larynx is fully calibrated.";
      } else if (emotionalTone === "energetic") {
        testSentence = "Aria core fully charged! Launching telemetry scanners, caching visual grids, and awaiting your command, Sir!";
      } else if (emotionalTone === "friendly") {
        testSentence = "Hello, Sir. Aria is fully synchronized. How is your day progressing? I am ready for any commands you have.";
      } else {
        testSentence = "Aria neural link online. Vocal pitch and speed indexes are aligned to standard operating thresholds.";
      }
    }

    try {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(testSentence);
        const voices = window.speechSynthesis.getVoices();
        
        let matchedVoice = null;
        if (ttsVoice === "male") {
          matchedVoice = voices.find(v => v.lang.startsWith("en") && (v.name.toLowerCase().includes("male") || v.name.toLowerCase().includes("google") || v.name.toLowerCase().includes("microsoft")));
        } else {
          matchedVoice = voices.find(v => v.lang.startsWith("en") && (v.name.toLowerCase().includes("female") || v.name.toLowerCase().includes("zira") || v.name.toLowerCase().includes("hazel")));
        }
        if (matchedVoice) utterance.voice = matchedVoice;
        
        utterance.rate = ttsSpeed;
        utterance.pitch = ttsPitch;
        utterance.volume = ttsVolume;
        
        window.speechSynthesis.speak(utterance);
        addToast(`Voice test triggered: "${testSentence}"`, "success");
      } else {
        addToast("Local speech synthesis not supported. Falling back to synth chime.", "info");
      }
    } catch (err) {
      console.warn("Failed voice test synthesis:", err);
    }
  };

  const processVoiceCommand = async (command: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setVoiceLogs(prev => [...prev, { role: "user", content: command, timestamp }]);
    setSttTranscript("");

    const cleanCmd = command.toLowerCase().trim();

    if (isSpeaking && voiceInterruption) {
      stopSpeaking();
      addToast("JARVIS output interrupted by user speech.", "info");
    }

    // Classify the incoming command
    const analysis = classifyRequest(command);

    // If it's a knowledge question, handle specifically or route to Gemini
    if (analysis.category === AgentCategory.KNOWLEDGE_QUESTIONS) {
      // Local quick answers for common physics/CS conceptual queries for snappy offline backup
      let offlineAnswer = "";
      if (cleanCmd.includes("newton") || cleanCmd.includes("law of motion")) {
        offlineAnswer = "Sir, Newton's Laws of Motion describe the relationship between a physical body and the forces acting upon it. The First Law, or Law of Inertia, states that an object remains at rest or in uniform motion unless acted on by an external force. The Second Law states that force equals mass times acceleration (F=ma). The Third Law states that for every action, there is an equal and opposite reaction.";
      } else if (cleanCmd.includes("recursion") || cleanCmd.includes("recursive")) {
        offlineAnswer = "Recursion, Sir, is a programming method where a function calls itself directly or indirectly. It requires a base case to prevent infinite execution and stack overflows, alongside a recursive step that reduces the problem size. It is exceptionally elegant for tree traversals, search directories, and divide-and-conquer paradigms.";
      } else if (cleanCmd.includes("quantum mechanics") || cleanCmd.includes("quantum physics")) {
        offlineAnswer = "Quantum mechanics, Sir, is the fundamental theory in physics that describes the nature and behavior of matter and radiation at atomic and subatomic scales. It introduces wave-particle duality, quantization of energy states, the Heisenberg uncertainty principle, and superposition—where particles exist in multiple potential configurations simultaneously until observed.";
      }

      if (offlineAnswer) {
        setVoiceLogs(prev => [...prev, { role: "model", content: offlineAnswer, timestamp }]);
        speakText(offlineAnswer);
        addToast("Conceptual reasoning resolved locally.", "success");
        addRecentActivity("Conceptual Query", "diagnostics_run", `Answered: ${analysis.target}`);
        return;
      }

      // Otherwise route to Gemini Chat
      const replyPlaceholder = "Routing conceptual query to cognitive reasoning link... Standby, Sir.";
      setVoiceLogs(prev => [...prev, { role: "model", content: replyPlaceholder, timestamp }]);
      
      try {
        await sendMessage(command);
        setTimeout(() => {
          setVoiceLogs(prev => {
            const filtered = prev.filter(p => p.content !== replyPlaceholder);
            return [
              ...filtered,
              { role: "model", content: "Mainframe transaction synchronized. Analytical readout sent to your primary console stream, Sir.", timestamp: new Date().toLocaleTimeString() }
            ];
          });
        }, 3000);
      } catch (e) {
        const fallbackReply = "Cognitive satellite uplink timed out, Sir. I am operating on local auxiliary subroutines.";
        setVoiceLogs(prev => {
          const filtered = prev.filter(p => p.content !== replyPlaceholder);
          return [...filtered, { role: "model", content: fallbackReply, timestamp }];
        });
        speakText(fallbackReply);
      }
      return;
    }

    // Secure Permission Handshake Check for Actionable Categories
    const permissionKey = analysis.requiredPermission;
    if (permissionKey && permissionKey !== "none") {
      const currentStatus = agentPermissions[permissionKey];
      if (currentStatus === "prompt") {
        setPendingCommand(command);
        setPermissionModalTarget(permissionKey);
        setPermissionModalOpen(true);
        
        const handshakemsg = `Handshake required, Sir. Local mainframe operation requested but security permissions for '${permissionKey}' are currently unverified. I am deploying the secure authorization gateway popup for your verification.`;
        setVoiceLogs(prev => [...prev, { role: "model", content: handshakemsg, timestamp }]);
        speakText(handshakemsg);
        addToast("Security handshake requested.", "warning");
        return;
      } else if (currentStatus === "denied") {
        const denymsg = `Access denied, Sir. The required security permission for '${permissionKey}' is currently marked as Denied in our system preferences. Operation aborted.`;
        setVoiceLogs(prev => [...prev, { role: "model", content: denymsg, timestamp }]);
        speakText(denymsg);
        addToast("Local operation aborted: Access Denied.", "error");
        return;
      }
    }

    // Direct Operating Execution (Permission is GRANTED or NONE)
    const execMsg = `${analysis.replyText}\n\n[OPERATING MODE LOGS]:\n` + analysis.executionLogs.join("\n");
    setVoiceLogs(prev => [...prev, { role: "model", content: execMsg, timestamp }]);
    speakText(analysis.replyText);
    
    // Add corresponding actual UI items/tasks
    if (analysis.category === AgentCategory.DEVICE_CONTROL) {
      if (cleanCmd.includes("chrome") || cleanCmd.includes("browser")) {
        window.open("https://www.google.com", "_blank");
      } else if (cleanCmd.includes("vs code") || cleanCmd.includes("vscode")) {
        window.open("https://vscode.dev", "_blank");
      } else if (cleanCmd.includes("spotify")) {
        window.open("https://open.spotify.com", "_blank");
      }
      addToast(`Device Command Executed: ${analysis.action}`, "success");
      addRecentActivity("Device Control", "system_event", `PyAutoGUI automation: ${analysis.action}`);
      await addTask(analysis.action, "Device_Control", "high", undefined, "Automation");
    }
    else if (analysis.category === AgentCategory.FILE_OPERATIONS) {
      if (cleanCmd.includes("create")) {
        const folderName = analysis.target || "Physics Notes";
        try {
          await uploadFile(`${folderName}_dir.json`, "directory", "eyI3YW5pc2giOiAiSmFydmlzIn0=");
        } catch (e) {
          console.warn("Folder file sync skipped:", e);
        }
      }
      addToast(`File Command Executed: ${analysis.action}`, "success");
      addRecentActivity("File Operation", "file_action", `Local Node FS: ${analysis.action}`);
      await addTask(analysis.action, "File_System", "medium", undefined, "Records");
    }
    else if (analysis.category === AgentCategory.BROWSER_AUTOMATION) {
      if (cleanCmd.includes("youtube")) {
        window.open("https://www.youtube.com", "_blank");
      } else if (cleanCmd.includes("gmail")) {
        window.open("https://mail.google.com", "_blank");
      } else if (cleanCmd.includes("search")) {
        const q = encodeURIComponent(analysis.target);
        window.open(`https://www.youtube.com/results?search_query=${q}`, "_blank");
      }
      addToast(`Browser Automation Triggered: ${analysis.action}`, "success");
      addRecentActivity("Browser Automation", "system_event", `Playwright Headless Sequence: ${analysis.action}`);
      await addTask(analysis.action, "Browser_Automation", "high", undefined, "Automation");
    }
    else if (analysis.category === AgentCategory.DEVELOPMENT_MODE) {
      addToast(`Development Command Executed: ${analysis.action}`, "success");
      addRecentActivity("Dev Server started", "task_started", `Terminal daemon: ${analysis.action}`);
      await addTask(analysis.action, "Terminal_Daemon", "high", undefined, "Development");
    }
  };

  const startVoiceSTT = () => {
    if (isSTTListening) {
      stopVoiceSTT();
      return;
    }

    if (typeof window === "undefined" || !("webkitSpeechRecognition" in window || "SpeechRecognition" in window)) {
      addToast("Speech recognition is not supported in this browser environment.", "error");
      return;
    }

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRec();
    recognition.continuous = continuousConversation;
    recognition.interimResults = streamingRecognition;
    recognition.lang = sttLanguage;

    recognition.onstart = () => {
      setIsSTTListening(true);
      setSttTranscript("");
      companionAudioEngine.playSFX("notification");
      addToast("Voice core listening...", "success");
    };

    recognition.onresult = (event: any) => {
      let currentResult = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        currentResult += event.results[i][0].transcript;
      }
      setSttTranscript(currentResult);
      
      if (event.results[event.results.length - 1].isFinal) {
        const commandText = event.results[event.results.length - 1][0].transcript.trim();
        if (commandText) {
          processVoiceCommand(commandText);
        }
      }
    };

    recognition.onerror = (e: any) => {
      console.error("Speech Recognition Error:", e);
      if (e.error !== "no-speech") {
        addToast(`Speech capture error: ${e.error}`, "warning");
      }
      setIsSTTListening(false);
    };

    recognition.onend = () => {
      setIsSTTListening(false);
    };

    recognition.start();
    setActiveSpeechRec(recognition);
  };

  const stopVoiceSTT = () => {
    if (activeSpeechRec) {
      try {
        activeSpeechRec.stop();
      } catch (err) {}
      setActiveSpeechRec(null);
    }
    setIsSTTListening(false);
    addToast("Voice capture paused.", "info");
  };

  const startWakeWordSentinel = () => {
    if (isWakeWordMonitoring) {
      stopWakeWordSentinel();
      return;
    }

    if (typeof window === "undefined" || !("webkitSpeechRecognition" in window || "SpeechRecognition" in window)) {
      addToast("Acoustic wake word capture not supported in this browser.", "error");
      return;
    }

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const sentinel = new SpeechRec();
    sentinel.continuous = true;
    sentinel.interimResults = true;
    sentinel.lang = sttLanguage;

    sentinel.onstart = () => {
      setIsWakeWordMonitoring(true);
      companionAudioEngine.playSFX("startup");
      addToast(`Sentinel active: Listening for wake words...`, "success");
    };

    sentinel.onresult = (event: any) => {
      const lastResultIndex = event.results.length - 1;
      const transcript = event.results[lastResultIndex][0].transcript.toLowerCase();
      
      const triggerWords = [
        "jarvis",
        "hey jarvis",
        "hey, jarvis",
        "hi jarvis",
        "hi, jarvis",
        customWakeWord.toLowerCase()
      ];

      const matchedTrigger = triggerWords.find(word => transcript.includes(word));
      
      if (matchedTrigger) {
        companionAudioEngine.playSFX("success");
        stopWakeWordSentinel();
        
        const timestamp = new Date().toLocaleTimeString();
        setVoiceLogs(prev => [
          ...prev,
          { role: "model", content: `Acoustic Wake Signal Triggered: [${matchedTrigger.toUpperCase()}]. Unlocking speech processor...`, timestamp }
        ]);

        speakText("Awaiting your command, Sir.");
        
        setTimeout(() => {
          startVoiceSTT();
        }, 1200);
      }
    };

    sentinel.onerror = (e: any) => {
      if (e.error !== "no-speech") {
        console.warn("Wake Sentinel Error:", e.error);
      }
    };

    sentinel.onend = () => {
      if (isWakeWordMonitoring) {
        try {
          sentinel.start();
        } catch (err) {}
      }
    };

    sentinel.start();
    setWakeSentinel(sentinel);
  };

  const stopWakeWordSentinel = () => {
    setIsWakeWordMonitoring(false);
    if (wakeSentinel) {
      try {
        wakeSentinel.stop();
      } catch (e) {}
      setWakeSentinel(null);
    }
    addToast("Wake word sentinel deactivated.", "info");
  };

  useEffect(() => {
    return () => {
      if (activeSpeechRec) {
        try { activeSpeechRec.stop(); } catch (e) {}
      }
      if (wakeSentinel) {
        try { wakeSentinel.stop(); } catch (e) {}
      }
    };
  }, [activeSpeechRec, wakeSentinel]);

  const toggleAmbience = (type: "digital" | "focus" | "rain" | "space" | "library") => {
    const active = companionAudioEngine.getActiveAmbience();
    if (active === type) {
      companionAudioEngine.stopAmbience();
      setPlayingAmbience(null);
      addToast(`Ambient ${type} generator paused.`, "info");
    } else {
      companionAudioEngine.startAmbience(type, ambienceVolume);
      setPlayingAmbience(type);
      companionAudioEngine.playSFX("notification");
      addToast(`Ambient ${type} generator online.`, "success");
      addRecentActivity(`Ambient Audio Started: ${type}`, "system_event", "Dynamic procedural audio synthesis active");
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    setAmbienceVolume(vol);
    companionAudioEngine.setAmbienceVolume(vol);
  };

  const playSoundSFX = (type: any) => {
    companionAudioEngine.playSFX(type);
    addToast(`SFX Synthesizer: ${type.toUpperCase()} triggered.`, "info");
  };

  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalText.trim()) return;
    setStudyGoals([...studyGoals, { text: newGoalText, completed: false }]);
    setNewGoalText("");
    companionAudioEngine.playSFX("notification");
    addToast("Focus session target registered", "success");
  };

  const toggleGoal = (index: number) => {
    const updated = [...studyGoals];
    updated[index].completed = !updated[index].completed;
    setStudyGoals(updated);
    companionAudioEngine.playSFX(updated[index].completed ? "success" : "shutdown");
  };

  // Simulate hand gestures
  const triggerSimulatedGesture = (gesture: string, action: string) => {
    const time = new Date().toLocaleTimeString();
    setGestureLogs((prev) => [{ time, gesture, action }, ...prev]);
    companionAudioEngine.playSFX("notification");
    addToast(`Gesture Event: ${gesture} -> ${action}`, "success");
    addRecentActivity(`Gesture Registered: ${gesture}`, "webcam_accessed", `System execution: ${action}`);

    // If gesture implies navigation, let's do a cool tab flip
    if (gesture === "Swipe Right") {
      speakText(`Gesture swipe right registered. Accessing mainframe nodes.`);
    } else if (gesture === "Thumbs Up") {
      speakText(`Thumbs up detected. Setting secure protocols.`);
    }
  };

  // Multi-Monitor workspace placement
  const handleAssignWidget = (monitorId: string, widget: string) => {
    setMonitors(monitors.map(m => m.id === monitorId ? { ...m, activeWidget: widget } : m));
    companionAudioEngine.playSFX("success");
    addToast(`${widget} allocated to display node.`, "success");
    addRecentActivity(`Monitor Layout Updated`, "system_event", `${widget} mapped to screen registry`);
  };

  // Plugin installer helper
  const handleInstallPlugin = (pluginId: string) => {
    setPluginsList(pluginsList.map(p => {
      if (p.id === pluginId) {
        companionAudioEngine.playSFX("notification");
        return { ...p, installing: true };
      }
      return p;
    }));

    setTimeout(() => {
      setPluginsList(pluginsList.map(p => {
        if (p.id === pluginId) {
          companionAudioEngine.playSFX("success");
          addToast(`Plugin sandbox: ${p.name} installed and compiled!`, "success");
          addRecentActivity("Plugin Installed", "file_action", `${p.name} sandbox registered`);
          return { ...p, installed: true, installing: false };
        }
        return p;
      }));
    }, 2000);
  };

  const handleRemovePlugin = (pluginId: string, name: string) => {
    setPluginsList(pluginsList.map(p => {
      if (p.id === pluginId) {
        companionAudioEngine.playSFX("shutdown");
        addToast(`Plugin secure sandbox: ${name} uninstalled.`, "warning");
        addRecentActivity("Plugin Uninstalled", "file_action", `${name} binary logs wiped`);
        return { ...p, installed: false };
      }
      return p;
    }));
  };

  const filteredPlugins = pluginsList.filter(p => {
    const matchesCategory = selectedPluginCategory === "all" || p.category === selectedPluginCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchPluginQuery.toLowerCase()) || p.desc.toLowerCase().includes(searchPluginQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div id="companion_mainframe" className="relative w-full h-full rounded-2xl p-0.5 select-none font-mono">
      {/* Absolute digital background grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#22d3ee_1px,transparent_1px)] [background-size:20px_20px] opacity-5"></div>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 overflow-visible lg:overflow-hidden h-auto lg:h-[550px] xl:h-full relative z-10">
        
        {/* Left column sidebar containing system navigation */}
        <div className="lg:col-span-1 flex flex-col gap-4 h-auto lg:h-full overflow-y-auto lg:overflow-hidden">
          <div className={`p-4 border rounded-xl flex flex-col justify-between ${
            isLight ? "bg-white/95 border-slate-300" : "bg-slate-950/90 border-cyan-500/15"
          } shadow-xl backdrop-blur-sm h-full`}>
            
            <div className="space-y-4">
              <div className="border-b border-cyan-500/10 pb-2">
                <span className={`text-[9px] font-mono ${isLight ? "text-cyan-600" : "text-cyan-400"} uppercase tracking-widest block font-bold`}>COMPANION PANEL</span>
                <h3 className={`font-display font-black text-xs ${isLight ? "text-slate-800" : "text-slate-200"} tracking-wider`}>OMEGA SYSTEMS</h3>
              </div>

              {/* Navigation button panel */}
              <div className="flex flex-col gap-2">
                {[
                  { id: "mood", label: "Mood Controls", icon: Sparkles, desc: "Focus / study mode hubs" },
                  { id: "voice", label: "Voice Core", icon: Mic, desc: "Acoustic wake & speak matrices" },
                  { id: "audio", label: "Audio Mainframe", icon: Volume2, desc: "Continuous ambience synth" },
                  { id: "monitor", label: "Multi-Monitor", icon: Monitor, desc: "Screen layouts dashboard" },
                  { id: "gestures", label: "Gesture Webcam", icon: Hand, desc: "Optical hand movement HUD" },
                  { id: "ar", label: "AR Volumetrics", icon: Compass, desc: "Volumetric room projection" },
                  { id: "marketplace", label: "Marketplace", icon: Package, desc: "Secure helper sandboxes" }
                ].map((item) => {
                  const IconComp = item.icon;
                  const isActive = activeSubSection === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveSubSection(item.id as any);
                        companionAudioEngine.playSFX("notification");
                      }}
                      className={`w-full text-left p-2.5 rounded-lg border transition-all duration-300 cursor-pointer ${
                        isActive
                          ? isLight
                            ? "bg-cyan-50 border-cyan-500 text-cyan-700 shadow-md"
                            : "bg-cyan-950/30 border-cyan-500 text-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.15)]"
                          : isLight
                            ? "border-transparent hover:bg-slate-100/80 text-slate-500"
                            : "border-transparent hover:bg-slate-900/60 text-slate-400"
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <IconComp className={`w-4 h-4 ${isActive ? "text-cyan-400 animate-pulse" : "text-slate-500"}`} />
                        <div>
                          <div className="text-[11px] font-bold uppercase tracking-wider">{item.label}</div>
                          <div className="text-[8px] text-slate-500">{item.desc}</div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Diagnostic readout footprint at bottom of pane */}
            <div className="border-t border-cyan-500/10 pt-3 mt-4 space-y-1 select-none">
              <div className="flex items-center justify-between text-[8px] text-slate-500 uppercase tracking-widest font-bold">
                <span>ACTIVE_STABLE:</span>
                <span className="text-cyan-400 font-extrabold font-mono">100%</span>
              </div>
              <div className="flex items-center justify-between text-[8px] text-slate-500 uppercase tracking-widest font-bold">
                <span>MATRIX_UPLINK:</span>
                <span className="text-cyan-400 font-extrabold font-mono">OMEGA-SECURE</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Columns: Sub-Section View Workspace */}
        <div className="lg:col-span-3 flex flex-col gap-4 h-full overflow-hidden">
          <div className={`flex-1 p-4 border rounded-xl overflow-y-auto scrollbar-thin flex flex-col relative ${
            isLight ? "bg-white/95 border-slate-300" : "bg-slate-950/80 border-cyan-500/15"
          } backdrop-blur-md`}>
            
            {/* Header info bar inside center panel */}
            <div className="flex items-center justify-between border-b border-cyan-500/10 pb-2 mb-4">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-cyan-500" />
                <span className={`text-[10px] font-bold uppercase tracking-[0.2em] ${isLight ? "text-cyan-700" : "text-cyan-400"}`}>
                  COMPANION_SUBMODULE // {activeSubSection.toUpperCase()}
                </span>
              </div>
              <div className="flex items-center gap-1.5 font-mono text-[8px] text-slate-500">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                <span>GRID: CONNECTED</span>
              </div>
            </div>

            {/* 1. MOOD / MODE SYSTEM PANEL */}
            {activeSubSection === "mood" && (
              <div className="flex-1 flex flex-col gap-4">
                <div className="space-y-1.5">
                  <h4 className={`text-xs font-bold uppercase tracking-wider ${isLight ? "text-slate-800" : "text-slate-200"}`}>Intelligent Mood & Cognitive State</h4>
                  <p className="text-[10px] text-slate-500 leading-relaxed">
                    JARVIS adapts visual speeds, system alerts, audio ambient synthesis, and developer widgets in real-time according to your workspace focus mode.
                  </p>
                </div>

                {/* Grid of modes */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: "focus", label: "Focus Mode", icon: Sparkles, desc: "Limits distraction", color: "text-cyan-400 border-cyan-500/20" },
                    { id: "coding", label: "Coding Mode", icon: Terminal, desc: "Developer tools", color: "text-purple-400 border-purple-500/20" },
                    { id: "gaming", label: "Gaming Mode", icon: Gamepad2, desc: "High frame rates", color: "text-pink-400 border-pink-500/20" },
                    { id: "study", label: "Study Mode", icon: BookOpen, desc: "Reminders & tasks", color: "text-amber-400 border-amber-500/20" }
                  ].map((mode) => {
                    const IconComp = mode.icon;
                    const isSelected = activeMood === mode.id;
                    return (
                      <button
                        key={mode.id}
                        onClick={() => {
                          setActiveMood(mode.id as any);
                          companionAudioEngine.playSFX("success");
                          addToast(`Cognitive mode shifted: ${mode.label}`, "info");
                          addRecentActivity("Mood Shifted", "system_event", `Workspace adapted to ${mode.label}`);
                        }}
                        className={`p-3 rounded-xl border text-center cursor-pointer transition-all duration-300 flex flex-col items-center justify-center gap-1.5 ${
                          isSelected
                            ? isLight
                              ? "bg-cyan-50 border-cyan-500 shadow"
                              : "bg-slate-900 border-cyan-500/40 shadow-[0_0_15px_rgba(6,182,212,0.1)]"
                            : isLight
                              ? "border-slate-200 bg-slate-50/50 hover:bg-slate-100"
                              : "border-slate-850 bg-slate-950/40 hover:bg-slate-900/40"
                        }`}
                      >
                        <IconComp className={`w-4 h-4 ${isSelected ? mode.color.split(" ")[0] : "text-slate-500"}`} />
                        <div className="text-[10px] font-bold uppercase tracking-wider leading-none">{mode.label}</div>
                      </button>
                    );
                  })}
                </div>

                {/* Submodule UI depending on current selected Mood */}
                <div className={`p-4 border rounded-xl flex-1 flex flex-col gap-3.5 ${
                  isLight ? "bg-slate-50/50 border-slate-200" : "bg-slate-950/40 border-cyan-500/5"
                }`}>
                  
                  {/* FOCUS MODE: study timer, goals check */}
                  {activeMood === "focus" && (
                    <div className="space-y-4 flex-1 flex flex-col">
                      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-cyan-500/5 pb-3">
                        <div className="text-center sm:text-left">
                          <span className="text-[8px] text-slate-500 uppercase tracking-widest block font-bold">COGNITIVE TIME BLOCK</span>
                          <span className="text-xl font-bold font-mono tracking-widest text-cyan-400">
                            {String(pomodoroMinutes).padStart(2, "0")}:{String(pomodoroSeconds).padStart(2, "0")}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setPomodoroActive(!pomodoroActive);
                              companionAudioEngine.playSFX("notification");
                            }}
                            className="px-2.5 py-1 text-[10px] bg-cyan-500/10 border border-cyan-500/40 hover:bg-cyan-500/25 text-cyan-400 font-bold uppercase rounded cursor-pointer"
                          >
                            {pomodoroActive ? "Pause" : "Engage"}
                          </button>
                          <button
                            onClick={() => {
                              setPomodoroActive(false);
                              setPomodoroMinutes(25);
                              setPomodoroSeconds(0);
                              companionAudioEngine.playSFX("shutdown");
                            }}
                            className="p-1 text-slate-500 hover:text-slate-300 border border-transparent hover:border-slate-800 rounded cursor-pointer"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Goals Tracker */}
                      <div className="space-y-2.5 flex-1 flex flex-col">
                        <span className="text-[9px] text-slate-500 uppercase tracking-widest block font-bold">Active Targets Check</span>
                        
                        <form onSubmit={handleAddGoal} className="flex gap-2">
                          <input
                            type="text"
                            placeholder="Register study goal..."
                            value={newGoalText}
                            onChange={(e) => setNewGoalText(e.target.value)}
                            className={`flex-1 text-[10px] px-2.5 py-1.5 rounded border outline-none font-mono ${
                              isLight 
                                ? "bg-white border-slate-300 focus:border-cyan-500" 
                                : "bg-black/40 border-cyan-500/20 focus:border-cyan-400 text-slate-300"
                            }`}
                          />
                          <button type="submit" className="px-2 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded text-cyan-400 cursor-pointer">
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </form>

                        <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1 scrollbar-thin">
                          {studyGoals.map((g, idx) => (
                            <div
                              key={idx}
                              onClick={() => toggleGoal(idx)}
                              className={`flex items-center gap-2 p-2 rounded border cursor-pointer select-none transition-all ${
                                g.completed 
                                  ? "bg-green-950/10 border-green-500/20 text-slate-500 line-through" 
                                  : isLight ? "bg-white border-slate-200" : "bg-black/20 border-cyan-500/5 text-slate-300"
                              }`}
                            >
                              <div className={`w-3 h-3 rounded-sm border flex items-center justify-center ${g.completed ? "border-green-500 bg-green-500/20" : "border-slate-500"}`}>
                                {g.completed && <Check className="w-2.5 h-2.5 text-green-400" />}
                              </div>
                              <span className="text-[10px] leading-none">{g.text}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* CODING MODE: dev console outputs, server diagnostic readings */}
                  {activeMood === "coding" && (
                    <div className="space-y-3.5 flex-1 flex flex-col font-mono text-[9px]">
                      <div className="flex items-center justify-between border-b border-cyan-500/5 pb-2">
                        <div className="flex items-center gap-1.5">
                          <Terminal className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
                          <span className="text-purple-400 font-bold uppercase tracking-wider">Npm Dev-Server Feed</span>
                        </div>
                        <span className="text-green-500 text-[8px] px-1 bg-green-950/20 border border-green-500/20 rounded font-bold animate-ping">LIVE</span>
                      </div>

                      <div className="bg-black/60 p-3 rounded-lg border border-purple-500/10 h-[150px] overflow-y-auto space-y-1.5 scrollbar-thin text-slate-300 text-[8px]">
                        {codingTerminalLogs.map((log, idx) => (
                          <div key={idx} className="flex gap-1.5 items-start">
                            <span className="text-purple-500">&gt;</span>
                            <span className="leading-relaxed">{log}</span>
                          </div>
                        ))}
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-[8px] pt-1 border-t border-cyan-500/5 select-none">
                        <div className="p-1.5 bg-black/20 rounded border border-cyan-500/5">
                          <span className="text-slate-500 block">CPU THREADS:</span>
                          <span className="text-purple-400 font-bold">12/16 CORES ACTIVE</span>
                        </div>
                        <div className="p-1.5 bg-black/20 rounded border border-cyan-500/5">
                          <span className="text-slate-500 block">LOCAL NETWORK:</span>
                          <span className="text-purple-400 font-bold">PORT 3000 SECURE</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* GAMING MODE: block metrics, custom sliders */}
                  {activeMood === "gaming" && (
                    <div className="space-y-4 flex-1 flex flex-col text-[10px]">
                      <div className="flex justify-between items-center border-b border-cyan-500/5 pb-2">
                        <div className="flex items-center gap-1.5">
                          <Gamepad2 className="w-4 h-4 text-pink-400 animate-bounce" />
                          <span className="text-pink-400 font-bold uppercase tracking-wider">Holographic Game-Core</span>
                        </div>
                        <div className="text-right">
                          <span className="text-slate-500 text-[8px] block">TICKER_FPS</span>
                          <span className="text-pink-400 font-bold font-mono">120_FPS</span>
                        </div>
                      </div>

                      {/* Performance items */}
                      <div className="space-y-2.5">
                        <div className="p-2.5 bg-black/20 rounded-lg border border-pink-500/10 flex items-center justify-between">
                          <span className="text-slate-400">Cooling Fan Speed Boost</span>
                          <span className="text-green-400 font-bold font-mono">92%</span>
                        </div>
                        <div className="p-2.5 bg-black/20 rounded-lg border border-pink-500/10 flex items-center justify-between">
                          <span className="text-slate-400">Low-Latency Neural Pipeline</span>
                          <span className="text-green-400 font-bold font-mono">ACTIVE (1.2ms)</span>
                        </div>
                        <div className="p-2.5 bg-black/20 rounded-lg border border-pink-500/10 flex items-center justify-between">
                          <span className="text-slate-400">System Notifications Guard</span>
                          <span className="text-rose-400 font-bold font-mono">MUTED</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* STUDY MODE: session alerts and revision planners */}
                  {activeMood === "study" && (
                    <div className="space-y-3.5 flex-1 flex flex-col text-[10px]">
                      <div className="flex items-center gap-2 border-b border-cyan-500/5 pb-2">
                        <BookOpen className="w-4 h-4 text-amber-400 animate-pulse" />
                        <span className="text-amber-400 font-bold uppercase tracking-wider">Academic Study Board</span>
                      </div>

                      <div className="p-3 bg-black/20 rounded-lg border border-amber-500/15 space-y-1">
                        <span className="text-amber-400 font-bold block text-[11px]">Next Revision Interval</span>
                        <p className="text-[9px] text-slate-400 leading-relaxed">
                          Microservice architecture review session is queued. Estimated length: 45 minutes.
                        </p>
                      </div>

                      <div className="space-y-1.5 select-none pt-1">
                        <span className="text-[8px] text-slate-500 uppercase tracking-widest block font-bold">Study Sessions Rec</span>
                        <div className="p-2 bg-black/20 rounded border border-cyan-500/5 flex items-center justify-between">
                          <span>Alpha Waves Meditation</span>
                          <button
                            onClick={() => {
                              toggleAmbience("focus");
                              companionAudioEngine.playSFX("success");
                            }}
                            className="px-2 py-0.5 border border-amber-500/30 text-amber-400 text-[8px] rounded cursor-pointer uppercase font-bold"
                          >
                            Listen
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 2. AUDIO SYNTHESIZER MAIN VIEW */}
            {activeSubSection === "audio" && (
              <div className="flex-1 flex flex-col gap-4">
                <div className="space-y-1.5">
                  <h4 className={`text-xs font-bold uppercase tracking-wider ${isLight ? "text-slate-800" : "text-slate-200"}`}>Futuristic Ambient Audio Mainframe</h4>
                  <p className="text-[10px] text-slate-500 leading-relaxed">
                    Procedure sound sweeps completely synthesized inside your browser using the raw Web Audio API. Zero external networks required.
                  </p>
                </div>

                {/* Ambience continuous loop items */}
                <div className="space-y-2.5">
                  <span className="text-[9px] text-slate-500 uppercase tracking-widest block font-bold">Continuous Ambience Synthetics</span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {[
                      { id: "space", label: "Space Ambience", desc: "Low-frequency spaceship humming loop" },
                      { id: "rain", label: "Rain Ambience", desc: "Filtered procedural white noise precipitation" },
                      { id: "library", label: "Library Room", desc: "Warm brownian noise & distant resonances" },
                      { id: "focus", label: "Binaural Focus", desc: "Left/Right detuned sine alpha waves" },
                      { id: "digital", label: "Soft Digital", desc: "Acoustics static + metronome ticks" }
                    ].map((item) => {
                      const isPlaying = playingAmbience === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => toggleAmbience(item.id as any)}
                          className={`p-3 border text-left rounded-xl flex items-center justify-between cursor-pointer transition-all duration-300 ${
                            isPlaying
                              ? "bg-cyan-950/20 border-cyan-400 text-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.1)]"
                              : isLight
                                ? "border-slate-200 bg-slate-50/50 hover:bg-slate-100"
                                : "border-cyan-500/5 bg-slate-950/40 hover:bg-slate-900/30"
                          }`}
                        >
                          <div className="space-y-0.5">
                            <span className="text-[11px] font-bold uppercase tracking-wider block">{item.label}</span>
                            <span className="text-[8px] text-slate-500 block leading-tight">{item.desc}</span>
                          </div>
                          <div>
                            {isPlaying ? (
                              <Pause className="w-4 h-4 text-cyan-400 animate-pulse" />
                            ) : (
                              <Play className="w-4 h-4 text-slate-400" />
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Volume slider & Sound FX sandbox trigger button panel */}
                <div className={`p-4 border rounded-xl space-y-4 ${
                  isLight ? "bg-slate-50/50 border-slate-200" : "bg-slate-950/40 border-cyan-500/5"
                }`}>
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-[10px] font-bold">
                      <span className="text-slate-400 uppercase tracking-wider">Uplink Sound Level</span>
                      <span className="text-cyan-400 font-mono">{Math.round(ambienceVolume * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={ambienceVolume}
                      onChange={handleVolumeChange}
                      className="w-full accent-cyan-400 h-1 bg-cyan-950 rounded outline-none"
                    />
                  </div>

                  {/* Sound FX sandbox */}
                  <div className="space-y-2.5">
                    <span className="text-[9px] text-slate-500 uppercase tracking-widest block font-bold">Diagnostics Sound FX sandbox</span>
                    <div className="grid grid-cols-3 gap-2 text-[9px]">
                      {[
                        { id: "startup", label: "Startup" },
                        { id: "shutdown", label: "Shutdown" },
                        { id: "notification", label: "Notification" },
                        { id: "success", label: "Success" },
                        { id: "warning", label: "Warning" },
                        { id: "error", label: "Failure" }
                      ].map((sfx) => (
                        <button
                          key={sfx.id}
                          onClick={() => playSoundSFX(sfx.id)}
                          className={`p-2 border rounded-lg text-center font-bold cursor-pointer transition-all ${
                            isLight
                              ? "border-slate-300 hover:bg-slate-100"
                              : "border-cyan-500/10 bg-black/20 hover:border-cyan-500/35 hover:bg-black/40 text-slate-300"
                          }`}
                        >
                          {sfx.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 3. MULTI-MONITOR WORKSPACE LAYOUT PANELS */}
            {activeSubSection === "monitor" && (
              <div className="flex-1 flex flex-col gap-4 select-none">
                <div className="space-y-1.5">
                  <h4 className={`text-xs font-bold uppercase tracking-wider ${isLight ? "text-slate-800" : "text-slate-200"}`}>Multi-Monitor Intelligence Workspace</h4>
                  <p className="text-[10px] text-slate-500 leading-relaxed">
                    Map separate HUD dashboards to different physical displays connected to your OMEGA matrix pipeline.
                  </p>
                </div>

                {/* Display grid chassis representation */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {monitors.map((mon) => (
                    <div
                      key={mon.id}
                      className={`p-3 border rounded-xl flex flex-col items-center text-center gap-2 relative transition-all ${
                        isLight ? "bg-slate-50 border-slate-300 shadow" : "bg-slate-950/60 border-cyan-500/15"
                      }`}
                    >
                      {/* Interactive tag representing port connection details */}
                      <span className="absolute top-2 left-2 text-[7px] font-mono font-bold px-1 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-400/20">
                        {mon.port}
                      </span>
                      <span className="absolute top-2 right-2 text-[7px] font-mono text-slate-500">
                        {mon.hz}
                      </span>

                      <div className="w-16 h-10 mt-3 border border-cyan-500/30 rounded flex flex-col items-center justify-center bg-black/40 shadow-inner relative overflow-hidden">
                        {/* Simulated screen sweep scanner line */}
                        <div className="absolute top-0 left-0 w-full h-0.5 bg-cyan-400/30 animate-pulse"></div>
                        <span className="text-[7px] text-cyan-400 font-bold uppercase tracking-wide truncate max-w-[50px]">
                          {mon.activeWidget.split(" ")[0]}
                        </span>
                      </div>

                      <div className="space-y-0.5">
                        <span className="text-[10px] font-bold uppercase tracking-wider block">{mon.name}</span>
                        <span className="text-[8px] text-slate-500 block">{mon.resolution}</span>
                      </div>

                      {/* Display select option inside individual chassis */}
                      <div className="w-full mt-1">
                        <select
                          value={mon.activeWidget}
                          onChange={(e) => handleAssignWidget(mon.id, e.target.value)}
                          className={`w-full text-[9px] font-bold p-1 border rounded font-mono outline-none cursor-pointer ${
                            isLight
                              ? "bg-white border-slate-300 text-slate-700"
                              : "bg-black/60 border-cyan-500/10 text-cyan-400"
                          }`}
                        >
                          <option value="Chat Console">Chat Console</option>
                          <option value="Memory Vault">Memory Vault</option>
                          <option value="System Metrics">System Metrics</option>
                          <option value="Augmented Reality">Augmented Reality</option>
                          <option value="Diagnostics Core">Diagnostics Core</option>
                        </select>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Display connection diagnostic info box */}
                <div className={`p-4 border rounded-xl flex items-start gap-3.5 ${
                  isLight ? "bg-slate-50/50 border-slate-200" : "bg-slate-950/40 border-cyan-500/5"
                }`}>
                  <AlertCircle className="w-5 h-5 text-cyan-500 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider block text-slate-300">Port Diagnostics Footprint</span>
                    <p className="text-[9px] text-slate-400 leading-relaxed">
                      All virtual displays are locked onto standard OMEGA frequencies. Display profiles synchronized with secure HDCP 2.2 encryption matrices. No packet latency detected in DisplayPort lines.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* 4. GESTURE WEBCAM CONTROLS HUD */}
            {activeSubSection === "gestures" && (
              <div className="flex-1 flex flex-col gap-4">
                <div className="space-y-1.5">
                  <h4 className={`text-xs font-bold uppercase tracking-wider ${isLight ? "text-slate-800" : "text-slate-200"}`}>Gesture Webcam Control Center</h4>
                  <p className="text-[10px] text-slate-500 leading-relaxed">
                    Trigger custom commands, scroll mainframe views, and authorize protocols using real-time hand-skeletal tracker web feeds.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Left column: webcam projection frame simulator */}
                  <div className="flex flex-col gap-3">
                    <div className="relative border border-cyan-500/25 rounded-2xl aspect-video bg-black/80 flex flex-col items-center justify-center overflow-hidden group">
                      
                      {/* Scanning visual laser scan line */}
                      <div className="absolute top-0 left-0 w-full h-1 bg-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.8)] animate-[scan_2.8s_linear_infinite] z-20"></div>
                      
                      {/* Micro coordinates matrix overlay */}
                      <div className="absolute inset-0 bg-[radial-gradient(#22d3ee_1px,transparent_1px)] [background-size:16px_16px] opacity-10"></div>

                      {gestureWebcamActive ? (
                        <div className="relative w-full h-full flex flex-col items-center justify-center text-center p-4">
                          {/* Outer skeletal hands overlay wireframe */}
                          <div className="absolute border border-green-500/30 rounded-full w-24 h-24 animate-pulse z-10"></div>
                          <div className="absolute border border-cyan-400/20 rounded-full w-36 h-36 z-10"></div>
                          
                          <Camera className="w-8 h-8 text-cyan-400 animate-pulse mb-1.5 z-10" />
                          <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-widest z-10">Optic Optical Feed Scanning</span>
                          <span className="text-[8px] text-slate-500 font-mono mt-1 z-10">SKELETAL GRID: STABLE (21 NODES)</span>
                        </div>
                      ) : (
                        <div className="text-center p-4 flex flex-col items-center gap-1.5">
                          <Eye className="w-8 h-8 text-slate-600 mb-1" />
                          <button
                            onClick={() => {
                              setGestureWebcamActive(true);
                              companionAudioEngine.playSFX("startup");
                              addToast("WebCam Hand Skeletal Tracker active.", "success");
                            }}
                            className="px-3 py-1.5 border border-cyan-500/45 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 text-[10px] font-bold rounded-lg cursor-pointer uppercase tracking-wider"
                          >
                            Engage Webcam Feed
                          </button>
                        </div>
                      )}

                      {/* Display calibration and coordinate overlays */}
                      {gestureWebcamActive && (
                        <div className="absolute bottom-2 right-2 bg-black/80 border border-cyan-500/10 rounded px-1.5 py-0.5 text-[7px] font-mono text-cyan-400/75 z-10">
                          X_AXIS: 19.2 // Y_AXIS: 44.5
                        </div>
                      )}
                    </div>

                    {/* Calibration Sliders */}
                    <div className={`p-3 border rounded-xl space-y-2.5 ${
                      isLight ? "bg-slate-50/50 border-slate-200" : "bg-slate-950/40 border-cyan-500/5"
                    }`}>
                      <div className="space-y-1">
                        <div className="flex justify-between text-[9px] font-bold uppercase">
                          <span className="text-slate-400">Optic Gesture Sensitivity</span>
                          <span className="text-cyan-400">{sensitivity}%</span>
                        </div>
                        <input
                          type="range"
                          min="10"
                          max="100"
                          value={sensitivity}
                          onChange={(e) => setSensitivity(parseInt(e.target.value))}
                          className="w-full accent-cyan-400 h-1 bg-cyan-950 rounded"
                        />
                      </div>

                      <div className="flex items-center justify-between pt-1 select-none">
                        <span className="text-[9px] text-slate-400 uppercase font-bold">Calibration mode</span>
                        <button
                          onClick={() => {
                            setCalibrationMode(!calibrationMode);
                            companionAudioEngine.playSFX("notification");
                            addToast(calibrationMode ? "Calibration lock secure." : "Calibrating hand frames...", "info");
                          }}
                          className={`px-2 py-0.5 border text-[8px] font-bold rounded cursor-pointer uppercase ${
                            calibrationMode
                              ? "border-green-500 text-green-400"
                              : "border-cyan-500/20 text-slate-400"
                          }`}
                        >
                          {calibrationMode ? "CALIBRATING" : "CALIBRATE"}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Right column: interactive override simulator */}
                  <div className="flex flex-col gap-3">
                    <span className="text-[9px] text-slate-500 uppercase tracking-widest block font-bold">Simulated override commands list</span>
                    <div className="grid grid-cols-2 gap-1.5 text-[9px]">
                      {[
                        { gesture: "Swipe Left", action: "Previous page", color: "border-cyan-500/20 hover:border-cyan-500/55 hover:text-cyan-300" },
                        { gesture: "Swipe Right", action: "Next page", color: "border-cyan-500/20 hover:border-cyan-500/55 hover:text-cyan-300" },
                        { gesture: "Open Palm", action: "Pause synthesizers", color: "border-pink-500/20 hover:border-pink-500/55 hover:text-pink-300" },
                        { gesture: "Thumbs Up", action: "Confirm protocols", color: "border-green-500/20 hover:border-green-500/55 hover:text-green-300" },
                        { gesture: "Pinch", action: "Zoom HUD canvas", color: "border-amber-500/20 hover:border-amber-500/55 hover:text-amber-300" },
                        { gesture: "Raise Hand", action: "Trigger mic wake", color: "border-purple-500/20 hover:border-purple-500/55 hover:text-purple-300" }
                      ].map((ov) => (
                        <button
                          key={ov.gesture}
                          onClick={() => triggerSimulatedGesture(ov.gesture, ov.action)}
                          className={`p-2.5 border rounded-xl text-left cursor-pointer transition-all ${ov.color} bg-black/10`}
                        >
                          <span className="font-bold block tracking-wide">{ov.gesture}</span>
                          <span className="text-[8px] text-slate-500 block truncate">{ov.action}</span>
                        </button>
                      ))}
                    </div>

                    {/* Real-time event logger */}
                    <div className="space-y-1.5">
                      <span className="text-[8px] text-slate-500 uppercase tracking-widest block font-bold">Optic Gesture Event Logs</span>
                      <div className="bg-black/50 border border-cyan-500/5 rounded-lg p-3 max-h-[100px] overflow-y-auto text-[8px] space-y-1 scrollbar-thin">
                        {gestureLogs.map((log, idx) => (
                          <div key={idx} className="flex items-center justify-between text-slate-300">
                            <span className="text-slate-500 font-mono">{log.time}</span>
                            <span className="font-bold text-cyan-400">{log.gesture}</span>
                            <span className="text-slate-400">{log.action}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 5. AR VOLUMETRIC SANDBOXES */}
            {activeSubSection === "ar" && (
              <div className="flex-1 flex flex-col gap-4">
                <div className="space-y-1.5">
                  <h4 className={`text-xs font-bold uppercase tracking-wider ${isLight ? "text-slate-800" : "text-slate-200"}`}>Augmented Reality Volumetric View</h4>
                  <p className="text-[10px] text-slate-500 leading-relaxed">
                    Projects a simulated volumetric projection of OMEGA’s core dashboard and widgets pinned directly to three-dimensional coordinate spaces.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Left Column: Phone AR perspective representation */}
                  <div className="border border-cyan-500/20 rounded-2xl relative aspect-square md:aspect-auto md:h-[300px] bg-[#02070f] flex flex-col items-center justify-center overflow-hidden">
                    
                    {/* Volumetric grid floor mesh */}
                    <div className="absolute inset-0 bg-[linear-gradient(rgba(34,211,238,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(34,211,238,0.02)_1px,transparent_1px)] [background-size:24px_24px] transform -rotate-x-45 origin-bottom opacity-20"></div>

                    {/* Floating translucent core mesh */}
                    <motion.div
                      animate={{
                        y: [-12, 12, -12],
                        rotateY: [0, 360],
                      }}
                      transition={{
                        y: { duration: 6, ease: "easeInOut", repeat: Infinity },
                        rotateY: { duration: 18, ease: "linear", repeat: Infinity }
                      }}
                      style={{
                        scale: arScale,
                        rotateZ: `${arRotation}deg`
                      }}
                      className="w-20 h-20 border border-cyan-400/40 rounded-full flex items-center justify-center bg-cyan-950/15 shadow-[0_0_24px_rgba(34,211,238,0.2)] relative z-10"
                    >
                      <div className="w-10 h-10 border border-purple-500/30 rounded-full animate-ping absolute"></div>
                      <Cpu className="w-6 h-6 text-cyan-400 animate-pulse" />
                    </motion.div>

                    {/* Pinned floats */}
                    <AnimatePresence>
                      {pinnedARWidgets.weather && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute top-10 left-6 bg-slate-950/80 border border-cyan-500/20 rounded p-2 text-[8px] z-20 text-cyan-400">
                          <span className="font-bold block uppercase">AR_WEATHER</span>
                          <span>24°C // Sunny</span>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    <AnimatePresence>
                      {pinnedARWidgets.calendar && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute top-10 right-6 bg-slate-950/80 border border-cyan-500/20 rounded p-2 text-[8px] z-20 text-cyan-400">
                          <span className="font-bold block uppercase">AR_CALENDAR</span>
                          <span>Keynote @ 8PM</span>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    <AnimatePresence>
                      {pinnedARWidgets.notifications && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute bottom-12 left-6 bg-slate-950/80 border border-cyan-500/20 rounded p-2 text-[8px] z-20 text-cyan-400">
                          <span className="font-bold block uppercase">AR_ALERTS</span>
                          <span>3 Pending Logs</span>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Camera Filter Overlay tags */}
                    <div className="absolute top-2 left-2 flex gap-1 z-20">
                      <span className="bg-cyan-950 px-1 py-0.5 rounded text-[7px] font-bold text-cyan-400 border border-cyan-400/25">
                        FILTER: {arCameraFilter.toUpperCase()}
                      </span>
                    </div>
                  </div>

                  {/* Right Column: sliders, widget pins */}
                  <div className="space-y-4">
                    {/* Widget pin triggers */}
                    <div className="space-y-2">
                      <span className="text-[9px] text-slate-500 uppercase tracking-widest block font-bold">Pin widgets in AR viewport</span>
                      <div className="grid grid-cols-2 gap-1.5 text-[9px] select-none">
                        {[
                          { id: "weather", label: "Weather Forecast" },
                          { id: "calendar", label: "Calendar Schedules" },
                          { id: "notifications", label: "Alert Stream" },
                          { id: "coreGauges", label: "Core telemetry" }
                        ].map((item) => {
                          const isPinned = (pinnedARWidgets as any)[item.id];
                          return (
                            <button
                              key={item.id}
                              onClick={() => {
                                setPinnedARWidgets({ ...pinnedARWidgets, [item.id]: !isPinned });
                                companionAudioEngine.playSFX("notification");
                              }}
                              className={`p-2 border rounded-lg text-left font-bold cursor-pointer transition-all ${
                                isPinned
                                  ? "border-cyan-500 text-cyan-400 bg-cyan-950/10"
                                  : "border-cyan-500/5 bg-black/25 hover:border-cyan-500/20"
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <span>{item.label}</span>
                                {isPinned && <Check className="w-3 h-3 text-cyan-400" />}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Coordinates settings sliders */}
                    <div className={`p-4 border rounded-xl space-y-3.5 ${
                      isLight ? "bg-slate-50/50 border-slate-200" : "bg-slate-950/40 border-cyan-500/5"
                    }`}>
                      <span className="text-[9px] text-slate-500 uppercase tracking-widest block font-bold leading-none">AR Spatial Coordinates</span>
                      
                      <div className="grid grid-cols-2 gap-3 text-[10px]">
                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span className="text-slate-400">Position X (m)</span>
                            <span className="text-cyan-400">{arX.toFixed(1)}</span>
                          </div>
                          <input type="range" min="-5" max="5" step="0.5" value={arX} onChange={(e) => setArX(parseFloat(e.target.value))} className="w-full accent-cyan-400" />
                        </div>

                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span className="text-slate-400">Position Y (m)</span>
                            <span className="text-cyan-400">{arY.toFixed(1)}</span>
                          </div>
                          <input type="range" min="0" max="5" step="0.2" value={arY} onChange={(e) => setArY(parseFloat(e.target.value))} className="w-full accent-cyan-400" />
                        </div>

                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span className="text-slate-400">Scale factor</span>
                            <span className="text-cyan-400">{arScale.toFixed(1)}x</span>
                          </div>
                          <input type="range" min="0.5" max="2.5" step="0.1" value={arScale} onChange={(e) => setArScale(parseFloat(e.target.value))} className="w-full accent-cyan-400" />
                        </div>

                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span className="text-slate-400">Pitch rotation</span>
                            <span className="text-cyan-400">{arRotation}°</span>
                          </div>
                          <input type="range" min="0" max="360" step="5" value={arRotation} onChange={(e) => setArRotation(parseInt(e.target.value))} className="w-full accent-cyan-400" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 6. PLUGIN MARKETPLACE PORTAL */}
            {activeSubSection === "marketplace" && (
              <div className="flex-1 flex flex-col gap-4">
                <div className="space-y-1.5">
                  <h4 className={`text-xs font-bold uppercase tracking-wider ${isLight ? "text-slate-800" : "text-slate-200"}`}>Plugin Secure Marketplace</h4>
                  <p className="text-[10px] text-slate-500 leading-relaxed">
                    Install secure binary packages and system connectors verified by OMEGA protocols to expand JARVIS’s baseline toolkits.
                  </p>
                </div>

                {/* Filter and search controllers */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <div className="flex-1 relative">
                    <input
                      type="text"
                      placeholder="Search plug-in registry..."
                      value={searchPluginQuery}
                      onChange={(e) => setSearchPluginQuery(e.target.value)}
                      className={`w-full text-[10px] pl-8 pr-3 py-1.5 rounded-lg border outline-none font-mono ${
                        isLight 
                          ? "bg-white border-slate-300 focus:border-cyan-500 text-slate-700" 
                          : "bg-slate-950/80 border-cyan-500/25 focus:border-cyan-400 text-slate-300"
                      }`}
                    />
                    <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
                  </div>
                  
                  <div className="flex gap-1 overflow-x-auto scrollbar-none pb-1">
                    {[
                      { id: "all", label: "All" },
                      { id: "productivity", label: "Productivity" },
                      { id: "coding", label: "Coding" },
                      { id: "finance", label: "Finance" },
                      { id: "education", label: "Education" }
                    ].map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => {
                          setSelectedPluginCategory(cat.id as any);
                          companionAudioEngine.playSFX("notification");
                        }}
                        className={`px-2.5 py-1 text-[9px] font-bold border rounded-md cursor-pointer uppercase ${
                          selectedPluginCategory === cat.id
                            ? "border-cyan-500 text-cyan-400 bg-cyan-950/15"
                            : "border-cyan-500/5 bg-black/25 hover:border-cyan-500/20"
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Plugin Cards List */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 flex-1 overflow-y-auto max-h-[220px] pr-1 scrollbar-thin">
                  {filteredPlugins.map((plugin) => (
                    <div
                      key={plugin.id}
                      className={`p-3.5 border rounded-xl flex flex-col justify-between gap-3 ${
                        isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/50 border-cyan-500/10"
                      }`}
                    >
                      <div className="space-y-1.5 text-[10px]">
                        <div className="flex items-center justify-between">
                          <span className={`font-bold uppercase tracking-wider block text-xs ${isLight ? "text-slate-800" : "text-cyan-200"}`}>
                            {plugin.name}
                          </span>
                          <span className="text-[8px] text-slate-500 font-mono">
                            {plugin.version}
                          </span>
                        </div>
                        <p className="text-[9px] text-slate-400 leading-relaxed">
                          {plugin.desc}
                        </p>

                        <div className="flex flex-wrap gap-1 pt-1 select-none">
                          {plugin.permissions.map((perm) => (
                            <span key={perm} className="text-[7px] font-mono px-1.5 py-0.5 rounded bg-black/40 text-slate-500 border border-slate-800 uppercase leading-none">
                              {perm}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-between border-t border-cyan-500/5 pt-2 select-none">
                        <div className="text-[8px] text-slate-500">
                          Rating: <span className="text-cyan-400 font-bold">{plugin.rating}★</span> ({plugin.downloads} downloads)
                        </div>

                        {plugin.installed ? (
                          <button
                            onClick={() => handleRemovePlugin(plugin.id, plugin.name)}
                            className="px-2.5 py-1 text-[9px] font-bold text-red-400 border border-red-500/30 hover:bg-red-950/20 rounded cursor-pointer uppercase flex items-center gap-1.5"
                          >
                            <Trash2 className="w-3 h-3" />
                            Uninstall
                          </button>
                        ) : (
                          <button
                            disabled={plugin.installing}
                            onClick={() => handleInstallPlugin(plugin.id)}
                            className={`px-2.5 py-1 text-[9px] font-bold text-cyan-400 border border-cyan-500/40 bg-cyan-500/10 hover:bg-cyan-500/25 rounded cursor-pointer uppercase flex items-center gap-1.5 ${
                              plugin.installing ? "animate-pulse cursor-wait" : ""
                            }`}
                          >
                            {plugin.installing ? (
                              <>
                                <RefreshCw className="w-3 h-3 animate-spin" />
                                Installing...
                              </>
                            ) : (
                              <>
                                <Download className="w-3 h-3" />
                                Install
                              </>
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 7. ADVANCED VOICE CORE */}
            {activeSubSection === "voice" && (
              <div className="flex-1 flex flex-col gap-4 overflow-y-auto max-h-[500px] xl:max-h-full pr-1 scrollbar-thin">
                <style>{`
                  @keyframes pulse-wave {
                    0% { transform: scaleY(0.3); opacity: 0.5; }
                    100% { transform: scaleY(1.1); opacity: 1; }
                  }
                `}</style>

                <div className="flex items-center justify-between border-b border-cyan-500/10 pb-2">
                  <div className="space-y-1">
                    <h4 className={`text-xs font-bold uppercase tracking-wider ${isLight ? "text-slate-800" : "text-slate-200"} flex items-center gap-1.5`}>
                      <Mic className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                      Advanced Cognitive Voice Core
                    </h4>
                    <p className="text-[10px] text-slate-500 leading-relaxed">
                      Continuous auditory standby matrices, low-power Porcupine wake word detection, and high-fidelity speech synthesis.
                    </p>
                  </div>
                  
                  {/* Global stand-by indicator */}
                  <div className="flex items-center gap-2">
                    <span className="flex h-2 w-2 relative">
                      <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isWakeWordMonitoring || isSTTListening ? "bg-green-400" : "bg-amber-400"}`}></span>
                      <span className={`relative inline-flex rounded-full h-2 w-2 ${isWakeWordMonitoring || isSTTListening ? "bg-green-500" : "bg-amber-500"}`}></span>
                    </span>
                    <span className="text-[8px] font-mono uppercase tracking-widest text-slate-400">
                      {isSTTListening ? "Listening" : isWakeWordMonitoring ? "Sentinel Standby" : "Online"}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
                  {/* Left panel: configurations - spans 7 cols */}
                  <div className="xl:col-span-7 space-y-4">
                    
                    {/* WAKE WORD CARD */}
                    <div className={`p-4 border rounded-xl space-y-3.5 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/40 border-cyan-500/10"}`}>
                      <div className="flex items-center justify-between">
                        <span className={`text-[10px] font-bold uppercase tracking-widest block ${isLight ? "text-slate-700" : "text-cyan-400"}`}>
                          Porcupine Wake Word System
                        </span>
                        <div className="flex items-center gap-1.5">
                          <input
                            type="checkbox"
                            id="porcupine-enable"
                            checked={porcupineEnabled}
                            onChange={(e) => setPorcupineEnabled(e.target.checked)}
                            className="rounded border-slate-800 text-cyan-500 focus:ring-cyan-400 w-3 h-3 bg-black cursor-pointer"
                          />
                          <label htmlFor="porcupine-enable" className="text-[9px] font-mono text-slate-500 cursor-pointer">CONTINUOUS DSP</label>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                        <div className="space-y-1">
                          <label className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block">Wake phrase Selection</label>
                          <select
                            value={wakeWord}
                            onChange={(e: any) => setWakeWord(e.target.value)}
                            className={`w-full text-[10px] p-1.5 rounded-md border outline-none font-mono ${
                              isLight ? "bg-white border-slate-300 text-slate-700" : "bg-black border-cyan-500/15 text-slate-300"
                            }`}
                          >
                            <option value="Hey JARVIS">"Hey JARVIS" (Optimized)</option>
                            <option value="JARVIS">"JARVIS" (High Sensitivity)</option>
                            <option value="custom">Custom Wake Phrase...</option>
                          </select>
                        </div>

                        {wakeWord === "custom" && (
                          <div className="space-y-1">
                            <label className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block">Custom Phrase</label>
                            <input
                              type="text"
                              value={customWakeWord}
                              onChange={(e) => setCustomWakeWord(e.target.value)}
                              className={`w-full text-[10px] p-1.5 rounded-md border outline-none font-mono ${
                                isLight ? "bg-white border-slate-300 text-slate-700" : "bg-black border-cyan-500/15 text-cyan-400"
                              }`}
                            />
                          </div>
                        )}
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-[9px] font-mono text-slate-400">
                          <span>Wake-Word Acoustic Sensitivity</span>
                          <span className="text-cyan-400 font-bold">{wakeWordSensitivity}%</span>
                        </div>
                        <input
                          type="range"
                          min="30"
                          max="95"
                          value={wakeWordSensitivity}
                          onChange={(e) => setWakeWordSensitivity(parseInt(e.target.value))}
                          className="w-full accent-cyan-500 bg-cyan-950/20 h-1 rounded-lg cursor-pointer"
                        />
                      </div>

                      <div className="flex flex-col sm:flex-row gap-3 pt-1 select-none">
                        <button
                          onClick={startWakeWordSentinel}
                          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-[10px] font-mono uppercase font-black rounded-lg border transition-all duration-300 cursor-pointer ${
                            isWakeWordMonitoring
                              ? "bg-amber-500/15 border-amber-500/50 text-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.15)] animate-pulse"
                              : "bg-cyan-500/10 border-cyan-500/30 hover:bg-cyan-500/20 text-cyan-400"
                          }`}
                        >
                          <Power className="w-3.5 h-3.5" />
                          {isWakeWordMonitoring ? "Shutdown Wake Sentinel" : "Activate Wake Sentinel Standby"}
                        </button>
                        
                        <div className="flex items-center gap-2 px-2 py-1 bg-black/20 rounded-md border border-cyan-500/5 sm:w-auto w-full justify-between sm:justify-start">
                          <span className="text-[8px] font-mono text-slate-500 uppercase">Energy saver</span>
                          <button
                            onClick={() => setConserveBattery(!conserveBattery)}
                            className={`px-1.5 py-0.5 rounded text-[8px] font-bold font-mono transition-colors uppercase ${
                              conserveBattery ? "bg-green-500/20 border border-green-500/40 text-green-400" : "bg-slate-800 border border-slate-700 text-slate-400"
                            }`}
                          >
                            {conserveBattery ? "Low-Power Porcupine" : "Performance DSP"}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* SPEECH TO TEXT CONFIG */}
                    <div className={`p-4 border rounded-xl space-y-3.5 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/40 border-cyan-500/10"}`}>
                      <span className={`text-[10px] font-bold uppercase tracking-widest block ${isLight ? "text-slate-700" : "text-cyan-400"}`}>
                        Speech-to-Text (Acoustic Capture)
                      </span>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                        <div className="space-y-1">
                          <label className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block">Transcription Engine</label>
                          <select
                            value={sttEngine}
                            onChange={(e: any) => setSttEngine(e.target.value)}
                            className={`w-full text-[10px] p-1.5 rounded-md border outline-none font-mono ${
                              isLight ? "bg-white border-slate-300 text-slate-700" : "bg-black border-cyan-500/15 text-slate-300"
                            }`}
                          >
                            <option value="web_speech">Web Speech API (Streaming)</option>
                            <option value="whisper">Whisper (High-Fidelity Cloud)</option>
                            <option value="vosk">Vosk (Secure Offline Native)</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block">Linguistic Matrix</label>
                          <select
                            value={sttLanguage}
                            onChange={(e) => setSttLanguage(e.target.value)}
                            className={`w-full text-[10px] p-1.5 rounded-md border outline-none font-mono ${
                              isLight ? "bg-white border-slate-300 text-slate-700" : "bg-black border-cyan-500/15 text-slate-300"
                            }`}
                          >
                            <option value="en-US">English (US)</option>
                            <option value="es-ES">Spanish (ES)</option>
                            <option value="fr-FR">French (FR)</option>
                            <option value="de-DE">German (DE)</option>
                            <option value="ja-JP">Japanese (JP)</option>
                            <option value="zh-CN">Chinese (CN)</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 select-none">
                        <div className="flex items-center justify-between p-2 bg-black/20 rounded-md border border-cyan-500/5">
                          <div className="space-y-0.5">
                            <div className="text-[9px] font-bold font-mono uppercase tracking-wider text-slate-300">Acoustic Noise Suppressor</div>
                            <div className="text-[7px] text-slate-500 leading-none">Filter ambient workspace noise</div>
                          </div>
                          <button
                            onClick={() => setNoiseCancellation(!noiseCancellation)}
                            className={`px-1.5 py-0.5 rounded text-[8px] font-bold font-mono uppercase ${
                              noiseCancellation ? "bg-green-500/20 text-green-400 border border-green-500/30" : "bg-slate-800 text-slate-500"
                            }`}
                          >
                            {noiseCancellation ? "Enabled" : "Disabled"}
                          </button>
                        </div>

                        <div className="flex items-center justify-between p-2 bg-black/20 rounded-md border border-cyan-500/5">
                          <div className="space-y-0.5">
                            <div className="text-[9px] font-bold font-mono uppercase tracking-wider text-slate-300">Real-time Streaming</div>
                            <div className="text-[7px] text-slate-500 leading-none">Display transcripts instantaneously</div>
                          </div>
                          <button
                            onClick={() => setStreamingRecognition(!streamingRecognition)}
                            className={`px-1.5 py-0.5 rounded text-[8px] font-bold font-mono uppercase ${
                              streamingRecognition ? "bg-green-500/20 text-green-400 border border-green-500/30" : "bg-slate-800 text-slate-500"
                            }`}
                          >
                            {streamingRecognition ? "Enabled" : "Disabled"}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* TEXT TO SPEECH CONFIG */}
                    <div className={`p-4 border rounded-xl space-y-3.5 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/40 border-cyan-500/10"}`}>
                      <span className={`text-[10px] font-bold uppercase tracking-widest block ${isLight ? "text-slate-700" : "text-cyan-400"}`}>
                        Text-to-Speech (Vocal Matrices)
                      </span>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                        <div className="space-y-1">
                          <label className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block">Vocal Engine</label>
                          <select
                            value={ttsEngine}
                            onChange={(e: any) => setTtsEngine(e.target.value)}
                            className={`w-full text-[10px] p-1.5 rounded-md border outline-none font-mono ${
                              isLight ? "bg-white border-slate-300 text-slate-700" : "bg-black border-cyan-500/15 text-slate-300"
                            }`}
                          >
                            <option value="web_speech">Web Synthesis (Real-time)</option>
                            <option value="piper">Piper TTS (Standard)</option>
                            <option value="coqui">Coqui TTS (Deep Voice)</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block">Avatar Identity</label>
                          <select
                            value={ttsVoice}
                            onChange={(e: any) => setTtsVoice(e.target.value)}
                            className={`w-full text-[10px] p-1.5 rounded-md border outline-none font-mono ${
                              isLight ? "bg-white border-slate-300 text-slate-700" : "bg-black border-cyan-500/15 text-slate-300"
                            }`}
                          >
                            <option value="male">JARVIS (Baritone)</option>
                            <option value="female">Aria (Empathetic)</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block">Emotional Preset</label>
                          <select
                            value={emotionalTone}
                            onChange={(e: any) => setEmotionalTone(e.target.value)}
                            className={`w-full text-[10px] p-1.5 rounded-md border outline-none font-mono ${
                              isLight ? "bg-white border-slate-300 text-slate-700" : "bg-black border-cyan-500/15 text-slate-300"
                            }`}
                          >
                            <option value="calm">Calm Analytical</option>
                            <option value="friendly">Friendly Assistant</option>
                            <option value="sarcastic">Sarcastic Sentinel</option>
                            <option value="energetic">Energetic Surge</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                        <div className="space-y-2">
                          <div className="flex justify-between text-[9px] font-mono text-slate-400">
                            <span>Vocal Speed Rate</span>
                            <span className="text-cyan-400 font-bold">{ttsSpeed}x</span>
                          </div>
                          <input
                            type="range"
                            min="0.5"
                            max="2.0"
                            step="0.1"
                            value={ttsSpeed}
                            onChange={(e) => setTtsSpeed(parseFloat(e.target.value))}
                            className="w-full accent-cyan-500 bg-cyan-950/20 h-1 rounded-lg cursor-pointer"
                          />
                        </div>

                        <div className="space-y-2">
                          <div className="flex justify-between text-[9px] font-mono text-slate-400">
                            <span>Vocal Pitch Offset</span>
                            <span className="text-cyan-400 font-bold">{ttsPitch}x</span>
                          </div>
                          <input
                            type="range"
                            min="0.5"
                            max="1.5"
                            step="0.1"
                            value={ttsPitch}
                            onChange={(e) => setTtsPitch(parseFloat(e.target.value))}
                            className="w-full accent-cyan-500 bg-cyan-950/20 h-1 rounded-lg cursor-pointer"
                          />
                        </div>

                        <div className="space-y-2">
                          <div className="flex justify-between text-[9px] font-mono text-slate-400">
                            <span>Volume Threshold</span>
                            <span className="text-cyan-400 font-bold">{Math.round(ttsVolume * 100)}%</span>
                          </div>
                          <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.05"
                            value={ttsVolume}
                            onChange={(e) => setTtsVolume(parseFloat(e.target.value))}
                            className="w-full accent-cyan-500 bg-cyan-950/20 h-1 rounded-lg cursor-pointer"
                          />
                        </div>
                      </div>

                      <div className="flex justify-between select-none pt-1">
                        <div className="flex gap-2">
                          <button
                            onClick={playVoiceTest}
                            className="px-3.5 py-1.5 text-[9px] font-mono font-bold text-cyan-400 border border-cyan-500/30 hover:bg-cyan-500/10 rounded-lg cursor-pointer uppercase flex items-center gap-1.5"
                          >
                            <Volume1 className="w-3.5 h-3.5" />
                            Calibrate & Test Speech
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right panel: Live interaction, logs, visual wave - spans 5 cols */}
                  <div className="xl:col-span-5 space-y-4 flex flex-col">
                    
                    {/* VISUAL WAVE / CAPTURER */}
                    <div className={`p-4 border rounded-xl space-y-3.5 flex flex-col justify-between ${
                      isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/40 border-cyan-500/10"
                    }`}>
                      <div className="flex items-center justify-between">
                        <span className={`text-[10px] font-bold uppercase tracking-widest block ${isLight ? "text-slate-700" : "text-cyan-400"}`}>
                          Real-time Voice Capture
                        </span>
                        
                        <div className="flex gap-1.5 select-none">
                          <button
                            onClick={() => setContinuousConversation(!continuousConversation)}
                            className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-bold uppercase ${
                              continuousConversation ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30" : "bg-slate-800 text-slate-500"
                            }`}
                          >
                            Continuous
                          </button>
                          <button
                            onClick={() => setVoiceInterruption(!voiceInterruption)}
                            className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-bold uppercase ${
                              voiceInterruption ? "bg-red-500/20 text-red-400 border border-red-500/30" : "bg-slate-800 text-slate-500"
                            }`}
                          >
                            Interruptible
                          </button>
                        </div>
                      </div>

                      {/* Animated visual wave widget */}
                      <div className="h-[75px] bg-black/35 rounded-xl border border-cyan-500/5 relative overflow-hidden flex items-center justify-center">
                        {isSTTListening ? (
                          <div className="flex items-center gap-1">
                            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1].map((item, idx) => {
                              const delay = idx * 0.04;
                              const randHeight = [12, 28, 48, 16, 32, 54, 20, 42, 60, 24][idx % 10];
                              return (
                                <div
                                  key={idx}
                                  style={{
                                    animation: `pulse-wave 0.8s ease-in-out infinite alternate`,
                                    animationDelay: `${delay}s`,
                                    height: `${randHeight}px`
                                  }}
                                  className="w-[3px] rounded bg-gradient-to-t from-cyan-500 via-teal-400 to-emerald-400 shadow-[0_0_8px_rgba(6,182,212,0.3)]"
                                ></div>
                              );
                            })}
                          </div>
                        ) : isWakeWordMonitoring ? (
                          <div className="flex items-center gap-1.5">
                            <span className="flex h-1.5 w-1.5 relative">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-amber-500"></span>
                            </span>
                            <span className="text-[9px] font-mono text-amber-500 uppercase tracking-wider animate-pulse">Acoustic wake word listener online</span>
                          </div>
                        ) : (
                          <span className="text-[9px] font-mono text-slate-600 uppercase tracking-wider">Acoustic Matrix Deactivated</span>
                        )}

                        <div className="absolute bottom-1 right-2">
                          <span className="text-[7px] font-mono text-slate-500 block">MIC_GAIN: 1.0 // WAVE_HERTZ</span>
                        </div>
                      </div>

                      {/* Microphone Selector block */}
                      <div className="space-y-1">
                        <label className="text-[8px] font-mono text-slate-500 uppercase tracking-wider block">Acoustic Mic Source</label>
                        <select
                          value={selectedMic}
                          onChange={(e) => {
                            setSelectedMic(e.target.value);
                            companionAudioEngine.playSFX("notification");
                          }}
                          className={`w-full text-[9px] p-1.5 rounded-md border outline-none font-mono ${
                            isLight ? "bg-white border-slate-300 text-slate-700" : "bg-black border-cyan-500/10 text-slate-300"
                          }`}
                        >
                          {microphones.length === 0 ? (
                            <option value="">Default System Microphone (Internal)</option>
                          ) : (
                            microphones.map((mic) => (
                              <option key={mic.deviceId} value={mic.deviceId}>{mic.label || `Microphone (${mic.deviceId.slice(0,6)})`}</option>
                            ))
                          )}
                        </select>
                      </div>

                      {/* PTT and Active speech buttons */}
                      <div className="flex gap-2.5 select-none pt-1">
                        <button
                          onClick={startVoiceSTT}
                          className={`flex-1 py-2 px-3 text-[10px] font-mono font-bold uppercase rounded-lg border flex items-center justify-center gap-1.5 cursor-pointer transition-all duration-300 ${
                            isSTTListening
                              ? "bg-red-500/10 border-red-500/40 text-red-400 shadow-[0_0_12px_rgba(239,68,68,0.15)] animate-pulse"
                              : "bg-cyan-500/15 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/25"
                          }`}
                        >
                          <Mic className="w-3.5 h-3.5" />
                          {isSTTListening ? "Stop Listening" : "Push-To-Talk Capture"}
                        </button>
                      </div>

                      {sttTranscript && (
                        <div className="p-2 bg-black/45 rounded-lg border border-cyan-500/10">
                          <span className="text-[8px] font-mono text-slate-500 block uppercase">Capturing Speech:</span>
                          <span className="text-[10px] font-mono text-cyan-300 leading-relaxed block italic">"{sttTranscript}"</span>
                        </div>
                      )}
                    </div>

                    {/* SANDBOX DIALOGUE TERMINAL */}
                    <div className={`p-4 border rounded-xl flex-1 flex flex-col justify-between min-h-[220px] ${
                      isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/40 border-cyan-500/10"
                    }`}>
                      <div className="flex items-center justify-between border-b border-cyan-500/5 pb-1.5 mb-2.5">
                        <span className={`text-[10px] font-bold uppercase tracking-widest block ${isLight ? "text-slate-700" : "text-cyan-400"}`}>
                          Acoustic Sandbox Terminal
                        </span>
                        
                        <button
                          onClick={() => {
                            setVoiceLogs([{ role: "model", content: "Auditory logger cleared.", timestamp: new Date().toLocaleTimeString() }]);
                            companionAudioEngine.playSFX("warning");
                          }}
                          className="text-[8px] font-mono text-red-400 hover:underline uppercase"
                        >
                          Clear
                        </button>
                      </div>

                      {/* Scroller Dialog box */}
                      <div className="flex-1 overflow-y-auto max-h-[120px] space-y-2 pr-1 scrollbar-thin font-mono text-[9px] mb-2.5 select-text">
                        {voiceLogs.map((log, idx) => (
                          <div key={idx} className={`p-1.5 rounded-md border ${
                            log.role === "user"
                              ? isLight ? "bg-slate-200 border-slate-300 text-slate-800" : "bg-cyan-950/20 border-cyan-500/10 text-cyan-300"
                              : isLight ? "bg-white border-slate-200 text-slate-500" : "bg-black/30 border-slate-800 text-slate-400"
                          }`}>
                            <div className="flex justify-between items-center mb-0.5 opacity-60 text-[7px]">
                              <span className="font-bold">{log.role === "user" ? "USER_UPLINK" : "JARVIS_CORE"}</span>
                              <span>{log.timestamp}</span>
                            </div>
                            <div className="leading-relaxed whitespace-pre-wrap">{log.content}</div>
                          </div>
                        ))}
                      </div>

                      {/* Text manual override input */}
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Type simulated voice command (e.g. 'run the backend', 'open chrome')..."
                          value={voiceInputText}
                          onChange={(e) => setVoiceInputText(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" && voiceInputText.trim()) {
                              processVoiceCommand(voiceInputText.trim());
                              setVoiceInputText("");
                            }
                          }}
                          className={`flex-1 text-[9px] px-2 py-1.5 rounded border outline-none font-mono ${
                            isLight
                              ? "bg-white border-slate-300 text-slate-800"
                              : "bg-black/40 border-cyan-500/10 focus:border-cyan-400 text-slate-300"
                          }`}
                        />
                        <button
                          onClick={() => {
                            if (voiceInputText.trim()) {
                              processVoiceCommand(voiceInputText.trim());
                              setVoiceInputText("");
                            }
                          }}
                          className="px-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-[9px] uppercase font-bold rounded cursor-pointer select-none"
                        >
                          Simulate
                        </button>
                      </div>

                      {/* Hands-Free Permissions Manager Matrix */}
                      <div className="mt-4 pt-3 border-t border-cyan-500/5 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-bold font-mono text-slate-400 uppercase tracking-wide">Hands-Free Operator Permissions Matrix</span>
                          <button
                            onClick={() => {
                              const nextPerms = {
                                microphone: "granted" as const,
                                accessibility: "granted" as const,
                                fileSystem: "granted" as const,
                                screen: "granted" as const,
                                appControl: "granted" as const,
                                browserAutomation: "granted" as const,
                              };
                              saveAgentPermissions(nextPerms);
                              addToast("All agent operation permissions authorized successfully.", "success");
                            }}
                            className="text-[8px] font-mono text-cyan-400 hover:underline uppercase font-bold"
                          >
                            Authorize All Nodes
                          </button>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-1.5 font-mono text-[8px]">
                          {Object.entries(agentPermissions).map(([key, value]) => (
                            <div
                              key={key}
                              className={`flex items-center justify-between p-1.5 rounded border ${
                                isLight
                                  ? "bg-slate-50 border-slate-200"
                                  : "bg-black/30 border-cyan-500/5 hover:border-cyan-500/10"
                              }`}
                            >
                              <span className="text-slate-400 uppercase font-semibold">{key.replace(/([A-Z])/g, "_$1")}</span>
                              <button
                                onClick={async () => {
                                  if (key === "microphone") {
                                    try {
                                      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                                      stream.getTracks().forEach(track => track.stop());
                                    } catch (e) {
                                      console.warn("Microphone access check failed:", e);
                                    }
                                  }
                                  const nextPerms = {
                                    ...agentPermissions,
                                    [key]: value === "granted" ? "prompt" as const : "granted" as const
                                  };
                                  saveAgentPermissions(nextPerms);
                                  addToast(`${key} permission updated to ${value === "granted" ? "PROMPT" : "GRANTED"}.`, "info");
                                }}
                                className={`px-1.5 py-0.5 rounded uppercase font-bold text-[7px] cursor-pointer ${
                                  value === "granted"
                                    ? "bg-green-500/10 text-green-400 border border-green-500/20"
                                    : value === "denied"
                                    ? "bg-red-500/10 text-red-400 border border-red-500/20"
                                    : "bg-amber-500/10 text-amber-500 border border-amber-500/20"
                                }`}
                              >
                                {value}
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Technical specifications system specs */}
                      <div className={`mt-4 p-2.5 rounded-lg border font-mono ${isLight ? "bg-slate-50 border-slate-200 text-slate-600" : "bg-black/30 border-cyan-500/5 text-slate-500"} text-[8px]`}>
                        <div className="flex items-center gap-1.5 font-bold uppercase text-slate-400 mb-1.5">
                          <Cpu className="w-3 h-3 text-cyan-400" />
                          Sir's Local Companion Workstation Stack
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                          <div className="space-y-0.5">
                            <span className="text-cyan-400/80 font-bold">DESKTOP CONTROLLER</span>
                            <p className="leading-snug text-slate-400">Python 3.11 / FastAPI / PyAutoGUI / psutil / Playwright / keyboard & mouse events</p>
                          </div>
                          <div className="space-y-0.5">
                            <span className="text-cyan-400/80 font-bold">ANDROID CORE NODE</span>
                            <p className="leading-snug text-slate-400">Accessibility Service / Notification Listener / Storage Scanner / AudioRecord mic stream</p>
                          </div>
                          <div className="space-y-0.5">
                            <span className="text-cyan-400/80 font-bold">GATEWAY LINK</span>
                            <p className="leading-snug text-slate-400">Continuous WebSockets (port 3000 proxy) / WebRTC media stream / local system services</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* HELP CARD: QUICK OPERATOR VOICE SHORTCUTS GUIDELINE */}
                <div className={`p-3 border rounded-xl space-y-1.5 ${isLight ? "bg-slate-100/50 border-slate-200" : "bg-black/30 border-cyan-500/5"}`}>
                  <div className="flex items-center gap-1.5 text-[9px] font-mono text-slate-400 uppercase font-bold select-none">
                    <Info className="w-3.5 h-3.5 text-cyan-400" />
                    JARVIS OMEGA Hands-Free Operator Shortcut Catalog
                  </div>
                  <p className="text-[8px] text-slate-500 leading-relaxed font-mono">
                    Speak or simulate these explicit verbal phrasing categories to operate your local workstations directly:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-2 text-[8px] font-mono select-none">
                    <div className="p-2 bg-black/25 rounded border border-cyan-500/5 space-y-1">
                      <div className="text-cyan-400 font-bold uppercase text-[7px]">1. Device Control</div>
                      <div className="text-slate-300 font-semibold">"Open Chrome" / "Open VS Code" / "Increase volume" / "Lock PC"</div>
                      <div className="text-slate-500 text-[7px] leading-tight">Controls windows, launches apps via PyAutoGUI & psutil.</div>
                    </div>
                    <div className="p-2 bg-black/25 rounded border border-cyan-500/5 space-y-1">
                      <div className="text-cyan-400 font-bold uppercase text-[7px]">2. File Operations</div>
                      <div className="text-slate-300 font-semibold">"Create folder named Physics Notes" / "Search computer for JEE formulas"</div>
                      <div className="text-slate-500 text-[7px] leading-tight">Performs local os/shutil creation, renaming and crawls.</div>
                    </div>
                    <div className="p-2 bg-black/25 rounded border border-cyan-500/5 space-y-1">
                      <div className="text-cyan-400 font-bold uppercase text-[7px]">3. Browser Automation</div>
                      <div className="text-slate-300 font-semibold">"Open YouTube" / "Search for JEE lectures" / "Open Gmail"</div>
                      <div className="text-slate-500 text-[7px] leading-tight">Spawns Playwright automated scripts in browser viewport.</div>
                    </div>
                    <div className="p-2 bg-black/25 rounded border border-cyan-500/5 space-y-1">
                      <div className="text-cyan-400 font-bold uppercase text-[7px]">4. Development Mode</div>
                      <div className="text-slate-300 font-semibold">"Run my FastAPI server" / "Start the React project"</div>
                      <div className="text-slate-500 text-[7px] leading-tight">Initializes local dev server daemons, ports, & git pushes.</div>
                    </div>
                    <div className="p-2 bg-black/25 rounded border border-cyan-500/5 space-y-1">
                      <div className="text-cyan-400 font-bold uppercase text-[7px]">5. Knowledge Base</div>
                      <div className="text-slate-300 font-semibold">"What is Newton's law?" / "Explain recursion"</div>
                      <div className="text-slate-500 text-[7px] leading-tight">Fast analytical local explanations without searching Google.</div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* SECURITY HANDSHAKE AUTHORIZATION MODAL */}
      <AnimatePresence>
        {permissionModalOpen && permissionModalTarget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className={`w-full max-w-md p-6 rounded-2xl border font-mono select-none ${
                isLight ? "bg-white border-slate-300 text-slate-800" : "bg-zinc-950 border-cyan-500/20 text-cyan-300"
              }`}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-cyan-950/40 border border-cyan-500/30 rounded-xl">
                  <Shield className="w-6 h-6 text-cyan-400 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-sm font-bold tracking-wide uppercase">Security Handshake Request</h3>
                  <p className="text-[10px] text-slate-400 uppercase">JARVIS OMEGA // COGNITIVE AGENT GATEWAY</p>
                </div>
              </div>

              <div className="p-4 bg-black/40 rounded-xl border border-cyan-500/5 mb-5 space-y-3">
                <p className="text-[11px] leading-relaxed text-slate-300">
                  Sir, the active execution array is requesting localized system-level access. Please confirm permission authorization:
                </p>
                <div className="flex items-center justify-between p-2.5 bg-cyan-950/20 rounded-lg border border-cyan-500/10 text-[10px]">
                  <span className="font-bold text-slate-200">REQUESTED PRIVILEGE:</span>
                  <span className="text-cyan-400 font-bold uppercase">{permissionModalTarget.replace(/([A-Z])/g, "_$1")}</span>
                </div>
                <div className="text-[9px] text-slate-400 leading-normal">
                  {permissionModalTarget === "microphone" && "Allows continuous voice capture, hotword audio triggers, and local STT recognition."}
                  {permissionModalTarget === "accessibility" && "Enables system overlay elements, window event detection, and Android notification listeners."}
                  {permissionModalTarget === "fileSystem" && "Allows JARVIS to securely scan directory routes, create folder elements, and rename workspace files."}
                  {permissionModalTarget === "screen" && "Enables optical screen-capture analysis for real-time visual assistance and layout debugging."}
                  {permissionModalTarget === "appControl" && "Enables PyAutoGUI macro inputs, process control via psutil, volume adjustment, and computer lock commands."}
                  {permissionModalTarget === "browserAutomation" && "Allows headless Playwright scripts to execute searches, downloads, and web page interactions."}
                </div>
              </div>

              <div className="flex gap-3 text-xs">
                <button
                  onClick={() => {
                    const nextPerms = { ...agentPermissions, [permissionModalTarget]: "denied" as const };
                    saveAgentPermissions(nextPerms);
                    setPermissionModalOpen(false);
                    setPendingCommand(null);
                    addToast(`Security privilege for '${permissionModalTarget}' denied.`, "warning");
                  }}
                  className={`flex-1 py-2.5 rounded-xl border font-bold uppercase cursor-pointer text-center text-[10px] ${
                    isLight ? "bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-700" : "bg-red-950/20 hover:bg-red-900/30 border-red-500/30 text-red-400"
                  }`}
                >
                  Deny Access
                </button>
                <button
                  onClick={() => {
                    const nextPerms = { ...agentPermissions, [permissionModalTarget]: "granted" as const };
                    saveAgentPermissions(nextPerms);
                    setPermissionModalOpen(false);
                    addToast(`Security privilege for '${permissionModalTarget}' granted!`, "success");
                    
                    // Re-execute the pending command
                    if (pendingCommand) {
                      const cmd = pendingCommand;
                      setPendingCommand(null);
                      setTimeout(() => {
                        processVoiceCommand(cmd);
                      }, 500);
                    }
                  }}
                  className="flex-1 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl font-bold uppercase cursor-pointer text-center text-[10px]"
                >
                  Authorize Node
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
