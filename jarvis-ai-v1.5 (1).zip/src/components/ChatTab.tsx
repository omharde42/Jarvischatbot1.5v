/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { useJarvisStore } from "../stores/jarvisStore";
import { api } from "../services/api";
import { 
  Send, 
  Trash2, 
  Pin, 
  Image as ImageIcon, 
  Plus, 
  Mic, 
  VolumeX, 
  Volume2, 
  Cpu, 
  Search, 
  CornerDownLeft, 
  ClipboardCheck, 
  Clipboard, 
  Terminal,
  Maximize2,
  Minimize2,
  StopCircle,
  History,
  RotateCcw,
  ChevronRight,
  Sparkles,
  Loader2
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// Robust and highly responsive Custom Markdown & Code Highlights Parser
function RenderFormattedMessage({ text, isLight }: { text: string; isLight?: boolean }) {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleCopyCode = (code: string, index: number) => {
    navigator.clipboard.writeText(code);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  if (!text) return null;

  // Split content by code blocks ```
  const parts = text.split(/(```[\s\S]*?```)/g);

  return (
    <div className={`space-y-2 leading-relaxed text-sm ${isLight ? "text-slate-800" : "text-slate-200"}`}>
      {parts.map((part, index) => {
        if (part.startsWith("```")) {
          // Extract language and actual code content
          const match = part.match(/```(\w*)\n([\s\S]*?)```/);
          const lang = match ? match[1] : "bash";
          const code = match ? match[2] : part.slice(3, -3);

          return (
            <div key={index} className="my-3 border border-cyan-500/20 rounded-lg overflow-hidden bg-slate-950">
              <div className="flex items-center justify-between px-4 py-1.5 bg-slate-900 border-b border-cyan-500/10 font-mono text-xs text-cyan-400">
                <div className="flex items-center gap-2">
                  <Terminal className="w-3.5 h-3.5" />
                  <span>{lang || "jarvis_os"}</span>
                </div>
                <button
                  onClick={() => handleCopyCode(code, index)}
                  className="flex items-center gap-1 hover:text-cyan-200 transition-colors cursor-pointer"
                >
                  {copiedIndex === index ? (
                    <>
                      <ClipboardCheck className="w-3.5 h-3.5 text-green-400" />
                      <span className="text-green-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Clipboard className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="p-4 overflow-x-auto font-mono text-xs text-slate-300 bg-black/60 scrollbar-thin">
                <code>{code.trim()}</code>
              </pre>
            </div>
          );
        }

        // Inline formatting replacements (e.g. bold, inline code)
        // Parse bold **text**
        const lines = part.split("\n");
        return (
          <div key={index} className="space-y-1">
            {lines.map((line, lIdx) => {
              if (line.trim().startsWith("- ") || line.trim().startsWith("* ")) {
                return (
                  <ul key={lIdx} className="list-disc pl-5 my-1 space-y-0.5">
                    <li>{parseInlineFormatting(line.trim().substring(2), isLight)}</li>
                  </ul>
                );
              }
              return <p key={lIdx} className="my-1">{parseInlineFormatting(line, isLight)}</p>;
            })}
          </div>
        );
      })}
    </div>
  );
}

function parseInlineFormatting(text: string, isLight?: boolean) {
  // Regex to match inline code `code` and bold **bold**
  const tokens = text.split(/(\*\*.*?\*\*|`.*?`)/g);
  return tokens.map((token, index) => {
    if (token.startsWith("**") && token.endsWith("**")) {
      return <strong key={index} className={`${isLight ? "text-cyan-700 font-bold" : "text-cyan-400 font-semibold"}`}>{token.slice(2, -2)}</strong>;
    }
    if (token.startsWith("`") && token.endsWith("`")) {
      return <code key={index} className={`${isLight ? "bg-slate-200 border-slate-300 text-slate-800" : "bg-slate-950 border border-cyan-500/10 text-cyan-300"} font-mono text-xs px-1.5 py-0.5 rounded`}>{token.slice(1, -1)}</code>;
    }
    return token;
  });
}

const COMMANDS = [
  { keyword: "run diagnostics", display: "/diagnostics", description: "Triggers a full diagnostic sweep of mainframe services and integrity" },
  { keyword: "open task monitor", display: "/tasks", description: "Switches to the Process Telemetry and Task monitor tab" },
  { keyword: "clear memory", display: "/clear", description: "Securely purges and wipes all memories from the core database" },
  { keyword: "clear chat", display: "/new-chat", description: "Initializes a completely fresh core simulation chat" },
  { keyword: "full screen chat", display: "/maximize", description: "Maximizes chat console to occupy the full interface grid" },
  { keyword: "exit full screen", display: "/minimize", description: "Restores chat console back to default dashboard proportions" },
  { keyword: "switch to dark mode", display: "/dark-theme", description: "Switches current interface theme to stealth dark theme" },
  { keyword: "switch to light mode", display: "/light-theme", description: "Switches current interface theme to clean office light mode" },
];

const holographicContainerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const holographicSectionVariants = {
  hidden: { 
    opacity: 0, 
    y: 20,
    filter: "hue-rotate(-15deg) brightness(1.3) contrast(1.1) drop-shadow(0 0 12px rgba(6,182,212,0.4))",
  },
  visible: { 
    opacity: 1, 
    y: 0,
    filter: "hue-rotate(0deg) brightness(1) contrast(1) drop-shadow(0 0 0px rgba(0,0,0,0))",
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 15,
    },
  },
};

export default function ChatTab() {
  const {
    conversations,
    activeConversationId,
    chatLoading,
    chatError,
    sendMessage,
    startConversation,
    deleteConversation,
    selectConversation,
    togglePinConversation,
    isSpeaking,
    stopSpeaking,
    startListening,
    stopListening,
    isListening,
    settings,
    isFullScreenChat,
    setFullScreenChat,
    voiceCommandsHistory,
    clearVoiceCommandsHistory,
  } = useJarvisStore();

  const [listeningSeconds, setListeningSeconds] = useState(0);
  const [peakAmplitudes, setPeakAmplitudes] = useState<number[]>([1, 1, 1, 1, 1, 1]);

  useEffect(() => {
    if (!isSpeaking && !isListening) {
      setPeakAmplitudes([1, 1, 1, 1, 1, 1]);
      return;
    }

    const interval = setInterval(() => {
      setPeakAmplitudes(
        Array.from({ length: 6 }, () => {
          const rand = Math.random();
          const threshold = isListening ? 0.65 : 0.75;
          if (rand > threshold) {
            // Peak detected: Amplify up to 1.85x
            return 1.4 + Math.random() * 0.45;
          } else if (rand < (isListening ? 0.3 : 0.2)) {
            // Low valley
            return 0.3 + Math.random() * 0.3;
          }
          return 0.8 + Math.random() * 0.5;
        })
      );
    }, isListening ? 90 : 120);

    return () => clearInterval(interval);
  }, [isSpeaking, isListening]);

  useEffect(() => {
    if (!isListening) {
      setListeningSeconds(0);
      return;
    }

    const interval = setInterval(() => {
      setListeningSeconds((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [isListening]);

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, "0");
    const s = (secs % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  const [input, setInput] = useState(() => {
    const initialConvId = useJarvisStore.getState().activeConversationId || "general";
    return localStorage.getItem(`jarvis_chat_draft_${initialConvId}`) || "";
  });
  const [isCommandMode, setIsCommandMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [showSessionsList, setShowSessionsList] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Gemini 3.5-Flash audio transcriber integration
  const [isGeminiVoiceActive, setIsGeminiVoiceActive] = useState(true);
  const [isRecordingAudio, setIsRecordingAudio] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<any>(null);

  useEffect(() => {
    return () => {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    };
  }, []);

  const startGeminiRecording = async () => {
    try {
      chunksRef.current = [];
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const options = { mimeType: "audio/webm" };
      let recorder;
      try {
        recorder = new MediaRecorder(stream, options);
      } catch (e) {
        recorder = new MediaRecorder(stream);
      }

      recorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      recorder.onstop = async () => {
        setIsTranscribing(true);
        useJarvisStore.getState().addToast("Transcribing audio using gemini-3.5-flash...", "info");
        try {
          const audioBlob = new Blob(chunksRef.current, { type: recorder.mimeType || "audio/webm" });
          
          const reader = new FileReader();
          reader.readAsDataURL(audioBlob);
          reader.onloadend = async () => {
            const base64Audio = reader.result as string;
            try {
              const res = await api.transcribeAudio(base64Audio, recorder.mimeType || "audio/webm");
              if (res && res.text) {
                setInput((prev) => {
                  const prefix = prev.trim() ? prev.trim() + " " : "";
                  return prefix + res.text;
                });
                useJarvisStore.getState().addToast("Speech transcribed successfully.", "success");
              } else {
                useJarvisStore.getState().addToast("Transcriber did not detect any words.", "warning");
              }
            } catch (err: any) {
              console.error("Transcribe failed:", err);
              useJarvisStore.getState().addToast("Transcription failed: " + (err.message || err), "error");
            } finally {
              setIsTranscribing(false);
            }
          };
        } catch (e: any) {
          console.error("Failed to process audio chunks:", e);
          setIsTranscribing(false);
        }
      };

      recorder.start();
      setIsRecordingAudio(true);
      setRecordingTime(0);

      recordingTimerRef.current = setInterval(() => {
        setRecordingTime((prev) => {
          if (prev >= 60) {
            stopGeminiRecording();
            return prev;
          }
          return prev + 1;
        });
      }, 1000);

    } catch (err: any) {
      console.error("Microphone access blocked:", err);
      useJarvisStore.getState().addToast("Microphone access denied: " + (err.message || "Please allow access"), "error");
    }
  };

  const stopGeminiRecording = () => {
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }

    if (recorderRef.current && recorderRef.current.state !== "inactive") {
      recorderRef.current.stop();
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }

    setIsRecordingAudio(false);
  };

  const resolvedMode = settings?.appearance?.mode || "dark";
  const isLight = resolvedMode === "light";

  const activeConv = conversations.find((c) => c.id === activeConversationId);

  // Command Mode Parsing & Suggestions
  const isSlashCommand = input.startsWith("/");
  const searchText = isSlashCommand ? input.slice(1).trim().toLowerCase() : input.trim().toLowerCase();

  const matchedCommands = input.trim() === "" && isCommandMode
    ? COMMANDS
    : COMMANDS.filter(cmd => 
        cmd.keyword.toLowerCase().includes(searchText) || 
        cmd.display.toLowerCase().includes(searchText) ||
        cmd.description.toLowerCase().includes(searchText)
      );

  const showSuggestions = (isCommandMode || isSlashCommand) && matchedCommands.length > 0;

  // Restore draft when switching active simulations
  useEffect(() => {
    const savedDraft = localStorage.getItem(`jarvis_chat_draft_${activeConversationId || "general"}`);
    setInput(savedDraft || "");
  }, [activeConversationId]);

  useEffect(() => {
    // Auto-scroll to bottom of messages
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeConv?.messages?.length, chatLoading]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() === "" && !selectedImage) return;

    let text = input.trim();
    // Resolve slash commands or keyword inputs cleanly
    if (text.startsWith("/")) {
      const match = COMMANDS.find(
        (c) => c.display.toLowerCase() === text.toLowerCase() || c.keyword.toLowerCase() === text.slice(1).toLowerCase()
      );
      if (match) {
        text = match.keyword;
      } else {
        text = text.slice(1);
      }
    }

    const img = selectedImage;
    setInput("");
    setSelectedImage(null);
    setIsCommandMode(false);
    localStorage.removeItem(`jarvis_chat_draft_${activeConversationId || "general"}`);

    await sendMessage(text, img);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const filteredConversations = conversations.filter((c) =>
    c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.messages.some((m) => m.content.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <motion.div
      id="jarvis_chat_tab"
      initial="hidden"
      animate="visible"
      variants={holographicContainerVariants}
      className={`grid grid-cols-1 lg:grid-cols-4 gap-4 overflow-visible lg:overflow-hidden ${
        isFullScreenChat ? "h-[85vh] lg:h-[88vh]" : "h-auto lg:h-[550px] xl:h-full"
      }`}
    >
      {/* Session Navigation Side Rail */}
      <motion.div
        variants={holographicSectionVariants}
        className={`lg:col-span-1 ${showSessionsList ? "flex" : "hidden lg:flex"} flex-col ${
          isLight ? "bg-white/90 border-slate-300 shadow-md text-slate-800" : "glassmorphism border-cyan-500/20 text-slate-100"
        } rounded-xl p-3 h-[420px] lg:h-full overflow-hidden transition-colors duration-500`}
      >
        
        {/* Simulations Section */}
        <div className="flex-1 flex flex-col min-h-[180px] pb-3 border-b border-cyan-500/10 overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <h3 className={`font-display font-medium text-sm ${isLight ? "text-cyan-700" : "text-cyan-400"} uppercase tracking-widest`}>Simulations</h3>
            <button
              onClick={() => {
                startConversation();
                setShowSessionsList(false);
              }}
              className={`p-1.5 rounded-lg border ${
                isLight ? "border-slate-300 hover:border-slate-400 bg-slate-50 text-slate-600" : "border-cyan-500/30 hover:border-cyan-400 bg-cyan-950/20 text-cyan-400 hover:bg-cyan-900/30"
              } transition-all cursor-pointer`}
              title="Start New Core Simulation"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Search simulation records */}
          <div className="relative mb-2 flex-shrink-0">
            <Search className={`absolute left-2.5 top-2.5 w-4 h-4 ${isLight ? "text-slate-400" : "text-cyan-500/50"}`} />
            <input
              type="text"
              placeholder="Search logs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full ${
                isLight ? "bg-slate-50 border-slate-300 text-slate-800 placeholder-slate-400" : "bg-slate-950/80 border-cyan-500/20 text-slate-200 placeholder-cyan-500/40"
              } border rounded-lg pl-9 pr-3 py-1.5 font-sans text-xs focus:outline-none focus:border-cyan-400 transition-all`}
            />
          </div>

          {/* Chat Logs List */}
          <div className="flex-1 overflow-y-auto space-y-1.5 scrollbar-thin pr-1">
            {filteredConversations.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-500 font-mono">No simulation channels</div>
            ) : (
              filteredConversations.map((c) => {
                const isActive = c.id === activeConversationId;
                return (
                  <div
                    key={c.id}
                    onClick={() => {
                      selectConversation(c.id);
                      setShowSessionsList(false);
                    }}
                    className={`group relative flex items-center justify-between p-2.5 rounded-lg border cursor-pointer transition-all ${
                      isActive
                        ? isLight
                          ? "bg-cyan-50 border-cyan-300 shadow-inner"
                          : "bg-cyan-950/30 border-cyan-500/60 shadow-inner shadow-cyan-950/50"
                        : isLight
                          ? "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                          : "border-cyan-500/10 hover:border-cyan-500/30 hover:bg-slate-900/40"
                    }`}
                  >
                    <div className="flex flex-col gap-0.5 overflow-hidden w-[80%]">
                      <span className={`text-xs font-medium truncate ${isActive ? "text-cyan-400" : "text-slate-300"}`}>
                        {c.title}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {new Date(c.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>

                    {/* Actions (Pin / Trash) */}
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          togglePinConversation(c.id);
                        }}
                        className={`p-1 rounded hover:bg-slate-800 ${c.pin ? "text-cyan-400" : "text-slate-500"}`}
                        title={c.pin ? "Unpin session" : "Pin session"}
                      >
                        <Pin className="w-3.5 h-3.5 fill-current" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteConversation(c.id);
                        }}
                        className="p-1 rounded hover:bg-red-950/40 text-slate-500 hover:text-red-400"
                        title="Delete session"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Command History Section */}
        <div className="flex-1 flex flex-col pt-3 min-h-[160px] overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <History className={`w-4 h-4 ${isLight ? "text-cyan-700" : "text-cyan-400"}`} />
              <h3 className={`font-display font-medium text-xs ${isLight ? "text-cyan-700" : "text-cyan-400"} uppercase tracking-widest`}>
                Command History
              </h3>
            </div>
            {voiceCommandsHistory.length > 0 && (
              <button
                onClick={clearVoiceCommandsHistory}
                className={`p-1 rounded text-xs transition-all flex items-center gap-1 cursor-pointer ${
                  isLight
                    ? "text-slate-500 hover:text-red-600 hover:bg-slate-100"
                    : "text-slate-400 hover:text-rose-400 hover:bg-rose-950/20"
                }`}
                title="Purge command telemetry"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="text-[10px] uppercase font-mono tracking-wider">Purge</span>
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto space-y-1.5 scrollbar-thin pr-1">
            {voiceCommandsHistory.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-6 opacity-60">
                <Mic className={`w-8 h-8 ${isLight ? "text-slate-400" : "text-cyan-500/30"} mb-1.5 animate-pulse`} />
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500">No Telemetry</span>
                <span className="text-[9px] text-slate-500 mt-1 px-2 leading-tight">
                  Awaiting vocal command transmissions or system overrides
                </span>
              </div>
            ) : (
              voiceCommandsHistory.map((cmd, idx) => (
                <button
                  key={`${cmd}-${idx}`}
                  type="button"
                  onClick={() => sendMessage(cmd)}
                  className={`w-full text-left p-2 rounded-lg border flex items-center justify-between transition-all group/cmd cursor-pointer ${
                    isLight
                      ? "border-slate-200 hover:border-cyan-300 hover:bg-cyan-50/50 text-slate-700"
                      : "border-cyan-500/5 hover:border-cyan-500/30 bg-cyan-950/5 hover:bg-cyan-950/20 text-slate-300 hover:text-cyan-400"
                  }`}
                  title={`Execute: "${cmd}"`}
                >
                  <div className="flex items-center gap-2 overflow-hidden pr-2">
                    <RotateCcw className={`w-3 h-3 flex-shrink-0 transition-transform group-hover/cmd:rotate-45 ${
                      isLight ? "text-slate-400" : "text-cyan-500/50"
                    }`} />
                    <span className="text-xs truncate font-mono">{cmd}</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 flex-shrink-0 opacity-0 group-hover/cmd:opacity-100 transition-all text-cyan-400 translate-x-[-4px] group-hover/cmd:translate-x-0" />
                </button>
              ))
            )}
          </div>
        </div>
      </motion.div>

      {/* Main Active Dialog Panel */}
      <motion.div
        variants={holographicSectionVariants}
        className={`lg:col-span-3 ${showSessionsList ? "hidden lg:flex" : "flex"} flex-col ${
          isLight ? "bg-white/90 border-slate-300 shadow-md text-slate-800" : "glassmorphism border-cyan-500/20 text-slate-100"
        } rounded-xl h-[480px] lg:h-full overflow-hidden relative transition-colors duration-500`}
      >
        {/* Chat Tab Header */}
        <div className={`flex items-center justify-between px-3 sm:px-4 py-2.5 sm:py-3 border-b ${
          isLight ? "border-slate-200 bg-slate-100/60" : "border-cyan-500/15 bg-cyan-950/10"
        }`}>
          <div className="flex items-center gap-2 overflow-hidden mr-1">
            <div className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse flex-shrink-0"></div>
            <div className="overflow-hidden">
              <h2 className={`font-display text-xs sm:text-sm font-semibold ${isLight ? "text-slate-800" : "text-slate-100"} tracking-wider uppercase truncate`}>
                {activeConv ? activeConv.title : "JARVIS MAIN CONSOLE"}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
            {/* Mobile Sessions Toggle */}
            <button
              onClick={() => setShowSessionsList(!showSessionsList)}
              className={`lg:hidden flex items-center gap-1 px-2 py-1 rounded-lg border text-[10px] font-mono transition-all cursor-pointer ${
                showSessionsList
                  ? isLight
                    ? "border-amber-400 bg-amber-50 text-amber-700 hover:bg-amber-100"
                    : "border-amber-500/40 bg-amber-950/20 text-amber-400 hover:bg-amber-900/30"
                  : isLight
                    ? "border-cyan-400 bg-cyan-50 text-cyan-700 hover:bg-cyan-100"
                    : "border-cyan-500/30 bg-cyan-500/10 text-cyan-400 hover:bg-cyan-950/40"
              }`}
              title={showSessionsList ? "Show Active Console Dialog" : "View Previous Sessions"}
            >
              <History className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{showSessionsList ? "SHOW CHAT" : "SESSIONS"}</span>
              <span className="sm:hidden">{showSessionsList ? "CHAT" : "LIST"}</span>
            </button>

            {/* Full-Screen Toggle Button */}
            <button
              onClick={() => setFullScreenChat(!isFullScreenChat)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[10px] font-mono transition-all cursor-pointer ${
                isFullScreenChat
                  ? isLight
                    ? "border-amber-400 bg-amber-50 text-amber-700 hover:bg-amber-100"
                    : "border-amber-500/40 bg-amber-950/20 text-amber-400 hover:bg-amber-900/30"
                  : isLight
                    ? "border-cyan-400 bg-cyan-50 text-cyan-700 hover:bg-cyan-100"
                    : "border-cyan-500/30 bg-cyan-500/10 text-cyan-400 hover:bg-cyan-950/40"
              }`}
              title={isFullScreenChat ? "Exit Full-Screen Mode" : "Enter Full-Screen Mode"}
            >
              {isFullScreenChat ? (
                <>
                  <Minimize2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">EXIT FULL-SCREEN</span>
                </>
              ) : (
                <>
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">FULL SCREEN</span>
                </>
              )}
            </button>

            {/* Audio Speech controls */}
            {isSpeaking ? (
              <button
                onClick={stopSpeaking}
                className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border font-mono text-[10px] transition-colors cursor-pointer ${
                  isLight
                    ? "border-cyan-400 bg-cyan-100 text-cyan-700 hover:bg-cyan-200"
                    : "border-cyan-500/30 bg-cyan-500/10 text-cyan-400 hover:bg-cyan-950/40"
                }`}
              >
                <Volume2 className="w-3.5 h-3.5 animate-bounce" />
                <span>MUTE JARVIS</span>
              </button>
            ) : (
              <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border font-mono text-[10px] ${
                isLight ? "border-slate-200 bg-slate-50 text-slate-400" : "border-cyan-500/5 bg-slate-950/50 text-slate-500"
              }`}>
                <VolumeX className="w-3.5 h-3.5" />
                <span>AUDIO IDLE</span>
              </div>
            )}
          </div>
        </div>

        {/* Message Logs */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
          {activeConv && activeConv.messages.length > 0 ? (
            activeConv.messages.map((msg, idx) => {
              const isUser = msg.role === "user";
              return (
                <div
                  key={msg.id}
                  className={`flex ${isUser ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-xl p-3.5 border shadow-lg ${
                      isUser
                        ? isLight
                          ? "bg-cyan-50 border-cyan-300 text-slate-800 rounded-tr-none shadow-cyan-100/30"
                          : "bg-cyan-950/20 border-cyan-500/30 text-slate-100 rounded-tr-none"
                        : isLight
                          ? "bg-slate-50 border-slate-200 text-slate-800 rounded-tl-none"
                          : "bg-slate-950/80 border-cyan-500/10 text-slate-200 rounded-tl-none"
                    }`}
                  >
                    {/* Header bar within bubble */}
                    <div className="flex items-center justify-between mb-1 text-[9px] font-mono tracking-wider opacity-60">
                      <span className={isUser ? "text-cyan-600 font-bold" : "text-purple-600 font-bold"}>
                        {isUser ? "USER" : "JARVIS AI"}
                      </span>
                      <span className={isLight ? "text-slate-500" : "text-slate-400"}>
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>

                    {/* Optional Inline Image */}
                    {msg.image && (
                      <div className={`mb-2 max-w-[200px] border ${isLight ? "border-slate-300" : "border-cyan-500/30"} rounded overflow-hidden`}>
                        <img src={msg.image} alt="uploaded feed" className="w-full object-cover max-h-40" />
                      </div>
                    )}

                    <RenderFormattedMessage text={msg.content} isLight={isLight} />
                  </div>
                </div>
              );
            })
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 select-none opacity-80">
              <div className="w-16 h-16 rounded-full border border-cyan-500/25 bg-cyan-950/20 flex items-center justify-center mb-4 shadow-lg shadow-cyan-950/20">
                <Cpu className="w-8 h-8 text-cyan-400 animate-pulse" />
              </div>
              <h3 className="font-display text-lg text-slate-200 font-medium tracking-wide">JARVIS SECURE FEED</h3>
              <p className="max-w-sm text-xs text-slate-500 mt-2 font-mono leading-relaxed">
                "Welcome back, Sir. Secure neural networks are online and listening. How may I assist your engineering diagnostics today?"
              </p>
            </div>
          )}

          {/* Core is thinking / typing indicator */}
          {chatLoading && (
            <div className="flex justify-start">
              <div className="bg-slate-950/80 border border-pink-500/20 rounded-xl p-3.5 rounded-tl-none flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 bg-pink-500 rounded-full animate-bounce"></span>
                  <span className="w-2 h-2 bg-pink-500 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-2 h-2 bg-pink-500 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                </div>
                <span className="text-[10px] font-mono text-pink-400 tracking-widest uppercase">JARVIS ANALYZING...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Autocomplete / Command Suggestions Overlay */}
        {showSuggestions && (
          <div className={`p-2 border-t border-b mx-3 my-2 rounded-xl backdrop-blur-md shadow-2xl transition-all ${
            isLight 
              ? "bg-slate-100/95 border-slate-300 text-slate-800" 
              : "bg-slate-950/95 border-pink-500/30 text-slate-100 shadow-pink-950/20"
          }`}>
            <div className="px-2 py-1 flex items-center justify-between text-[9px] font-mono tracking-wider text-pink-400 font-bold uppercase border-b border-pink-500/10 mb-1">
              <span>Mainframe Terminology [Command Suggestions]</span>
              <span>{matchedCommands.length} match(es)</span>
            </div>
            <div className="max-h-40 overflow-y-auto space-y-1 scrollbar-thin">
              {matchedCommands.map((cmd) => (
                <button
                  key={cmd.keyword}
                  type="button"
                  onClick={async () => {
                    setInput("");
                    setIsCommandMode(false);
                    await sendMessage(cmd.keyword);
                  }}
                  className={`w-full text-left px-2.5 py-2 rounded-lg font-mono text-xs flex items-center justify-between transition-all cursor-pointer ${
                    isLight
                      ? "hover:bg-slate-200 text-slate-700 hover:text-slate-900"
                      : "hover:bg-pink-500/10 text-slate-300 hover:text-pink-400 hover:border-pink-500/20 border border-transparent"
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <span className="text-pink-400 font-black">{cmd.display}</span>
                    <span className="text-slate-400 font-medium">{cmd.keyword}</span>
                  </span>
                  <span className="text-[10px] text-slate-500 truncate max-w-[200px] sm:max-w-xs">{cmd.description}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input prompt tray */}
        <form onSubmit={handleSend} className={`p-3 border-t relative ${
          isLight ? "border-slate-200 bg-slate-50" : "border-cyan-500/15 bg-black/40"
        }`}>
          {/* Preview selected image */}
          {selectedImage && (
            <div className={`mb-2 relative inline-block p-1 border ${isLight ? "border-slate-300 bg-white" : "border-cyan-500/40 bg-slate-950"} rounded`}>
              <img src={selectedImage} alt="feed preview" className="w-16 h-16 object-cover rounded" />
              <button
                type="button"
                onClick={() => setSelectedImage(null)}
                className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-600 hover:bg-red-500 text-white font-bold rounded-full text-[10px] flex items-center justify-center cursor-pointer"
              >
                ×
              </button>
            </div>
          )}

          <div className="flex items-center gap-2">
            {/* Command Mode Toggle Button */}
            <button
              type="button"
              onClick={() => setIsCommandMode(!isCommandMode)}
              className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                isCommandMode
                  ? isLight
                    ? "border-pink-400 bg-pink-50 text-pink-700 font-bold shadow-[0_0_10px_rgba(244,63,94,0.15)]"
                    : "border-pink-500/40 bg-pink-950/25 text-pink-400 font-bold shadow-[0_0_15px_rgba(244,63,94,0.25)]"
                  : isLight
                    ? "border-slate-300 bg-white hover:bg-slate-50 text-slate-500 hover:text-slate-700"
                    : "border-cyan-500/10 bg-cyan-950/5 hover:bg-cyan-950/15 hover:border-cyan-500/30 text-cyan-500/60 hover:text-cyan-400"
              }`}
              title="Toggle Command Console Mode (or type /)"
            >
              <Terminal className="w-4.5 h-4.5" />
              <span className="hidden md:inline text-[9px] uppercase tracking-wider">Cmd Mode</span>
            </button>

            <div className="flex-1 relative flex items-center">
              {isCommandMode && (
                <span className="absolute left-3.5 top-3 text-xs font-mono text-pink-400 animate-pulse pointer-events-none select-none">
                  $
                </span>
              )}
              <input
                type="text"
                placeholder={isCommandMode ? "Enter terminal command (e.g. '/diagnostics', '/tasks', '/clear')..." : "Transmit prompt or system commands (e.g., 'remember that...', 'schedule task...')"}
                value={input}
                onChange={(e) => {
                  const val = e.target.value;
                  setInput(val);
                  localStorage.setItem(`jarvis_chat_draft_${activeConversationId || "general"}`, val);
                }}
                disabled={chatLoading}
                className={`w-full ${
                  isLight
                    ? isCommandMode
                      ? "bg-pink-50/10 border-pink-300 text-slate-800 placeholder-pink-400/60 focus:border-pink-500"
                      : "bg-white border-slate-300 text-slate-800 placeholder-slate-400 focus:border-cyan-500"
                    : isCommandMode
                      ? "bg-slate-950/85 border-pink-500/40 text-pink-300 placeholder-pink-500/30 focus:border-pink-400 shadow-[0_0_15px_rgba(244,63,94,0.1)]"
                      : "bg-slate-950/85 border-cyan-500/35 text-slate-200 placeholder-cyan-500/40 focus:border-cyan-400"
                } border rounded-xl ${isCommandMode ? "pl-7" : "pl-3"} pr-10 py-3 font-sans text-xs focus:outline-none focus:ring-1 focus:ring-cyan-400/20 focus:shadow-inner transition-all disabled:opacity-50`}
              />

              {/* Upload image overlay icon */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={chatLoading}
                className={`absolute right-3 top-3 ${isLight ? "text-slate-400 hover:text-slate-600" : "text-cyan-500 hover:text-cyan-300"} transition-colors cursor-pointer`}
                title="Input Visual Image Overlay"
              >
                <ImageIcon className="w-4.5 h-4.5" />
              </button>
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </div>
            {/* Quick Voice mic button area with reactive voice wave frequency animation */}
            <div className="relative flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  if (isGeminiVoiceActive) {
                    if (isRecordingAudio) {
                      stopGeminiRecording();
                    } else {
                      startGeminiRecording();
                    }
                  } else {
                    if (isListening) {
                      stopListening();
                    } else {
                      startListening();
                    }
                  }
                }}
                disabled={chatLoading || isTranscribing}
                className={`p-3 rounded-xl border transition-all cursor-pointer disabled:opacity-40 relative group ${
                  (isListening || isRecordingAudio)
                    ? "border-red-500 bg-red-950/20 text-red-400 animate-pulse shadow-[0_0_12px_rgba(239,68,68,0.3)]"
                    : isSpeaking
                      ? isLight
                        ? "border-cyan-500 bg-cyan-50 text-cyan-600 shadow-[0_0_12px_rgba(6,182,212,0.3)] animate-pulse"
                        : "border-cyan-400 bg-cyan-950/40 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.4)] animate-pulse"
                      : isLight
                        ? "border-slate-300 bg-white hover:bg-slate-50 text-slate-600 animate-none"
                        : "border-cyan-500/30 bg-cyan-950/15 hover:bg-cyan-900/35 hover:border-cyan-400 text-cyan-400 animate-none"
                }`}
                title={
                  isRecordingAudio
                    ? "Stop Gemini Recording (Transcribe Audio)"
                    : isListening 
                      ? "Stop Web Speech Recording" 
                      : isSpeaking 
                        ? "JARVIS Vocalizing" 
                        : isGeminiVoiceActive
                          ? "Record Audio & Transcribe with Gemini 3.5-Flash"
                          : "Vocalize Input (Web Speech)"
                }
              >
                {isTranscribing ? (
                  <Loader2 className="w-4.5 h-4.5 text-cyan-400 animate-spin" />
                ) : (isListening || isRecordingAudio) ? (
                  <StopCircle className="w-4.5 h-4.5 text-red-400" />
                ) : isSpeaking ? (
                  <Volume2 className="w-4.5 h-4.5 text-cyan-400 animate-bounce" />
                ) : (
                  <Mic className="w-4.5 h-4.5" />
                )}
                
                {/* Glowing ripple background behind mic button during voice output */}
                {isSpeaking && !(isListening || isRecordingAudio) && (
                  <>
                    <div className="absolute inset-0 rounded-xl border border-cyan-500/50 animate-ping opacity-40 pointer-events-none" />
                    <div className="absolute inset-0 rounded-xl bg-cyan-500/10 animate-pulse pointer-events-none" />
                  </>
                )}
                {(isListening || isRecordingAudio) && (
                  <>
                    <div className="absolute inset-0 rounded-xl border border-red-500/50 animate-ping opacity-40 pointer-events-none" />
                  </>
                )}
              </button>

              {/* Reactive Visual duration timer next to the microphone icon when active */}
              {(isListening || isRecordingAudio) && (
                <div 
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 h-10 rounded-xl border transition-all duration-300 ${
                    isLight
                      ? "border-red-300 bg-red-50 text-red-600 shadow-sm"
                      : "border-red-500/30 bg-red-950/40 text-red-400 shadow-[0_0_10px_rgba(239,68,68,0.2)] animate-pulse"
                  }`}
                  title="Acoustic Session Active Listening Timer"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                  <span className="font-mono text-xs font-bold tracking-wider">
                    {isRecordingAudio ? formatDuration(recordingTime) : formatDuration(listeningSeconds)}
                  </span>
                </div>
              )}

              {/* Toggle speech processor */}
              <button
                type="button"
                onClick={() => {
                  if (isListening || isRecordingAudio) {
                    stopListening();
                    stopGeminiRecording();
                  }
                  setIsGeminiVoiceActive(!isGeminiVoiceActive);
                }}
                className={`flex items-center gap-1 px-2.5 py-1.5 h-10 rounded-xl border text-[10px] font-mono tracking-wider transition-all cursor-pointer ${
                  isGeminiVoiceActive
                    ? isLight
                      ? "border-pink-300 bg-pink-50 text-pink-700 font-bold"
                      : "border-pink-500/30 bg-pink-950/20 text-pink-400 font-bold"
                    : isLight
                      ? "border-slate-300 bg-white text-slate-500"
                      : "border-slate-800 bg-slate-950/50 text-slate-500"
                }`}
                title="Toggle Gemini 3.5-Flash High-Precision Audio Transcriber"
              >
                <Sparkles className={`w-3.5 h-3.5 ${isGeminiVoiceActive ? "text-pink-400 animate-spin" : "text-slate-500"}`} style={{ animationDuration: '3s' }} />
                <span className="hidden sm:inline">
                  {isGeminiVoiceActive ? "GEMINI VOICE" : "WEB SPEECH"}
                </span>
              </button>

              {/* Reactive Visual Wave representing voice output and microphone input frequency */}
              <div 
                className={`flex items-end gap-1 px-2.5 py-1.5 rounded-xl border h-10 transition-all duration-500 overflow-hidden ${
                  isSpeaking || isListening || isRecordingAudio
                    ? (isListening || isRecordingAudio)
                      ? isLight
                        ? "w-[84px] opacity-100 border-red-300 bg-red-50/90 shadow-[0_0_10px_rgba(239,68,68,0.1)]"
                        : "w-[84px] opacity-100 border-red-500/40 bg-slate-950/80 shadow-[0_0_15px_rgba(239,68,68,0.2)]"
                      : isLight
                        ? "w-[84px] opacity-100 border-cyan-300 bg-cyan-50/60 shadow-[0_0_10px_rgba(6,182,212,0.1)]"
                        : "w-[84px] opacity-100 border-cyan-500/40 bg-slate-950/80 shadow-[0_0_15px_rgba(6,182,212,0.2)]"
                    : "w-0 px-0 border-transparent bg-transparent opacity-0 pointer-events-none"
                }`}
                title={isListening || isRecordingAudio ? "Microphone Input Sound Wave" : "Active Voice Output Frequency"}
              >
                <div className="flex items-end gap-1 h-6 w-full justify-center">
                  {[14, 24, 16, 28, 10, 20].map((h, i) => {
                    const delay = `${i * 0.12}s`;
                    const duration = `${0.5 + (i % 3) * 0.15}s`;
                    const amp = peakAmplitudes[i] ?? 1;
                    const finalHeight = Math.min(28, Math.max(3, Math.round(h * amp)));
                    return (
                      <span
                        key={i}
                        className={`w-1 rounded-full origin-bottom transition-all duration-150 ${
                          (isListening || isRecordingAudio)
                            ? isLight
                              ? "bg-red-500"
                              : "bg-red-400 shadow-[0_0_6px_rgba(239,68,68,0.5)]"
                            : isLight
                              ? "bg-cyan-500"
                              : "bg-cyan-400 shadow-[0_0_6px_rgba(34,211,238,0.5)]"
                        }`}
                        style={{
                          height: `${finalHeight}px`,
                          animation: `voiceWave ${duration} ease-in-out infinite alternate`,
                          animationDelay: delay,
                        }}
                      />
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Send button */}
            <button
              type="submit"
              disabled={chatLoading || (input.trim() === "" && !selectedImage)}
              className={`p-3 rounded-xl border font-bold transition-all disabled:opacity-45 hover:scale-105 active:scale-95 disabled:hover:scale-100 disabled:cursor-not-allowed cursor-pointer ${
                isLight
                  ? "border-cyan-600 bg-cyan-500 hover:bg-cyan-600 text-white"
                  : "border-cyan-400 bg-cyan-500 hover:bg-cyan-400 text-slate-950"
              }`}
              title="Execute Transmission"
            >
              <Send className="w-4.5 h-4.5" />
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
