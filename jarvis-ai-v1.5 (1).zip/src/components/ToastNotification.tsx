/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { useJarvisStore } from "../stores/jarvisStore";
import { motion, AnimatePresence } from "motion/react";
import { 
  CheckCircle, 
  AlertTriangle, 
  Info, 
  X,
  Sparkles,
  Terminal
} from "lucide-react";

export default function ToastNotification() {
  const { toasts, removeToast } = useJarvisStore();

  const getToastStyles = (type: "success" | "error" | "info" | "warning") => {
    switch (type) {
      case "success":
        return {
          bg: "bg-green-950/80 border-green-500/50 text-green-400",
          accent: "bg-green-500",
          icon: <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />,
          label: "SUCCESS"
        };
      case "error":
        return {
          bg: "bg-red-950/80 border-red-500/50 text-red-400",
          accent: "bg-red-500",
          icon: <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />,
          label: "CRITICAL FAIL"
        };
      case "warning":
        return {
          bg: "bg-amber-950/80 border-amber-500/50 text-amber-400",
          accent: "bg-amber-500",
          icon: <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />,
          label: "CORE WARNING"
        };
      case "info":
      default:
        return {
          bg: "bg-cyan-950/80 border-cyan-500/50 text-cyan-400",
          accent: "bg-cyan-500",
          icon: <Info className="w-4 h-4 text-cyan-400 flex-shrink-0" />,
          label: "SYSTEM UPDATE"
        };
    }
  };

  return (
    <div 
      id="jarvis_toast_container" 
      className="fixed bottom-4 left-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none"
    >
      <AnimatePresence>
        {toasts.map((toast) => {
          const { bg, accent, icon, label } = getToastStyles(toast.type);
          return (
            <motion.div
              key={toast.id}
              layout
              initial={{ opacity: 0, x: -100, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: -50, scale: 0.85, transition: { duration: 0.15 } }}
              transition={{ type: "spring", stiffness: 350, damping: 25 }}
              className={`pointer-events-auto p-3 rounded-lg border backdrop-blur-md shadow-lg ${bg} flex gap-3 relative overflow-hidden`}
            >
              {/* Vertical neon accent indicator line */}
              <div className={`absolute left-0 top-0 bottom-0 w-1 ${accent} shadow-[0_0_8px_currentColor]`} />

              {/* Toast Icon */}
              <div className="flex-shrink-0 mt-0.5">
                {icon}
              </div>

              {/* Text content */}
              <div className="flex-1 min-w-0 pr-4">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <Terminal className="w-3 h-3 opacity-60" />
                  <span className="text-[9px] font-mono tracking-wider font-extrabold opacity-70 uppercase">
                    {label}
                  </span>
                </div>
                <p className="font-sans text-xs font-medium leading-relaxed">
                  {toast.message}
                </p>
              </div>

              {/* Close Button */}
              <button
                onClick={() => removeToast(toast.id)}
                className="absolute right-2 top-2 p-1 rounded-full hover:bg-slate-900/40 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-3 h-3" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
