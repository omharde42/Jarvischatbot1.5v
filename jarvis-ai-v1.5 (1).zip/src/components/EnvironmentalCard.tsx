import React, { useState, useEffect } from "react";
import { 
  Sun, 
  Cloud, 
  CloudRain, 
  Snowflake, 
  CloudLightning, 
  Wind, 
  Thermometer, 
  Droplets, 
  Compass, 
  Search, 
  RefreshCw, 
  MapPin, 
  AlertCircle
} from "lucide-react";
import { useJarvisStore } from "../stores/jarvisStore";
import { api } from "../services/api";
import { WeatherData } from "../types";

export const EnvironmentalCard: React.FC = () => {
  const { addToast, addRecentActivity } = useJarvisStore();
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isSearching, setIsSearching] = useState<boolean>(false);

  const fetchWeather = async (lat?: number, lng?: number, query?: string) => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.getWeather(lat, lng, query);
      setWeather(data);
      
      // Post activity logs to the Live Telemetry board
      const locName = data.location || query || "Detected Area";
      addRecentActivity(
        `Weather Synced`,
        "system_event",
        `Atmosphere at ${locName}: ${data.temperature}, ${data.conditions}`
      );
    } catch (err: any) {
      console.error("Failed to compile weather telemetry:", err);
      setError("Atmospheric Link Terminated");
      addToast("Failed to retrieve micro-climate telemetry.", "error");
    } finally {
      setLoading(false);
    }
  };

  const detectLocationAndFetch = () => {
    setLoading(true);
    setError(null);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          fetchWeather(latitude, longitude);
        },
        (err) => {
          console.warn("Geolocation access failed:", err);
          // Default to Malibu, CA
          fetchWeather(undefined, undefined, "Malibu, CA");
          addToast("Local coordinates unresolved. Standardizing to Malibu, CA.", "warning");
        },
        { timeout: 8000 }
      );
    } else {
      fetchWeather(undefined, undefined, "Malibu, CA");
    }
  };

  // Run automatically on mount
  useEffect(() => {
    detectLocationAndFetch();
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    fetchWeather(undefined, undefined, searchQuery.trim());
    setIsSearching(false);
  };

  const getWeatherIcon = (iconType: string, customSize?: string) => {
    const sizeClass = customSize || "w-5 h-5";
    switch (iconType) {
      case "sunny":
        return <Sun className={`${sizeClass} text-amber-400 animate-[spin_20s_linear_infinite]`} />;
      case "cloudy":
        return <Cloud className={`${sizeClass} text-slate-400`} />;
      case "rainy":
        return <CloudRain className={`${sizeClass} text-cyan-400`} />;
      case "snowy":
        return <Snowflake className={`${sizeClass} text-blue-300`} />;
      case "stormy":
        return <CloudLightning className={`${sizeClass} text-purple-400 animate-pulse`} />;
      case "windy":
        return <Wind className={`${sizeClass} text-teal-400`} />;
      default:
        return <Sun className={`${sizeClass} text-amber-400`} />;
    }
  };

  return (
    <div id="environmental-data-card" className="p-3 border border-cyan-500/5 bg-slate-950/50 rounded-xl space-y-2.5">
      {/* Header section with live indicator */}
      <div className="flex items-center justify-between border-b border-cyan-500/10 pb-1.5">
        <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">Atmospherics</span>
        <div className="flex items-center gap-1.5">
          {weather?.simulated && (
            <span className="text-[7px] font-mono text-amber-500 bg-amber-950/20 px-1 border border-amber-500/20 rounded">
              SIMULATED
            </span>
          )}
          <span className="text-[8px] font-mono text-cyan-400 bg-cyan-950/30 px-1.5 py-0.5 border border-cyan-500/20 rounded flex items-center gap-1">
            <span className="w-1 h-1 bg-cyan-400 rounded-full animate-ping" />
            WEATHER CORE
          </span>
        </div>
      </div>

      {/* Dynamic Main Section */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-6 space-y-2">
          <RefreshCw className="w-5 h-5 text-cyan-400 animate-spin" />
          <span className="text-[8px] font-mono text-cyan-500/80 uppercase tracking-widest animate-pulse">
            Syncing Satellite Feeds...
          </span>
        </div>
      ) : error ? (
        <div className="p-2 bg-red-950/20 border border-red-500/20 rounded flex flex-col items-center justify-center space-y-1.5">
          <AlertCircle className="w-5 h-5 text-red-400" />
          <span className="text-[9px] font-mono text-red-400">{error}</span>
          <button 
            onClick={detectLocationAndFetch}
            className="text-[8px] font-mono px-2 py-0.5 bg-red-900/30 border border-red-500/30 rounded hover:bg-red-900/50 text-red-300 flex items-center gap-1 transition-all"
          >
            <RefreshCw className="w-2.5 h-2.5" /> Reconnect
          </button>
        </div>
      ) : weather ? (
        <div className="space-y-2.5">
          {/* Location and Main Weather Condition Row */}
          <div className="flex items-start justify-between gap-1.5">
            <div className="min-w-0">
              <div className="flex items-center gap-1 text-slate-300 font-mono text-[10px] font-semibold">
                <MapPin className="w-3 h-3 text-cyan-400 flex-shrink-0" />
                <span className="truncate">{weather.location}</span>
              </div>
              <p className="text-[8px] font-mono text-slate-500 mt-0.5 uppercase tracking-wider">
                {weather.conditions}
              </p>
            </div>
            
            <div className="flex items-center gap-1.5 bg-slate-950/40 px-2 py-1 rounded border border-cyan-500/5">
              {getWeatherIcon(weather.iconType)}
              <span className="font-mono text-cyan-400 font-bold text-xs">
                {weather.temperature}
              </span>
            </div>
          </div>

          {/* Grid Stats */}
          <div className="grid grid-cols-3 gap-1.5 font-mono text-[8px] text-slate-400">
            <div className="p-1.5 bg-slate-950/60 rounded border border-cyan-500/5 flex flex-col items-center justify-center space-y-0.5">
              <div className="flex items-center gap-0.5 text-slate-500">
                <Thermometer className="w-2.5 h-2.5 text-cyan-400/80" />
                <span>UV INDEX</span>
              </div>
              <span className="text-slate-200 font-bold">{weather.uvIndex || "Low"}</span>
            </div>

            <div className="p-1.5 bg-slate-950/60 rounded border border-cyan-500/5 flex flex-col items-center justify-center space-y-0.5">
              <div className="flex items-center gap-0.5 text-slate-500">
                <Droplets className="w-2.5 h-2.5 text-cyan-400/80" />
                <span>HUMIDITY</span>
              </div>
              <span className="text-slate-200 font-bold">{weather.humidity}</span>
            </div>

            <div className="p-1.5 bg-slate-950/60 rounded border border-cyan-500/5 flex flex-col items-center justify-center space-y-0.5">
              <div className="flex items-center gap-0.5 text-slate-500">
                <Compass className="w-2.5 h-2.5 text-cyan-400/80" />
                <span>WIND SPEED</span>
              </div>
              <span className="text-slate-200 font-bold truncate max-w-full">{weather.wind}</span>
            </div>
          </div>

          {/* 24-Hour Forecast Timeline */}
          {weather.forecast && weather.forecast.length > 0 && (
            <div className="space-y-1.5 pt-1.5 border-t border-cyan-500/10">
              <div className="flex items-center justify-between">
                <span className="text-[7.5px] font-mono text-cyan-400/70 uppercase tracking-widest">24-Hour Satellite Forecast</span>
                <span className="text-[6px] font-mono text-slate-600">HOURLY DEEP SWEEP</span>
              </div>
              <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none snap-x">
                {weather.forecast.map((item, idx) => (
                  <div 
                    key={idx} 
                    className="flex-1 min-w-[58px] snap-start p-1.5 bg-slate-950/70 border border-cyan-500/5 hover:border-cyan-500/20 rounded flex flex-col items-center justify-center space-y-1 text-center transition-all shrink-0"
                  >
                    <span className="text-[7px] font-mono text-slate-400 font-semibold">{item.time}</span>
                    <div className="my-0.5">
                      {getWeatherIcon(item.iconType, "w-4 h-4")}
                    </div>
                    <span className="text-[8px] font-mono text-cyan-400 font-bold">{item.temperature}</span>
                    <span className="text-[6.5px] font-mono text-slate-500 truncate max-w-[52px] uppercase leading-none block" title={item.conditions}>
                      {item.conditions}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* JARVIS Audio-tactile description box */}
          {weather.details && (
            <div className="p-2 bg-slate-950/80 border border-cyan-500/10 rounded-lg text-slate-400 font-mono text-[8px] leading-relaxed relative overflow-hidden group">
              <div className="absolute inset-y-0 left-0 w-0.5 bg-cyan-400" />
              <p className="pl-1 italic">
                "{weather.details}"
              </p>
            </div>
          )}
        </div>
      ) : null}

      {/* Search Bar Panel / Controls */}
      <div className="pt-1.5 border-t border-cyan-500/10 flex items-center justify-between gap-1.5">
        {isSearching ? (
          <form onSubmit={handleSearchSubmit} className="flex-1 flex gap-1">
            <input 
              type="text"
              placeholder="Query atmospheric coordinates (e.g., Tokyo)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 px-2 py-0.5 font-mono text-[8px] bg-slate-950 border border-cyan-500/30 rounded focus:border-cyan-400 focus:outline-none text-cyan-300 placeholder-slate-600"
              disabled={loading}
              autoFocus
            />
            <button 
              type="submit"
              disabled={loading}
              className="px-1.5 py-0.5 bg-cyan-950/50 border border-cyan-500/30 rounded text-cyan-400 hover:bg-cyan-900/50 hover:text-cyan-300 font-mono text-[8px] flex items-center"
            >
              <Search className="w-2.5 h-2.5" />
            </button>
            <button 
              type="button"
              onClick={() => setIsSearching(false)}
              className="px-1 py-0.5 border border-slate-700 rounded text-slate-500 hover:text-slate-400 font-mono text-[8px]"
            >
              X
            </button>
          </form>
        ) : (
          <>
            <button 
              onClick={() => setIsSearching(true)}
              className="text-[8px] font-mono text-slate-500 hover:text-cyan-400 flex items-center gap-1 transition-all"
            >
              <Search className="w-2.5 h-2.5" /> SEARCH COORDINATES
            </button>
            <button 
              onClick={detectLocationAndFetch}
              disabled={loading}
              title="Detect my location"
              className="text-[8px] font-mono text-slate-500 hover:text-cyan-400 flex items-center gap-1 transition-all disabled:opacity-50"
            >
              <RefreshCw className={`w-2.5 h-2.5 ${loading ? "animate-spin" : ""}`} /> AUTO DETECT
            </button>
          </>
        )}
      </div>
    </div>
  );
};
