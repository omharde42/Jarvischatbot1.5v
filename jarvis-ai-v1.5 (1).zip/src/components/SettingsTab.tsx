/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { useJarvisStore } from "../stores/jarvisStore";
import { motion } from "motion/react";
import { 
  Settings, 
  Eye, 
  Volume2, 
  Cpu, 
  ShieldAlert, 
  Sliders, 
  Save, 
  RotateCcw,
  Sparkles,
  Info,
  Zap,
  Smartphone,
  Monitor,
  Mic,
  Activity,
  Search,
  Play
} from "lucide-react";
import { AppSettings } from "../types";

export default function SettingsTab() {
  const { settings, fetchSettings, saveSettings, sendMessage } = useJarvisStore();
  const [localSettings, setLocalSettings] = useState<AppSettings | null>(null);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [vocalSearch, setVocalSearch] = useState("");
  const [showApiKey, setShowApiKey] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  useEffect(() => {
    if (settings) {
      const parsed = JSON.parse(JSON.stringify(settings));
      if (!parsed.systemControl) {
        parsed.systemControl = {
          enabled: false,
          osType: "both",
          openAppAction: true,
          readNotifications: true,
          autoTypeWhatsapp: true,
          clapSensitivity: 50,
          wakeTriggers: {
            oral: true,
            write: true,
            clap: false,
            nameWake: true
          }
        };
      }
      setLocalSettings(parsed);
    }
  }, [settings]);

  const resolvedMode = settings?.appearance?.mode || "dark";
  const isLight = resolvedMode === "light";

  const holographicContainerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const holographicSectionVariants = {
    hidden: { 
      opacity: 0, 
      y: 20,
      filter: "hue-rotate(-15deg) brightness(1.3) contrast(1.1) drop-shadow(0 0 12px rgba(6,182,212,0.4))",
    },
    visible: { 
      opacity: 1, 
      y: 0,
      filter: "hue-rotate(0deg) brightness(1) contrast(1) drop-shadow(0 0 0px rgba(0,0,0,0))",
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15,
      },
    },
  };

  const handleSave = async () => {
    if (!localSettings) return;
    setSaveStatus("SAVING PROTOCOLS...");
    try {
      await saveSettings(localSettings);
      setSaveStatus("OMEGA CORES SYNCHRONIZED!");
      setTimeout(() => setSaveStatus(null), 3000);
    } catch (e) {
      setSaveStatus("TRANSMISSION ERROR!");
      setTimeout(() => setSaveStatus(null), 3000);
    }
  };

  const handleReset = () => {
    if (settings) {
      const parsed = JSON.parse(JSON.stringify(settings));
      if (!parsed.systemControl) {
        parsed.systemControl = {
          enabled: false,
          osType: "both",
          openAppAction: true,
          readNotifications: true,
          autoTypeWhatsapp: true,
          clapSensitivity: 50,
          wakeTriggers: {
            oral: true,
            write: true,
            clap: false,
            nameWake: true
          }
        };
      }
      setLocalSettings(parsed);
    }
  };

  const updateNestedField = (
    section: "appearance" | "ai" | "security",
    field: string,
    value: any
  ) => {
    if (!localSettings) return;
    setLocalSettings({
      ...localSettings,
      [section]: {
        ...localSettings[section],
        [field]: value,
      },
    });
  };

  const updateSystemControlField = (field: string, value: any) => {
    if (!localSettings) return;
    const currentControl = localSettings.systemControl || {
      enabled: false,
      osType: "both",
      openAppAction: true,
      readNotifications: true,
      autoTypeWhatsapp: true,
      clapSensitivity: 50,
      wakeTriggers: { oral: true, write: true, clap: false, nameWake: true }
    };
    setLocalSettings({
      ...localSettings,
      systemControl: {
        ...currentControl,
        [field]: value
      }
    });
  };

  const updateWakeTrigger = (trigger: string, value: boolean) => {
    if (!localSettings) return;
    const currentControl = localSettings.systemControl || {
      enabled: false,
      osType: "both",
      openAppAction: true,
      readNotifications: true,
      autoTypeWhatsapp: true,
      clapSensitivity: 50,
      wakeTriggers: { oral: true, write: true, clap: false, nameWake: true }
    };
    setLocalSettings({
      ...localSettings,
      systemControl: {
        ...currentControl,
        wakeTriggers: {
          ...currentControl.wakeTriggers,
          [trigger]: value
        }
      }
    });
  };

  if (!localSettings) {
    return (
      <div className="flex items-center justify-center py-20 font-mono text-xs text-cyan-400 animate-pulse">
        RETRIVING MAINFRAME CONFIGURATIONS...
      </div>
    );
  }

  return (
    <motion.div
      id="jarvis_settings_tab"
      initial="hidden"
      animate="visible"
      variants={holographicContainerVariants}
      className={`h-auto lg:h-[550px] xl:h-full flex flex-col ${
        isLight ? "bg-white/90 border-slate-300 shadow-md" : "glassmorphism border-cyan-500/20"
      } rounded-xl p-5 overflow-visible lg:overflow-hidden transition-colors duration-300`}
    >
      {/* Title */}
      <motion.div
        variants={holographicSectionVariants}
        className={`flex items-center justify-between border-b ${isLight ? "border-slate-200" : "border-cyan-500/15"} pb-3 mb-4`}
      >
        <div className="flex items-center gap-2.5">
          <Settings className={`w-5 h-5 ${isLight ? "text-cyan-600" : "text-cyan-400"} animate-spin [animation-duration:15s]`} />
          <div>
            <h2 className={`font-display text-sm font-semibold ${isLight ? "text-slate-800" : "text-slate-100"} tracking-wider uppercase`}>System Mainframe Core Preferences</h2>
            <p className="text-[10px] text-slate-500 font-mono">JARVIS ADMINISTRATIVE INTERFACE OVERLAYS</p>
          </div>
        </div>

        {/* Action triggers */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={handleReset}
            className={`px-3 py-1.5 border ${
              isLight ? "border-slate-300 hover:border-slate-400 bg-slate-50 text-slate-600" : "border-cyan-500/25 hover:border-cyan-400 bg-cyan-950/5 text-cyan-400"
            } text-xs font-display font-medium rounded-lg transition-all flex items-center gap-1.5 cursor-pointer`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET</span>
          </button>
          <button
            onClick={handleSave}
            className={`px-4 py-1.5 border ${
              isLight ? "border-cyan-600 bg-cyan-500 hover:bg-cyan-600 text-white" : "border-cyan-400 bg-cyan-500 hover:bg-cyan-400 text-slate-950"
            } font-bold text-xs font-display rounded-lg transition-all flex items-center gap-1.5 shadow-[0_0_10px_rgba(34,211,238,0.25)] hover:scale-105 active:scale-95 cursor-pointer`}
          >
            <Save className="w-3.5 h-3.5" />
            <span>SAVE CORE SETTINGS</span>
          </button>
        </div>
      </motion.div>

      {saveStatus && (
        <div className={`mb-4 p-2 border ${
          isLight ? "border-cyan-300 bg-cyan-50 text-cyan-700" : "border-cyan-500/35 bg-cyan-950/20 text-cyan-400"
        } font-mono text-[10px] text-center tracking-widest rounded-lg animate-pulse uppercase`}>
          {saveStatus}
        </div>
      )}

      {/* Settings Grid Form */}
      <motion.div
        variants={holographicSectionVariants}
        className="flex-1 overflow-y-auto space-y-5 pr-1 scrollbar-thin"
      >
        {/* Appearance Settings */}
        <div className={`p-4 border ${isLight ? "border-slate-200 bg-slate-50/50" : "border-cyan-500/10 bg-slate-950/40"} rounded-xl`}>
          <div className="flex items-center gap-2.5 mb-3">
            <Eye className={`w-4.5 h-4.5 ${isLight ? "text-cyan-600" : "text-cyan-400"}`} />
            <h3 className={`font-display font-medium text-xs ${isLight ? "text-slate-800" : "text-slate-200"} uppercase tracking-widest`}>Interface HUD & Theme Mode</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 font-mono text-xs">
            <div>
              <label className="block text-[9px] text-slate-500 uppercase tracking-wider mb-1.5">Visual Matrix Theme</label>
              <select
                value={localSettings.appearance.theme}
                onChange={(e) => updateNestedField("appearance", "theme", e.target.value)}
                className={`w-full ${
                  isLight ? "bg-white border-slate-300 text-slate-800" : "bg-slate-950/85 border-cyan-500/20 text-slate-300"
                } rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-cyan-400`}
              >
                <option value="cyberpunk">Cybernetic Cyan (Default)</option>
                <option value="nebula">Deep Nebula (Purple)</option>
                <option value="omega-classic">Classic Amber Gold</option>
                <option value="stealth">Stealth Night Matrix</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] text-slate-500 uppercase tracking-wider mb-1.5">Theme Mode (Light / Dark)</label>
              <select
                value={localSettings.appearance.mode || "dark"}
                onChange={(e) => updateNestedField("appearance", "mode", e.target.value)}
                className={`w-full ${
                  isLight ? "bg-white border-slate-300 text-slate-800" : "bg-slate-950/85 border-cyan-500/20 text-slate-300"
                } rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-cyan-400`}
              >
                <option value="dark">Stealth Dark Mode (Primary)</option>
                <option value="light">Lab Cleanroom Light Mode</option>
                <option value="system">Synchronize OS System Mode</option>
              </select>
            </div>

            <div className={`flex items-center justify-between sm:justify-start gap-4 p-2 border ${
              isLight ? "border-slate-200 bg-white" : "border-cyan-500/5 bg-slate-950/30"
            } rounded-lg`}>
              <div className="flex flex-col gap-0.5">
                <span className={`font-sans text-xs ${isLight ? "text-slate-700" : "text-slate-300"}`}>Acoustics Synth</span>
                <span className="text-[8px] text-slate-500">Audio feedback chimes</span>
              </div>
              <input
                type="checkbox"
                checked={localSettings.appearance.soundEnabled}
                onChange={(e) => updateNestedField("appearance", "soundEnabled", e.target.checked)}
                className="w-4 h-4 rounded border-cyan-500 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-0 bg-slate-950 accent-cyan-400 cursor-pointer"
              />
            </div>

            <div className={`flex items-center justify-between sm:justify-start gap-4 p-2 border ${
              isLight ? "border-slate-200 bg-white" : "border-cyan-500/5 bg-slate-950/30"
            } rounded-lg`}>
              <div className="flex flex-col gap-0.5">
                <span className={`font-sans text-xs ${isLight ? "text-slate-700" : "text-slate-300"}`}>Hologrid Glow</span>
                <span className="text-[8px] text-slate-500">Neon frame shadows</span>
              </div>
              <input
                type="checkbox"
                checked={localSettings.appearance.glow}
                onChange={(e) => updateNestedField("appearance", "glow", e.target.checked)}
                className="w-4 h-4 rounded border-cyan-500 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-0 bg-slate-950 accent-cyan-400 cursor-pointer"
              />
            </div>

            <div className={`flex items-center justify-between sm:justify-start gap-4 p-2 border ${
              isLight ? "border-slate-200 bg-white" : "border-cyan-500/5 bg-slate-950/30"
            } rounded-lg`}>
              <div className="flex flex-col gap-0.5">
                <span className={`font-sans text-xs flex items-center gap-1 ${isLight ? "text-slate-700 font-medium" : "text-slate-300 font-medium"}`}>
                  <Zap className="w-3 h-3 text-yellow-400" />
                  ARC Power Save
                </span>
                <span className="text-[8px] text-slate-500">Throttle holo-core and sparkline speed below 15% battery</span>
              </div>
              <input
                type="checkbox"
                checked={localSettings.appearance.powerSaveMode || false}
                onChange={(e) => updateNestedField("appearance", "powerSaveMode", e.target.checked)}
                className="w-4 h-4 rounded border-cyan-500 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-0 bg-slate-950 accent-cyan-400 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Neural AI Settings */}
        <div className={`p-4 border ${isLight ? "border-slate-200 bg-slate-50/50" : "border-cyan-500/10 bg-slate-950/40"} rounded-xl`}>
          <div className="flex items-center gap-2.5 mb-3">
            <Cpu className={`w-4.5 h-4.5 ${isLight ? "text-cyan-600" : "text-cyan-400"}`} />
            <h3 className={`font-display font-medium text-xs ${isLight ? "text-slate-800" : "text-slate-200"} uppercase tracking-widest`}>Neural Network Matrix</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
            <div>
              <label className="block text-[9px] text-slate-500 uppercase tracking-wider mb-1.5">Core AI Model</label>
              <select
                value={localSettings.ai.model}
                onChange={(e) => updateNestedField("ai", "model", e.target.value)}
                className={`w-full ${
                  isLight ? "bg-white border-slate-300 text-slate-800" : "bg-slate-950/85 border-cyan-500/20 text-slate-300"
                } rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-cyan-400`}
              >
                <option value="gemini-3.5-flash">Gemini 3.5 Flash (Default)</option>
                <option value="gemini-3.1-pro-preview">Gemini 3.1 Pro (Deep reasoning)</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] text-slate-500 uppercase tracking-wider mb-1.5">Synthesizer Voice</label>
              <select
                value={localSettings.ai.voiceName}
                onChange={(e) => updateNestedField("ai", "voiceName", e.target.value)}
                className={`w-full ${
                  isLight ? "bg-white border-slate-300 text-slate-800" : "bg-slate-950/85 border-cyan-500/20 text-slate-300"
                } rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-cyan-400`}
              >
                <option value="Zephyr">Zephyr (British Baritone)</option>
                <option value="Kore">Kore (Clear Professional)</option>
                <option value="Puck">Puck (Acoustic Crisp)</option>
                <option value="Charon">Charon (Sub-Woofer Male)</option>
              </select>
            </div>

            <div>
              <label className="flex justify-between text-[9px] text-slate-500 uppercase tracking-wider mb-1.5">
                <span>Cognitive Temperature</span>
                <span className={`font-bold ${isLight ? "text-cyan-600" : "text-cyan-400"}`}>{localSettings.ai.temperature}</span>
              </label>
              <div className="flex items-center gap-2.5 pt-1">
                <input
                  type="range"
                  min="0.1"
                  max="1.5"
                  step="0.1"
                  value={localSettings.ai.temperature}
                  onChange={(e) => updateNestedField("ai", "temperature", parseFloat(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
              </div>
            </div>

            <div>
              <label className="flex justify-between text-[9px] text-slate-500 uppercase tracking-wider mb-1.5">
                <span>Vocal Speed Rate</span>
                <span className={`font-bold ${isLight ? "text-cyan-600" : "text-cyan-400"}`}>{(localSettings.ai.speechRate ?? 1.0).toFixed(2)}x</span>
              </label>
              <div className="flex items-center gap-2.5 pt-1">
                <input
                  type="range"
                  min="0.5"
                  max="2.0"
                  step="0.05"
                  value={localSettings.ai.speechRate ?? 1.0}
                  onChange={(e) => updateNestedField("ai", "speechRate", parseFloat(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
              </div>
            </div>
          </div>

          {/* Gemini API Key Row */}
          <div className="mt-4 pt-4 border-t border-cyan-500/5 grid grid-cols-1 md:grid-cols-12 gap-4 font-mono text-xs items-end">
            <div className="md:col-span-8">
              <label className="block text-[9px] text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                JARVIS Core Gemini API Key (Overrides Baseline Offline Simulation)
              </label>
              <div className="relative">
                <input
                  type={showApiKey ? "text" : "password"}
                  value={localSettings.geminiApiKey || ""}
                  onChange={(e) => setLocalSettings({ ...localSettings, geminiApiKey: e.target.value })}
                  placeholder="Paste your GEMINI_API_KEY here to activate genuine model intelligence..."
                  className={`w-full ${
                    isLight ? "bg-white border-slate-300 text-slate-800" : "bg-slate-950/85 border-cyan-500/20 text-slate-300"
                  } rounded-lg pl-3 pr-10 py-1.5 focus:outline-none focus:border-cyan-400 placeholder:text-slate-600`}
                />
                <button
                  type="button"
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-cyan-400 cursor-pointer text-[9px] font-bold"
                >
                  {showApiKey ? "HIDE" : "SHOW"}
                </button>
              </div>
            </div>
            <div className="md:col-span-4 p-2 rounded-lg bg-cyan-950/10 border border-cyan-500/5 text-[10px] text-slate-400 flex items-start gap-2">
              <Info className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
              <p className="font-sans leading-normal">
                Sir, providing a valid Google AI Studio key disables localized backup engines and unlocks <strong>genuine Gemini 3.6 Flash</strong> real-time cognition.
              </p>
            </div>
          </div>
        </div>

        {/* Security & Overrides */}
        <div className={`p-4 border ${isLight ? "border-slate-200 bg-slate-50/50" : "border-cyan-500/10 bg-slate-950/40"} rounded-xl`}>
          <div className="flex items-center gap-2.5 mb-3">
            <ShieldAlert className={`w-4.5 h-4.5 ${isLight ? "text-cyan-600" : "text-cyan-400"}`} />
            <h3 className={`font-display font-medium text-xs ${isLight ? "text-slate-800" : "text-slate-200"} uppercase tracking-widest`}>Security Override Firewalls</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs">
            <div>
              <label className="block text-[9px] text-slate-500 uppercase tracking-wider mb-1.5">Access Protocol Authorization Code</label>
              <select
                value={localSettings.security.protocolLevel}
                onChange={(e) => updateNestedField("security", "protocolLevel", e.target.value)}
                className={`w-full ${
                  isLight ? "bg-white border-slate-300 text-slate-800" : "bg-slate-950/85 border-cyan-500/20 text-slate-300"
                } rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-cyan-400`}
              >
                <option value="JARVIS-Level">JARVIS AI Secure Admin (Primary)</option>
                <option value="Armor-Bypass">AI Core Calibration System Bypass</option>
                <option value="Core-Only">Core Engine Only Isolation Mode</option>
              </select>
            </div>

            <div className={`p-3 rounded-lg flex gap-3 text-slate-400 text-xs ${isLight ? "bg-amber-50 border border-amber-200" : "bg-slate-950/60 border border-amber-500/10"}`}>
              <Info className="w-5 h-5 text-amber-500 flex-shrink-0" />
              <p className={`font-sans text-[11px] leading-relaxed ${isLight ? "text-slate-700" : "text-slate-400"}`}>
                <strong className="text-amber-500 font-mono text-[9px] uppercase block mb-0.5">Telemetry Note</strong>
                Secure protocols prevent unverified overrides. Changing these bypass codes updates security parameters on your hosted Node container environment instantly.
              </p>
            </div>
          </div>
        </div>

        {/* Neural System Control & Omega Link */}
        <div className={`p-4 border ${isLight ? "border-slate-200 bg-slate-50/50" : "border-cyan-500/10 bg-slate-950/40"} rounded-xl`}>
          <div className="flex items-center justify-between border-b border-cyan-500/10 pb-2 mb-3">
            <div className="flex items-center gap-2.5">
              <Smartphone className={`w-4.5 h-4.5 ${isLight ? "text-cyan-600" : "text-cyan-400"}`} />
              <h3 className={`font-display font-medium text-xs ${isLight ? "text-slate-800" : "text-slate-200"} uppercase tracking-widest`}>Omega Neural Link & System Control</h3>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-[8px] font-mono px-1.5 py-0.5 rounded uppercase tracking-wider ${
                localSettings.systemControl?.enabled 
                  ? "bg-green-500/15 text-green-400 border border-green-500/20" 
                  : "bg-slate-950 text-slate-500 border border-slate-800"
              }`}>
                {localSettings.systemControl?.enabled ? "AUTHORIZATION GRANTED" : "UNAUTHORIZED"}
              </span>
            </div>
          </div>

          <div className="space-y-4 font-mono text-xs">
            {/* Global authorization toggle */}
            <div className={`p-3 rounded-lg border ${
              localSettings.systemControl?.enabled 
                ? "bg-cyan-950/10 border-cyan-500/25" 
                : isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/40 border-slate-800"
            } flex flex-col sm:flex-row sm:items-center justify-between gap-3`}>
              <div className="space-y-0.5">
                <span className={`font-sans text-xs font-semibold ${isLight ? "text-slate-800" : "text-slate-200"}`}>
                  Grant Persistent System Control Privilege
                </span>
                <p className="text-[10px] text-slate-500 font-sans leading-relaxed">
                  Authorize JARVIS to automate linked platforms (Android & Windows) without prompting for confirmation on each core instruction.
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={localSettings.systemControl?.enabled || false}
                  onChange={(e) => updateSystemControlField("enabled", e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 rounded-full peer peer-focus:ring-0 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-slate-300 after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500 peer-checked:after:bg-slate-950"></div>
              </label>
            </div>

            {localSettings.systemControl?.enabled && (
              <>
                {/* Integration channels */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Android Core Link */}
                  <div className={`p-3 border rounded-lg ${isLight ? "bg-white border-slate-200" : "bg-slate-950/40 border-cyan-500/5"} space-y-3`}>
                    <div className="flex items-center justify-between border-b border-cyan-500/5 pb-1.5">
                      <div className="flex items-center gap-1.5">
                        <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="font-semibold text-slate-300">ANDROID_CORE_LINK</span>
                      </div>
                      <select
                        value={localSettings.systemControl.osType === "android" || localSettings.systemControl.osType === "both" ? "linked" : "disabled"}
                        onChange={(e) => {
                          const val = e.target.value;
                          const currentType = localSettings.systemControl?.osType || "both";
                          let newType: "android" | "windows" | "both" = "both";
                          if (val === "disabled") {
                            newType = currentType === "both" ? "windows" : "android"; // dummy flip
                          } else {
                            newType = currentType === "windows" ? "both" : "android";
                          }
                          updateSystemControlField("osType", newType);
                        }}
                        className="bg-slate-950 border border-cyan-500/20 text-cyan-400 text-[10px] rounded px-1.5 py-0.5 focus:outline-none"
                      >
                        <option value="linked">CONNECTED (ONLINE)</option>
                        <option value="disabled">DISCONNECTED</option>
                      </select>
                    </div>

                    <div className="space-y-2 text-[11px] font-sans text-slate-400">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={localSettings.systemControl.openAppAction}
                          onChange={(e) => updateSystemControlField("openAppAction", e.target.checked)}
                          className="w-3.5 h-3.5 rounded border-cyan-500/30 text-cyan-500 bg-slate-950 accent-cyan-400"
                        />
                        <span>Permit App Opening Protocol (simulated launcher trigger)</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={localSettings.systemControl.readNotifications}
                          onChange={(e) => updateSystemControlField("readNotifications", e.target.checked)}
                          className="w-3.5 h-3.5 rounded border-cyan-500/30 text-cyan-500 bg-slate-950 accent-cyan-400"
                        />
                        <span>Sync and Transcribe Device Notifications</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={localSettings.systemControl.autoTypeWhatsapp}
                          onChange={(e) => updateSystemControlField("autoTypeWhatsapp", e.target.checked)}
                          className="w-3.5 h-3.5 rounded border-cyan-500/30 text-cyan-500 bg-slate-950 accent-cyan-400"
                        />
                        <span>Enable WhatsApp Vocal message typist</span>
                      </label>
                    </div>
                  </div>

                  {/* Windows Core Link */}
                  <div className={`p-3 border rounded-lg ${isLight ? "bg-white border-slate-200" : "bg-slate-950/40 border-cyan-500/5"} space-y-3`}>
                    <div className="flex items-center justify-between border-b border-cyan-500/5 pb-1.5">
                      <div className="flex items-center gap-1.5">
                        <Monitor className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="font-semibold text-slate-300">WINDOWS_OS_LINK</span>
                      </div>
                      <select
                        value={localSettings.systemControl.osType === "windows" || localSettings.systemControl.osType === "both" ? "linked" : "disabled"}
                        onChange={(e) => {
                          const val = e.target.value;
                          const currentType = localSettings.systemControl?.osType || "both";
                          let newType: "android" | "windows" | "both" = "both";
                          if (val === "disabled") {
                            newType = currentType === "both" ? "android" : "windows";
                          } else {
                            newType = currentType === "android" ? "both" : "windows";
                          }
                          updateSystemControlField("osType", newType);
                        }}
                        className="bg-slate-950 border border-cyan-500/20 text-cyan-400 text-[10px] rounded px-1.5 py-0.5 focus:outline-none"
                      >
                        <option value="linked">CONNECTED (ONLINE)</option>
                        <option value="disabled">DISCONNECTED</option>
                      </select>
                    </div>

                    <div className="space-y-2 text-[11px] font-sans text-slate-400">
                      <div className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 bg-green-400 rounded-full"></span>
                        <span>Terminal Orchestrator Hook active (WSL2 Node)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 bg-green-400 rounded-full"></span>
                        <span>Shell pipeline injection authorized (PowerShell 7.4)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-slate-500 text-[9px]">Biometrics: Verified (OMEGA-ADMIN-918)</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Wake triggers */}
                <div className={`p-3 border ${isLight ? "border-slate-200" : "border-cyan-500/5"} rounded-lg space-y-3`}>
                  <span className="text-[10px] font-bold text-slate-400 tracking-wider block uppercase border-b border-cyan-500/5 pb-1.5">Hands-Free Activation Triggers</span>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-[11px]">
                    {/* Oral trigger */}
                    <div className={`p-2 border rounded-lg ${localSettings.systemControl.wakeTriggers.oral ? "bg-cyan-950/10 border-cyan-500/20" : "bg-slate-950/10 border-slate-800"} flex items-center justify-between`}>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-slate-300 font-sans font-medium">Oral Commands</span>
                        <span className="text-[8px] text-slate-500 uppercase">Voice controls</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={localSettings.systemControl.wakeTriggers.oral}
                        onChange={(e) => updateWakeTrigger("oral", e.target.checked)}
                        className="w-3.5 h-3.5 rounded border-cyan-500 text-cyan-500 bg-slate-950 accent-cyan-400 cursor-pointer"
                      />
                    </div>

                    {/* Wake word */}
                    <div className={`p-2 border rounded-lg ${localSettings.systemControl.wakeTriggers.nameWake ? "bg-cyan-950/10 border-cyan-500/20" : "bg-slate-950/10 border-slate-800"} flex items-center justify-between`}>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-slate-300 font-sans font-medium">Wake Word</span>
                        <span className="text-[8px] text-slate-500 uppercase">Call "JARVIS"</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={localSettings.systemControl.wakeTriggers.nameWake}
                        onChange={(e) => updateWakeTrigger("nameWake", e.target.checked)}
                        className="w-3.5 h-3.5 rounded border-cyan-500 text-cyan-500 bg-slate-950 accent-cyan-400 cursor-pointer"
                      />
                    </div>

                    {/* Clap wake */}
                    <div className={`p-2 border rounded-lg ${localSettings.systemControl.wakeTriggers.clap ? "bg-cyan-950/10 border-cyan-500/20" : "bg-slate-950/10 border-slate-800"} flex items-center justify-between`}>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-slate-300 font-sans font-medium">Clap Activation</span>
                        <span className="text-[8px] text-slate-500 uppercase">Double-clap</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={localSettings.systemControl.wakeTriggers.clap}
                        onChange={(e) => updateWakeTrigger("clap", e.target.checked)}
                        className="w-3.5 h-3.5 rounded border-cyan-500 text-cyan-500 bg-slate-950 accent-cyan-400 cursor-pointer"
                      />
                    </div>

                    {/* Written wake */}
                    <div className={`p-2 border rounded-lg ${localSettings.systemControl.wakeTriggers.write ? "bg-cyan-950/10 border-cyan-500/20" : "bg-slate-950/10 border-slate-800"} flex items-center justify-between`}>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-slate-300 font-sans font-medium">Written Trigger</span>
                        <span className="text-[8px] text-slate-500 uppercase">Text input</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={localSettings.systemControl.wakeTriggers.write}
                        onChange={(e) => updateWakeTrigger("write", e.target.checked)}
                        className="w-3.5 h-3.5 rounded border-cyan-500 text-cyan-500 bg-slate-950 accent-cyan-400 cursor-pointer"
                      />
                    </div>
                  </div>

                  {localSettings.systemControl.wakeTriggers.clap && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                      <div>
                        <label className="flex justify-between text-[9px] text-slate-500 uppercase tracking-wider mb-1">
                          <span>Acoustics Clap Sensitivity</span>
                          <span className="font-bold text-cyan-400">{localSettings.systemControl.clapSensitivity}%</span>
                        </label>
                        <input
                          type="range"
                          min="10"
                          max="90"
                          step="5"
                          value={localSettings.systemControl.clapSensitivity}
                          onChange={(e) => updateSystemControlField("clapSensitivity", parseInt(e.target.value))}
                          className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                        />
                      </div>
                      <div className="p-2 bg-cyan-950/10 rounded border border-cyan-500/10 text-slate-400 text-[10px] leading-relaxed font-sans">
                        Requires microphone capability. Double-clapping with a sharp decibel amplitude spike exceeding threshold will instantly boot JARVIS into full conversational listening.
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Vocal Command Protocol Registry */}
        <div className={`p-4 border ${isLight ? "border-slate-200 bg-slate-50/50" : "border-cyan-500/10 bg-slate-950/40"} rounded-xl`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-cyan-500/10 pb-3 mb-3">
            <div className="flex items-center gap-2.5">
              <Mic className={`w-4.5 h-4.5 ${isLight ? "text-cyan-600" : "text-cyan-400"}`} />
              <div>
                <h3 className={`font-display font-medium text-xs ${isLight ? "text-slate-800" : "text-slate-200"} uppercase tracking-widest`}>
                  Vocal Command Protocol Registry
                </h3>
                <p className="text-[9px] text-slate-500 font-mono mt-0.5">ACOUSTICAL PATTERN INTERCEPTOR ENGINE</p>
              </div>
            </div>

            {/* Search Input */}
            <div className="relative">
              <input
                type="text"
                placeholder="Search command pattern..."
                value={vocalSearch}
                onChange={(e) => setVocalSearch(e.target.value)}
                className={`w-full sm:w-64 font-mono text-xs pl-8 pr-3 py-1.5 border rounded-lg ${
                  isLight 
                    ? "bg-white border-slate-300 text-slate-800 placeholder-slate-400 focus:border-cyan-500" 
                    : "bg-slate-950/90 border-cyan-500/20 text-cyan-400 placeholder-cyan-500/30 focus:border-cyan-400"
                } outline-none transition-all`}
              />
              <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-500" />
            </div>
          </div>

          <div className="space-y-3">
            <p className="text-[11px] font-sans text-slate-400 leading-relaxed">
              JARVIS continuously listens for vocal trigger waves (when conversational listening is active) and intercepts registered speech patterns locally. This bypasses standard LLM execution, enabling <strong>instantaneous zero-latency interface actions</strong>.
            </p>

            <div className={`border ${isLight ? "border-slate-200" : "border-cyan-500/5"} rounded-lg overflow-hidden`}>
              <div className="overflow-x-auto">
                <table className="w-full font-mono text-xs text-left border-collapse">
                  <thead>
                    <tr className={`border-b ${isLight ? "bg-slate-100 border-slate-200 text-slate-600" : "bg-slate-950/60 border-cyan-500/10 text-slate-400"}`}>
                      <th className="p-2.5 font-bold text-[9px] uppercase tracking-wider">Spoken Phrase Trigger</th>
                      <th className="p-2.5 font-bold text-[9px] uppercase tracking-wider">HUD Action & Protocol</th>
                      <th className="p-2.5 font-bold text-[9px] uppercase tracking-wider hidden md:table-cell">Category</th>
                      <th className="p-2.5 font-bold text-[9px] uppercase tracking-wider text-center">Authorization</th>
                      <th className="p-2.5 font-bold text-[9px] uppercase tracking-wider text-right">Simulation</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-cyan-500/5">
                    {(() => {
                      const voiceCommands = [
                        {
                          phrase: "Open Files",
                          altPhrases: ["switch to files", "show files", "go to files", "files tab"],
                          category: "HUD & Navigation",
                          action: "Redirect active HUD to Filer Records tab",
                          details: "Opens secure archive databases containing media feeds and stored telemetry.",
                          authorized: true
                        },
                        {
                          phrase: "Run Diagnostics",
                          altPhrases: ["start diagnostics", "diagnostics sweep", "initiate diagnostics"],
                          category: "System Core Operations",
                          action: "Initiate full localized diagnostic suite sweep",
                          details: "Runs comprehensive health checks on memory storage, CPU loads, and active processes.",
                          authorized: true
                        },
                        {
                          phrase: "Clear Memory",
                          altPhrases: ["wipe memory", "erase memory", "wipe memories"],
                          category: "System Core Operations",
                          action: "Securely purge active diagnostic logs and records",
                          details: "Performs full local cache sweep of stored mainframe diagnostics data.",
                          authorized: true
                        },
                        {
                          phrase: "Open Task Monitor",
                          altPhrases: ["switch to tasks", "show task monitor", "monitor processes"],
                          category: "HUD & Navigation",
                          action: "Redirect active HUD to Subprocess Task Monitor tab",
                          details: "Displays real-time background threads and automation sub-queues.",
                          authorized: true
                        },
                        {
                          phrase: "Open Memory",
                          altPhrases: ["switch to memory", "show memory vault", "go to memory"],
                          category: "HUD & Navigation",
                          action: "Redirect active HUD to Omega Memory Vault tab",
                          details: "Accesses stored conversational history index.",
                          authorized: true
                        },
                        {
                          phrase: "Open Chat",
                          altPhrases: ["switch to chat", "show chat console", "go to chat"],
                          category: "HUD & Navigation",
                          action: "Redirect active HUD to main Chat Console",
                          details: "Opens primary system terminal for cognitive simulation inquiries.",
                          authorized: true
                        },
                        {
                          phrase: "Open Settings",
                          altPhrases: ["switch to settings", "show settings", "go to settings"],
                          category: "HUD & Navigation",
                          action: "Redirect active HUD to Mainframe Preferences tab",
                          details: "Switches screen instantly to configuration matrices.",
                          authorized: true
                        },
                        {
                          phrase: "Go full screen",
                          altPhrases: ["maximize chat", "expand chat", "full screen chat"],
                          category: "HUD & Navigation",
                          action: "Toggle full-screen console terminal matrix",
                          details: "Expands main terminal and hides diagnostic sidebars.",
                          authorized: true
                        },
                        {
                          phrase: "Exit full screen",
                          altPhrases: ["minimize chat", "exit chat full screen", "normal screen"],
                          category: "HUD & Navigation",
                          action: "Restore split diagnostic sidebar monitors",
                          details: "Returns layout to standard multi-column display.",
                          authorized: true
                        },
                        {
                          phrase: "Switch to light mode",
                          altPhrases: ["enable light mode", "light theme"],
                          category: "Interface & Themes",
                          action: "Activate lab cleanroom light mode theme",
                          details: "Switches visual system styling to high-contrast white matrix.",
                          authorized: true
                        },
                        {
                          phrase: "Switch to dark mode",
                          altPhrases: ["enable dark mode", "dark theme"],
                          category: "Interface & Themes",
                          action: "Activate stealth gold-cyan dark mode theme",
                          details: "Restores visual system styling to eye-safe nocturnal matrix.",
                          authorized: true
                        },
                        {
                          phrase: "Mute acoustics",
                          altPhrases: ["disable sound", "mute sound", "turn off sound"],
                          category: "Interface & Themes",
                          action: "Disable vocal synthesizer speech & sound chimes",
                          details: "Silences vocal readouts and audio cues.",
                          authorized: true
                        },
                        {
                          phrase: "Unmute acoustics",
                          altPhrases: ["enable sound", "unmute sound", "turn on sound"],
                          category: "Interface & Themes",
                          action: "Enable vocal synthesizer speech & sound chimes",
                          details: "Restores natural acoustic voice line feedback.",
                          authorized: true
                        },
                        {
                          phrase: "Open browser",
                          altPhrases: ["open google", "open youtube", "open spotify", "launch vscode"],
                          category: "Omega Neural Link Automation",
                          action: "Trigger simulated device app launcher protocol",
                          details: "Launches requested web workspace or software package.",
                          authorized: localSettings?.systemControl?.enabled || false
                        },
                        {
                          phrase: "WhatsApp to Operator saying Hello",
                          altPhrases: ["whatsapp to Team", "send message", "type message"],
                          category: "Omega Neural Link Automation",
                          action: "Transmit typed or voiced WhatsApp payload",
                          details: "Laverages Neural Link to auto-type and send external communication.",
                          authorized: localSettings?.systemControl?.enabled || false
                        },
                        {
                          phrase: "Sync notifications",
                          altPhrases: ["check messages", "any alerts", "check notifications"],
                          category: "Omega Neural Link Automation",
                          action: "Synchronize connected mobile alert stream",
                          details: "Transcribes phone notification registers into primary HUD feed.",
                          authorized: localSettings?.systemControl?.enabled || false
                        },
                        {
                          phrase: "Analyse phone",
                          altPhrases: ["business work report", "analyze phone", "business task"],
                          category: "Omega Neural Link Automation",
                          action: "Perform diagnostic scan and audit business journals",
                          details: "Summarizes mobile hardware states and pending contracts.",
                          authorized: localSettings?.systemControl?.enabled || false
                        }
                      ];

                      const filteredCommands = voiceCommands.filter(cmd => 
                        cmd.phrase.toLowerCase().includes(vocalSearch.toLowerCase()) ||
                        cmd.category.toLowerCase().includes(vocalSearch.toLowerCase()) ||
                        cmd.action.toLowerCase().includes(vocalSearch.toLowerCase()) ||
                        cmd.altPhrases.some(alt => alt.toLowerCase().includes(vocalSearch.toLowerCase()))
                      );

                      if (filteredCommands.length > 0) {
                        return filteredCommands.map((cmd) => (
                          <tr 
                            key={cmd.phrase} 
                            className={`group transition-colors ${
                              isLight ? "hover:bg-slate-50/80" : "hover:bg-cyan-950/5"
                            }`}
                          >
                            <td className="p-2.5 align-top">
                              <div className="flex flex-col gap-1">
                                <span className={`font-semibold px-2 py-0.5 rounded border inline-block w-fit text-[11px] ${
                                  isLight 
                                    ? "bg-slate-100 border-slate-200 text-slate-800" 
                                    : "bg-cyan-950/20 border-cyan-500/25 text-cyan-300"
                                }`}>
                                  "{cmd.phrase}"
                                </span>
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {cmd.altPhrases.map(alt => (
                                    <span key={alt} className="text-[8px] text-slate-500 border border-slate-800/20 px-1 rounded">
                                      "{alt}"
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </td>
                            <td className="p-2.5 align-top">
                              <div className="space-y-0.5 max-w-xs md:max-w-md">
                                <span className={`font-sans text-[11px] font-semibold block ${isLight ? "text-slate-800" : "text-slate-200"}`}>
                                  {cmd.action}
                                </span>
                                <span className="text-[10px] text-slate-500 font-sans block leading-relaxed">
                                  {cmd.details}
                                </span>
                              </div>
                            </td>
                            <td className="p-2.5 align-top hidden md:table-cell">
                              <span className={`text-[8px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider ${
                                cmd.category.includes("Omega") 
                                  ? "bg-amber-500/10 text-amber-500 border border-amber-500/20"
                                  : cmd.category.includes("System")
                                  ? "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                                  : "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20"
                              }`}>
                                {cmd.category}
                              </span>
                            </td>
                            <td className="p-2.5 align-top text-center">
                              <span className={`text-[9px] font-bold uppercase tracking-wider ${
                                cmd.authorized 
                                  ? "text-green-400" 
                                  : "text-rose-500"
                              }`}>
                                {cmd.authorized ? "● GRANTED" : "○ DISALLOWED"}
                              </span>
                            </td>
                            <td className="p-2.5 align-top text-right">
                              <button
                                onClick={() => {
                                  sendMessage(cmd.phrase);
                                }}
                                className={`p-1 border rounded hover:scale-105 active:scale-95 transition-all text-[10px] font-bold tracking-wider inline-flex items-center gap-1 cursor-pointer ${
                                  cmd.authorized
                                    ? isLight 
                                      ? "bg-cyan-50 border-cyan-200 text-cyan-600 hover:bg-cyan-100" 
                                      : "bg-cyan-500/10 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/20"
                                    : "bg-slate-950 border-slate-800 text-slate-500 cursor-not-allowed opacity-50"
                                }`}
                                title={cmd.authorized ? `Simulate speaking "${cmd.phrase}"` : "Require Neural Link permission"}
                                disabled={!cmd.authorized}
                              >
                                <Play className="w-3 h-3" />
                                <span className="hidden sm:inline">SIMULATE</span>
                              </button>
                            </td>
                          </tr>
                        ));
                      } else {
                        return (
                          <tr>
                            <td colSpan={5} className="p-8 text-center text-slate-500 italic">
                              No matching spoken phrases found in the registry. Try searching "files", "diagnostic", or "memory".
                            </td>
                          </tr>
                        );
                      }
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
