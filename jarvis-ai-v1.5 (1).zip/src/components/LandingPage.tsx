import React from "react";
import { motion } from "motion/react";
import { 
  Cpu, 
  Database, 
  ShieldCheck, 
  Activity, 
  HardDrive, 
  Radio, 
  ArrowRight,
  Sparkles,
  Layers,
  Terminal,
  Compass
} from "lucide-react";

interface LandingPageProps {
  onEnterProtocol: () => void;
}

export default function LandingPage({ onEnterProtocol }: LandingPageProps) {
  // Description of subsystems for visual grid layout
  const subsystems = [
    {
      icon: <Radio className="w-4 h-4 text-cyan-400" />,
      title: "AICore Cognitive Interface",
      status: "ONLINE",
      description: "Generative vocalization, fluid listening frequency analysis, and real-time canvas waveform diagnostics."
    },
    {
      icon: <Database className="w-4 h-4 text-purple-400" />,
      title: "Neural Memory Bank",
      status: "SYNCHRONIZED",
      description: "Local cognitive memory logs mapped with secure priority pins, custom classification taxonomy, and search indexes."
    },
    {
      icon: <Activity className="w-4 h-4 text-teal-400" />,
      title: "Telemetry Process Center",
      status: "OPTIMAL",
      description: "Track system threads, resource-drains, compile reports, and simulate multi-threaded task completions."
    },
    {
      icon: <HardDrive className="w-4 h-4 text-emerald-400" />,
      title: "Mainframe Storage",
      status: "SECURED",
      description: "File processing suite capable of compiling comprehensive diagnostic reports, system logs, and security sweep summaries."
    },
    {
      icon: <Compass className="w-4 h-4 text-amber-400" />,
      title: "Environmental Metrics",
      status: "ACTIVE",
      description: "Continuous observation of host hardware coordinates, battery levels, geographic telemetry, and core processor load."
    },
    {
      icon: <ShieldCheck className="w-4 h-4 text-indigo-400" />,
      title: "Autonomous Crypt Integrity",
      status: "ENCRYPTED",
      description: "100% local database isolation, credentials lock, and complete user security. No external metric leakage."
    }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between relative p-4 md:p-8 overflow-x-hidden select-none font-mono">
      {/* Cyber HUD Grid & Radial Background Glow */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:3.5rem_3.5rem] opacity-25 pointer-events-none" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-cyan-500/5 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-0 right-10 w-[400px] h-[400px] bg-purple-500/5 rounded-full blur-[120px] pointer-events-none" />

      {/* Header */}
      <header className="w-full max-w-7xl mx-auto flex items-center justify-between border-b border-slate-900 pb-4 z-10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-center">
            <Cpu className="w-4 h-4 text-cyan-400 animate-pulse" />
          </div>
          <div>
            <span className="text-sm font-bold tracking-[0.2em] text-slate-200">JARVIS AI</span>
            <span className="text-[8px] text-cyan-500/60 block tracking-widest font-mono">v1.50 OPERATING SYSTEM</span>
          </div>
        </div>
        <div className="flex items-center gap-4 text-[10px] text-slate-500">
          <span className="hidden sm:inline border border-cyan-500/20 px-2 py-0.5 rounded bg-cyan-950/20 text-cyan-400">
            SECURE DIRECT LINK
          </span>
          <span className="font-mono text-slate-400">STATUS: READY</span>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="w-full max-w-7xl mx-auto flex flex-col lg:grid lg:grid-cols-12 gap-8 items-center justify-center my-auto py-8 z-10">
        
        {/* Left Side: Holo Arc Core Graphic & Brand Pitch */}
        <div className="lg:col-span-5 flex flex-col items-center lg:items-start text-center lg:text-left space-y-6">
          
          {/* Pulsing ARC Reactor Art */}
          <div className="relative w-48 h-48 flex items-center justify-center mb-4 lg:ml-4">
            {/* Outer rings */}
            <div className="absolute inset-0 rounded-full border-2 border-dashed border-cyan-500/20 animate-[spin_60s_linear_infinite]" />
            <div className="absolute inset-4 rounded-full border border-cyan-500/40 animate-[spin_30s_linear_infinite_reverse]" />
            <div className="absolute inset-8 rounded-full border-4 border-double border-purple-500/20" />
            
            {/* Pulsing Core */}
            <div className="absolute inset-12 rounded-full bg-cyan-950/20 border border-cyan-400/50 flex items-center justify-center shadow-[0_0_35px_rgba(34,211,238,0.25)]">
              <Cpu className="w-12 h-12 text-cyan-400 animate-pulse" />
            </div>
            
            {/* Glowing Accent Orbs on outer edge */}
            <div className="absolute top-2 left-1/2 -translate-x-1/2 w-2 h-2 bg-cyan-400 rounded-full shadow-[0_0_10px_rgba(34,211,238,0.8)] animate-ping" />
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-2 h-2 bg-purple-400 rounded-full shadow-[0_0_10px_rgba(168,85,247,0.8)]" />
            <div className="absolute left-2 top-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-cyan-400 rounded-full" />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-cyan-400 rounded-full" />
          </div>

          <div className="space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-cyan-950/40 border border-cyan-500/20 rounded-full text-[9px] uppercase tracking-widest text-cyan-400 font-bold">
              <Sparkles className="w-3 h-3 animate-spin" />
              INTELLIGENT SYSTEM CONSOLE
            </div>
            <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-slate-100 via-cyan-100 to-cyan-300 uppercase leading-none">
              Orchestrate Your <br />
              <span className="text-cyan-400 font-black">Digital Core.</span>
            </h1>
            <p className="text-xs text-slate-400 max-w-md leading-relaxed font-sans">
              Welcome to JARVIS AI. Establish control over a unified virtual console offering persistent biometric memory banks, active process controllers, diagnostic report sweep, and live voice-activated cognitive responses.
            </p>
          </div>

          {/* Central Call-to-Action Button */}
          <div className="w-full pt-4 flex flex-col items-center justify-center text-center">
            <button
              id="btn-initialize-mainframe"
              onClick={onEnterProtocol}
              className="px-8 py-4 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-400/40 hover:border-cyan-400 rounded-xl text-xs font-bold tracking-[0.2em] text-cyan-300 hover:text-cyan-100 transition-all duration-300 flex items-center justify-center gap-3 cursor-pointer group shadow-[0_0_25px_rgba(6,182,212,0.15)] hover:shadow-[0_0_35px_rgba(6,182,212,0.3)] hover:scale-[1.02] active:scale-[0.98] w-full sm:w-auto"
            >
              INITIALIZE COGNITIVE LINK
              <ArrowRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-1.5 transition-transform" />
            </button>
            <span className="text-[9px] text-slate-500 mt-2 block tracking-wider uppercase text-center w-full">
              PROTOCOL SECURED BY HIGH-FIDELITY BIOMETRICS
            </span>
          </div>

        </div>

        {/* Right Side: Core Modules Grid Display */}
        <div className="lg:col-span-7 w-full grid grid-cols-1 md:grid-cols-2 gap-4">
          {subsystems.map((sub, index) => (
            <motion.div
              key={sub.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.08 }}
              className="p-4 bg-slate-950/60 backdrop-blur border border-slate-900 hover:border-cyan-500/30 rounded-xl transition-all duration-300 relative overflow-hidden group"
            >
              <div className="absolute top-0 right-0 w-8 h-8 opacity-10 group-hover:opacity-20 pointer-events-none transition-opacity">
                <Terminal className="w-full h-full text-cyan-500" />
              </div>
              <div className="flex items-center gap-2.5 mb-2.5">
                <div className="p-2 rounded bg-slate-900 border border-slate-800">
                  {sub.icon}
                </div>
                <div>
                  <h3 className="font-bold text-xs text-slate-200 tracking-wider uppercase">
                    {sub.title}
                  </h3>
                  <span className="text-[8px] text-cyan-400 font-mono tracking-widest block font-bold">
                    [{sub.status}]
                  </span>
                </div>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                {sub.description}
              </p>
            </motion.div>
          ))}
        </div>

      </main>

      {/* Footer */}
      <footer className="w-full max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between border-t border-slate-900 pt-4 text-[10px] text-slate-500 z-10 gap-3">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
          <span>JARVIS SYSTEM MAINBOARD SECURE CLIENT CHANNEL</span>
        </div>
        <div className="flex items-center gap-6">
          <span>NO DATA TELEMETRY EXPORT</span>
          <span>LATENCY: 0.12ms</span>
          <span>© {new Date().getFullYear()} JARVIS AI OS</span>
        </div>
      </footer>
    </div>
  );
}
