import React, { useState, useEffect, useRef, useMemo } from "react";
import { useJarvisStore } from "../stores/jarvisStore";
import { 
  Search, 
  MessageSquare, 
  Cpu, 
  HardDrive, 
  Brain, 
  Clock, 
  X, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Command,
  ArrowRight
} from "lucide-react";
import { Conversation, Task, FileRecord, Memory } from "../types";

interface GlobalSearchProps {
  isLight: boolean;
}

interface SearchResult {
  id: string;
  type: "conversation" | "task" | "file" | "memory";
  title: string;
  subtitle: string;
  badge?: string;
  badgeColor?: string;
  timestamp?: string;
  matchExcerpt?: string;
}

export default function GlobalSearch({ isLight }: GlobalSearchProps) {
  const { 
    conversations, 
    tasks, 
    files, 
    memories, 
    setTab, 
    selectConversation, 
    addToast 
  } = useJarvisStore();

  const [query, setQuery] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Auto focus shortcut (Ctrl+K or Cmd+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        inputRef.current?.focus();
        setIsOpen(true);
      } else if (e.key === "Escape") {
        setIsOpen(false);
        inputRef.current?.blur();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Click outside to close
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Format file size
  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  // Build filtered search results
  const results = useMemo((): SearchResult[] => {
    if (!query.trim()) return [];
    
    const q = query.toLowerCase();
    const list: SearchResult[] = [];

    // 1. Search Conversations
    conversations.forEach((conv) => {
      const matchTitle = conv.title.toLowerCase().includes(q);
      let matchContent = "";
      
      // Find matching message content
      const matchingMessage = conv.messages.find(msg => 
        msg.content.toLowerCase().includes(q)
      );

      if (matchingMessage) {
        const index = matchingMessage.content.toLowerCase().indexOf(q);
        const start = Math.max(0, index - 30);
        const end = Math.min(matchingMessage.content.length, index + q.length + 40);
        const snippet = matchingMessage.content.substring(start, end);
        matchContent = `...${snippet}${end < matchingMessage.content.length ? "..." : ""}`;
      }

      if (matchTitle || matchContent) {
        list.push({
          id: conv.id,
          type: "conversation",
          title: conv.title,
          subtitle: `Conversation Folder: ${conv.folder || "Unsorted"}`,
          badge: conv.pin ? "PINNED" : undefined,
          badgeColor: "bg-amber-500/10 text-amber-400 border border-amber-500/20",
          timestamp: new Date(conv.createdAt).toLocaleDateString(),
          matchExcerpt: matchContent || undefined
        });
      }
    });

    // 2. Search Tasks
    tasks.forEach((task) => {
      const matchName = task.name.toLowerCase().includes(q);
      const matchType = task.type.toLowerCase().includes(q);
      let matchLog = "";

      // Find matching log line
      const matchingLog = task.logs?.find(log => log.toLowerCase().includes(q));
      if (matchingLog) {
        const index = matchingLog.toLowerCase().indexOf(q);
        const start = Math.max(0, index - 25);
        const end = Math.min(matchingLog.length, index + q.length + 35);
        const snippet = matchingLog.substring(start, end);
        matchLog = `[Log Match] ...${snippet}...`;
      }

      if (matchName || matchType || matchLog) {
        let statusBadgeColor = "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20";
        if (task.status === "completed") statusBadgeColor = "bg-green-500/10 text-green-400 border border-green-500/20";
        if (task.status === "failed") statusBadgeColor = "bg-red-500/10 text-red-400 border border-red-500/20";

        list.push({
          id: task.id,
          type: "task",
          title: task.name,
          subtitle: `${task.type} Thread (${task.progress}% complete)`,
          badge: task.status.toUpperCase(),
          badgeColor: statusBadgeColor,
          timestamp: new Date(task.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          matchExcerpt: matchLog || undefined
        });
      }
    });

    // 3. Search Files
    files.forEach((file) => {
      if (file.name.toLowerCase().includes(q) || file.type.toLowerCase().includes(q)) {
        list.push({
          id: file.id,
          type: "file",
          title: file.name,
          subtitle: `File Size: ${formatBytes(file.size)}`,
          badge: file.type.toUpperCase(),
          badgeColor: "bg-purple-500/10 text-purple-400 border border-purple-500/20",
          timestamp: new Date(file.timestamp).toLocaleDateString()
        });
      }
    });

    // 4. Search Memories
    memories.forEach((mem) => {
      if (mem.content.toLowerCase().includes(q) || mem.category.toLowerCase().includes(q)) {
        const index = mem.content.toLowerCase().indexOf(q);
        const start = Math.max(0, index - 30);
        const end = Math.min(mem.content.length, index + q.length + 40);
        const snippet = mem.content.substring(start, end);
        const matchExcerpt = `...${snippet}${end < mem.content.length ? "..." : ""}`;

        list.push({
          id: mem.id,
          type: "memory",
          title: `Memory Core // ${mem.category.toUpperCase()}`,
          subtitle: mem.content.substring(0, 80) + (mem.content.length > 80 ? "..." : ""),
          badge: mem.pinned ? "PINNED" : undefined,
          badgeColor: "bg-rose-500/10 text-rose-400 border border-rose-500/20",
          timestamp: new Date(mem.date).toLocaleDateString(),
          matchExcerpt: matchExcerpt
        });
      }
    });

    return list;
  }, [query, conversations, tasks, files, memories]);

  // Reset selected index when results change
  useEffect(() => {
    setSelectedIndex(0);
  }, [results]);

  // Handle Result Action click
  const handleItemClick = (item: SearchResult) => {
    if (item.type === "conversation") {
      setTab("chat");
      selectConversation(item.id);
      addToast(`Switched to Conversation: "${item.title}"`, "success");
    } else if (item.type === "task") {
      setTab("tasks");
      addToast(`Located Task Thread: "${item.title}"`, "info");
    } else if (item.type === "file") {
      setTab("files");
      addToast(`Opening Decentralized Files for: "${item.title}"`, "info");
    } else if (item.type === "memory") {
      setTab("memory");
      addToast(`Located Memory Block: "${item.title}"`, "info");
    }
    setQuery("");
    setIsOpen(false);
    inputRef.current?.blur();
  };

  // Keyboard navigation helpers
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (results.length === 0) return;

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % results.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + results.length) % results.length);
    } else if (e.key === "Enter") {
      e.preventDefault();
      handleItemClick(results[selectedIndex]);
    }
  };

  // Highlighter utility
  const highlightMatch = (text: string, search: string) => {
    if (!search) return text;
    const parts = text.split(new RegExp(`(${search.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")})`, "gi"));
    return (
      <span>
        {parts.map((part, i) => 
          part.toLowerCase() === search.toLowerCase() ? (
            <mark key={i} className="bg-yellow-500/30 text-yellow-200 px-0.5 rounded font-bold">
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </span>
    );
  };

  return (
    <div ref={containerRef} className="relative w-full max-w-sm sm:max-w-md mx-auto z-50">
      {/* Search Input Box */}
      <div className="relative">
        <Search className={`absolute left-3.5 top-1/2 transform -translate-y-1/2 w-4 h-4 ${
          isLight ? "text-slate-400" : "text-cyan-500/60"
        }`} />
        
        <input
          ref={inputRef}
          type="text"
          placeholder="Global system sweep... (⌘K / Ctrl+K)"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          className={`w-full py-2 pl-10 pr-10 font-sans text-xs border rounded-xl transition-all duration-300 ${
            isLight
              ? "bg-slate-100 border-slate-200 text-slate-800 placeholder-slate-400 focus:bg-white focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/20"
              : "bg-slate-950/40 border-cyan-500/20 text-slate-200 placeholder-cyan-500/30 focus:bg-slate-950/80 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/20 shadow-[inset_0_1px_4px_rgba(0,0,0,0.6)]"
          }`}
        />

        {query ? (
          <button
            onClick={() => {
              setQuery("");
              inputRef.current?.focus();
            }}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer transition-colors hover:text-red-400 p-0.5"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        ) : (
          <div className="absolute right-3.5 top-1/2 transform -translate-y-1/2 hidden md:flex items-center gap-0.5 px-1.5 py-0.5 border rounded text-[8px] font-mono select-none pointer-events-none opacity-40">
            <Command className="w-2 h-2" />
            <span>K</span>
          </div>
        )}
      </div>

      {/* Results Popup Overlay */}
      {isOpen && query.trim() && (
        <div className={`absolute top-full mt-2 left-0 right-0 max-h-[420px] overflow-y-auto rounded-xl border shadow-2xl backdrop-blur-md flex flex-col z-50 ${
          isLight 
            ? "bg-white/95 border-slate-200 shadow-slate-300/40 text-slate-800" 
            : "bg-slate-950/95 border-cyan-500/25 shadow-black/80 text-slate-200"
        }`}>
          {/* Header context info */}
          <div className={`px-4 py-2 border-b text-[10px] font-mono tracking-widest uppercase flex justify-between items-center ${
            isLight ? "bg-slate-50 border-slate-150 text-slate-500" : "bg-cyan-950/20 border-cyan-500/10 text-cyan-400/80"
          }`}>
            <span>SCAN RESULTS // INTEGRATED INDEX</span>
            <span className="font-bold">{results.length} MATCH{results.length === 1 ? "" : "ES"}</span>
          </div>

          {/* Results list */}
          {results.length > 0 ? (
            <div className="py-1.5 divide-y divide-cyan-500/5">
              {results.map((item, idx) => {
                const isSelected = idx === selectedIndex;
                let Icon = MessageSquare;
                if (item.type === "task") Icon = Cpu;
                if (item.type === "file") Icon = HardDrive;
                if (item.type === "memory") Icon = Brain;

                return (
                  <div
                    key={`${item.type}-${item.id}`}
                    onClick={() => handleItemClick(item)}
                    onMouseEnter={() => setSelectedIndex(idx)}
                    className={`px-4 py-3 cursor-pointer transition-all flex flex-col gap-1 relative ${
                      isSelected 
                        ? isLight 
                          ? "bg-cyan-50/70 border-l-2 border-cyan-500" 
                          : "bg-cyan-950/30 border-l-2 border-cyan-400" 
                        : "border-l-2 border-transparent"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Icon className={`w-3.5 h-3.5 flex-shrink-0 ${
                          item.type === "conversation" ? "text-cyan-400" :
                          item.type === "task" ? "text-purple-400" :
                          item.type === "file" ? "text-amber-400" : "text-rose-400"
                        }`} />
                        <span className="font-sans font-semibold text-xs tracking-wide truncate">
                          {highlightMatch(item.title, query)}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        {item.badge && (
                          <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded tracking-wider uppercase ${item.badgeColor}`}>
                            {item.badge}
                          </span>
                        )}
                        <span className="text-[9px] font-mono text-slate-500">
                          {item.timestamp}
                        </span>
                      </div>
                    </div>

                    <div className="text-[10px] text-slate-400 line-clamp-1">
                      {item.subtitle}
                    </div>

                    {item.matchExcerpt && (
                      <div className={`mt-1.5 p-1.5 rounded text-[10px] font-mono leading-relaxed break-all ${
                        isLight ? "bg-slate-100 text-slate-600" : "bg-slate-900/60 text-cyan-200/80 border border-cyan-950/20"
                      }`}>
                        {highlightMatch(item.matchExcerpt, query)}
                      </div>
                    )}

                    {isSelected && (
                      <div className="absolute right-3 bottom-3 text-cyan-400 flex items-center gap-1 text-[8px] font-mono animate-pulse">
                        <span>OPEN</span>
                        <ArrowRight className="w-2.5 h-2.5" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 flex flex-col items-center justify-center text-center gap-3">
              <AlertCircle className="w-8 h-8 text-slate-500 animate-pulse" />
              <div className="space-y-1">
                <p className="font-mono text-xs text-slate-400 uppercase tracking-widest font-bold">
                  No Telemetry Matches Found
                </p>
                <p className="text-[10px] text-slate-500 max-w-xs">
                  The mainframe indexes did not locate any active conversations, background tasks, or memory vaults matching <span className="font-bold text-cyan-400">"{query}"</span>.
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
