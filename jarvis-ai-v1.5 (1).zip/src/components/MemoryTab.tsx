/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { useJarvisStore } from "../stores/jarvisStore";
import { motion } from "motion/react";
import { 
  Pin, 
  Trash2, 
  Search, 
  Brain, 
  Calendar, 
  Plus, 
  Sparkles, 
  Layers,
  Database,
  Lock
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";

export default function MemoryTab() {
  const { 
    memories, 
    memoriesLoading, 
    fetchMemories, 
    addMemory, 
    deleteMemory, 
    togglePinMemory,
    recentActivities = [],
    tasks = []
  } = useJarvisStore();
  const [searchQuery, setSearchQuery] = useState("");
  const [newContent, setNewContent] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Armor Core");

  const getInteractionData = () => {
    const days = [];
    const now = new Date();
    
    // Past 7 days base activities for beautiful seeding
    const baseInteractions = [12, 18, 14, 25, 21, 29, 10];
    const taskSpikes = [2, 4, 3, 6, 5, 8, 2];

    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(now.getDate() - i);
      const dateStr = d.toLocaleDateString([], { month: "short", day: "numeric" });
      
      let interactions = baseInteractions[6 - i];
      let tCount = taskSpikes[6 - i];

      // Merge current live data counts for today (i === 0)
      if (i === 0) {
        interactions += recentActivities.length;
        tCount += tasks.filter(t => t.status === "running" || t.status === "completed").length;
      }

      days.push({
        name: dateStr,
        Interactions: interactions,
        Tasks: tCount,
      });
    }
    return days;
  };

  const chartData = getInteractionData();

  const holographicContainerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const holographicSectionVariants = {
    hidden: { 
      opacity: 0, 
      y: 20,
      filter: "hue-rotate(-15deg) brightness(1.3) contrast(1.1) drop-shadow(0 0 12px rgba(6,182,212,0.4))",
    },
    visible: { 
      opacity: 1, 
      y: 0,
      filter: "hue-rotate(0deg) brightness(1) contrast(1) drop-shadow(0 0 0px rgba(0,0,0,0))",
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15,
      },
    },
  };

  useEffect(() => {
    fetchMemories();
  }, []);

  const handleAddMemory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newContent.trim() === "") return;
    await addMemory(newContent, selectedCategory);
    setNewContent("");
  };

  const filteredMemories = memories.filter((m) =>
    m.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const stats = {
    total: memories.length,
    pinned: memories.filter((m) => m.pinned).length,
    armor: memories.filter((m) => m.category === "Armor Core" || m.category === "Core Systems").length,
    security: memories.filter((m) => m.category === "Security").length,
    personal: memories.filter((m) => m.category === "Personal" || m.category === "General").length,
  };

  return (
    <div className="relative overflow-hidden w-full h-full rounded-2xl p-0.5">
      {/* Holographic Scanline Animations */}
      <div className="holographic-grid-overlay rounded-2xl" />
      <div className="holographic-sweep" />

      <motion.div
        id="jarvis_memory_tab"
        initial="hidden"
        animate="visible"
        variants={holographicContainerVariants}
        className="grid grid-cols-1 lg:grid-cols-4 gap-4 overflow-visible lg:overflow-hidden h-auto lg:h-[550px] xl:h-full relative z-10"
      >
        {/* Side Stats & Quick Creation Panel */}
        <motion.div
          variants={holographicSectionVariants}
          className="lg:col-span-1 flex flex-col gap-4 h-auto lg:h-full overflow-y-auto lg:overflow-hidden"
        >
        {/* Memory Stats Block */}
        <div className="glassmorphism rounded-xl border border-cyan-500/20 p-4">
          <div className="flex items-center gap-2 mb-3">
            <Database className="w-4 h-4 text-cyan-400" />
            <h3 className="font-display font-medium text-sm text-slate-200 uppercase tracking-widest">Memory Metrics</h3>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-950/60 p-3 rounded-lg border border-cyan-500/10 text-center">
              <div className="text-xl font-display font-bold text-cyan-400">{stats.total}</div>
              <div className="text-[9px] font-mono text-slate-500 uppercase tracking-wider">Total Records</div>
            </div>
            <div className="bg-slate-950/60 p-3 rounded-lg border border-cyan-500/10 text-center">
              <div className="text-xl font-display font-bold text-purple-400">{stats.pinned}</div>
              <div className="text-[9px] font-mono text-slate-500 uppercase tracking-wider">Pinned Core</div>
            </div>
            <div className="bg-slate-950/60 p-2 rounded-lg border border-cyan-500/5 text-center">
              <div className="text-xs font-semibold text-slate-300">{stats.armor}</div>
              <div className="text-[8px] font-mono text-slate-500 uppercase tracking-wider">Armor Systems</div>
            </div>
            <div className="bg-slate-950/60 p-2 rounded-lg border border-cyan-500/5 text-center">
              <div className="text-xs font-semibold text-slate-300">{stats.security}</div>
              <div className="text-[8px] font-mono text-slate-500 uppercase tracking-wider">Security Prot</div>
            </div>
          </div>
        </div>

        {/* Quick Log Memory */}
        <div className="glassmorphism rounded-xl border border-cyan-500/20 p-4 flex-1 overflow-hidden flex flex-col">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <h3 className="font-display font-medium text-sm text-slate-200 uppercase tracking-widest">Store Insight</h3>
          </div>
          
          <form onSubmit={handleAddMemory} className="flex-1 flex flex-col gap-3">
            <div>
              <label className="block text-[9px] font-mono text-cyan-400/70 uppercase tracking-widest mb-1.5">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full bg-slate-950/80 border border-cyan-500/20 rounded-lg px-2.5 py-1.5 font-sans text-xs text-slate-200 focus:outline-none focus:border-cyan-400"
              >
                <option value="Armor Core">Armor Core</option>
                <option value="Security">Security Protocol</option>
                <option value="Physics">Physics Research</option>
                <option value="Personal">Personal Insights</option>
              </select>
            </div>

            <div className="flex-1 flex flex-col min-h-[100px]">
              <label className="block text-[9px] font-mono text-cyan-400/70 uppercase tracking-widest mb-1.5">Insight Details</label>
              <textarea
                placeholder="Write custom data for JARVIS long-term retrieval systems..."
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                className="flex-1 w-full bg-slate-950/80 border border-cyan-500/20 rounded-lg p-2.5 font-sans text-xs text-slate-200 placeholder-cyan-500/30 focus:outline-none focus:border-cyan-400 resize-none scrollbar-thin"
              />
            </div>

            <button
              type="submit"
              disabled={newContent.trim() === ""}
              className="w-full py-2 border border-cyan-400 bg-cyan-950/10 hover:bg-cyan-500 hover:text-slate-950 text-cyan-400 font-bold font-display text-xs rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:hover:bg-cyan-950/10 disabled:hover:text-cyan-400"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>RECORD MEMORY</span>
            </button>
          </form>
        </div>
        </motion.div>

        {/* Main Memory Records Board & Activity History vertical stack */}
        <motion.div
          variants={holographicSectionVariants}
          className="lg:col-span-3 flex flex-col gap-4 h-full overflow-hidden"
        >
        
        {/* Memory Records List card */}
        <div className="flex-1 flex flex-col glassmorphism rounded-xl border border-cyan-500/20 p-4 overflow-hidden min-h-[250px]">
          {/* Search bar and title */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-cyan-400 animate-pulse" />
              <div>
                <h2 className="font-display text-sm font-semibold text-slate-100 tracking-wider uppercase">Long-Term Memory Vault</h2>
                <p className="text-[10px] text-slate-500 font-mono">JARVIS CLOUD STORAGE SECURED MATRIX</p>
              </div>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-cyan-500/50" />
              <input
                type="text"
                placeholder="Filter memories..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950/80 border border-cyan-500/20 rounded-lg pl-9 pr-3 py-1.5 font-sans text-xs text-slate-200 placeholder-cyan-500/40 focus:outline-none focus:border-cyan-400 transition-colors"
              />
            </div>
          </div>

          {/* Memories Display Timeline */}
          <div className="flex-1 overflow-y-auto pr-1 space-y-3.5 scrollbar-thin">
            {memoriesLoading ? (
              <div className="flex items-center justify-center py-16 font-mono text-xs text-cyan-400 animate-pulse">
                RETRIEVING MEMORY REGISTERS...
              </div>
            ) : filteredMemories.length === 0 ? (
              <div className="text-center py-16 text-slate-500 font-mono text-xs">
                No telemetry or memories match search filters.
              </div>
            ) : (
              filteredMemories.map((m) => (
                <div
                  key={m.id}
                  className={`relative p-4 rounded-xl border transition-all ${
                    m.pinned
                      ? "bg-purple-950/10 border-purple-500/40 shadow-md shadow-purple-950/30"
                      : "bg-slate-950/50 border-cyan-500/10 hover:border-cyan-500/30"
                  }`}
                >
                  {/* Categorization & timeline dates */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className={`text-[9px] font-mono px-2 py-0.5 rounded uppercase tracking-widest ${
                        m.category === "Security"
                          ? "bg-red-500/10 text-red-400 border border-red-500/20"
                          : (m.category === "Core Systems" || m.category === "Armor Core")
                          ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20"
                          : m.category === "Physics"
                          ? "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                          : "bg-purple-500/10 text-purple-400 border border-purple-500/20"
                      }`}>
                        {m.category}
                      </span>
                      <span className="flex items-center gap-1 text-[9px] font-mono text-slate-500">
                        <Calendar className="w-3 h-3" />
                        {new Date(m.date).toLocaleDateString([], { year: "numeric", month: "short", day: "2-digit" })}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => togglePinMemory(m.id)}
                        className={`p-1 rounded hover:bg-slate-900 transition-colors cursor-pointer ${
                          m.pinned ? "text-purple-400" : "text-slate-500 hover:text-slate-300"
                        }`}
                        title={m.pinned ? "Unpin record" : "Pin record to core"}
                      >
                        <Pin className="w-3.5 h-3.5 fill-current" />
                      </button>
                      <button
                        onClick={() => deleteMemory(m.id)}
                        className="p-1 rounded hover:bg-red-950/30 text-slate-500 hover:text-red-400 transition-colors cursor-pointer"
                        title="Erase memory file"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Content */}
                  <p className="text-xs text-slate-200 leading-relaxed pl-1 font-sans">
                    {m.content}
                  </p>

                  {/* Cyber HUD elements */}
                  <div className="absolute right-3 bottom-1.5 opacity-10 pointer-events-none select-none font-mono text-[8px] text-cyan-400">
                    SECTOR_INDEX_{m.id.toUpperCase()}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Daily System Interactions Activity History Bar Chart */}
        <div className="h-[210px] flex flex-col glassmorphism rounded-xl border border-cyan-500/20 p-4 shrink-0 overflow-hidden relative">
          <div className="flex items-center justify-between mb-3 shrink-0">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
              <h3 className="font-display font-medium text-xs text-slate-200 uppercase tracking-widest">Daily System Interactions History</h3>
            </div>
            <div className="flex items-center gap-4 text-[9px] font-mono text-slate-500">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 bg-cyan-500/30 border border-cyan-400/50 rounded-sm"></span>
                <span>Interactions</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 bg-purple-500/30 border border-purple-400/50 rounded-sm"></span>
                <span>Sub-tasks</span>
              </span>
            </div>
          </div>

          <div className="flex-1 w-full min-h-0 text-[9px] font-mono">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
                <defs>
                  <linearGradient id="interactionsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#06b6d4" stopOpacity={0.8} />
                    <stop offset="100%" stopColor="#06b6d4" stopOpacity={0.15} />
                  </linearGradient>
                  <linearGradient id="tasksGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#a855f7" stopOpacity={0.8} />
                    <stop offset="100%" stopColor="#a855f7" stopOpacity={0.15} />
                  </linearGradient>
                </defs>
                <XAxis 
                  dataKey="name" 
                  stroke="#475569" 
                  tickLine={false} 
                  axisLine={{ stroke: '#1e293b' }}
                  tick={{ fill: '#94a3b8', fontSize: 9 }}
                />
                <YAxis 
                  stroke="#475569" 
                  tickLine={false} 
                  axisLine={{ stroke: '#1e293b' }}
                  tick={{ fill: '#94a3b8', fontSize: 9 }}
                />
                <Tooltip
                  cursor={{ fill: 'rgba(6, 182, 212, 0.05)' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-slate-950/95 border border-cyan-500/35 p-2.5 rounded-lg shadow-[0_0_15px_rgba(6,182,212,0.15)] backdrop-blur-md z-50">
                          <p className="text-[10px] font-bold text-cyan-400 mb-1">{payload[0].payload.name}</p>
                          <div className="space-y-1 text-[9px] text-slate-300">
                            <div className="flex justify-between gap-4">
                              <span>Interactions:</span>
                              <span className="font-bold text-cyan-400">{payload[0].value}</span>
                            </div>
                            {payload[1] && (
                              <div className="flex justify-between gap-4">
                                <span>Sub-tasks Run:</span>
                                <span className="font-bold text-purple-400">{payload[1].value}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="Interactions" fill="url(#interactionsGrad)" stroke="#06b6d4" strokeWidth={1} radius={[2, 2, 0, 0]} />
                <Bar dataKey="Tasks" fill="url(#tasksGrad)" stroke="#a855f7" strokeWidth={1} radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </motion.div>
    </motion.div>
    </div>
  );
}
