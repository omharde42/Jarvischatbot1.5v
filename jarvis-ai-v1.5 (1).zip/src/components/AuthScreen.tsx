import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ShieldCheck, 
  Lock, 
  Mail, 
  User, 
  ArrowRight, 
  Cpu, 
  ChevronRight, 
  Globe, 
  Zap,
  Info,
  AlertCircle,
  CheckCircle,
  Eye,
  EyeOff,
  Database
} from "lucide-react";
import { useFirebaseAuth } from "../hooks/useFirebaseAuth";

interface AuthScreenProps {
  onLoginSuccess: (user: any) => void;
  onBackToLanding?: () => void;
}

const COUNTRIES = [
  { name: "United States", code: "+1", flag: "🇺🇸" },
  { name: "India", code: "+91", flag: "🇮🇳" },
  { name: "Canada", code: "+1", flag: "🇨🇦" },
  { name: "United Kingdom", code: "+44", flag: "🇬🇧" },
  { name: "Australia", code: "+61", flag: "🇦🇺" },
  { name: "Singapore", code: "+65", flag: "🇸🇬" },
  { name: "Germany", code: "+49", flag: "🇩🇪" },
  { name: "France", code: "+33", flag: "🇫🇷" },
  { name: "Japan", code: "+81", flag: "🇯🇵" },
  { name: "Brazil", code: "+55", flag: "🇧🇷" },
  { name: "South Africa", code: "+27", flag: "🇿🇦" },
  { name: "UAE", code: "+971", flag: "🇦🇪" }
];

export default function AuthScreen({ onLoginSuccess, onBackToLanding }: AuthScreenProps) {
  const { 
    isLoading, 
    error: authError, 
    loginWithGoogle, 
    loginWithEmail, 
    signupWithEmail 
  } = useFirebaseAuth();

  const [view, setView] = useState<"intro" | "login" | "signup" | "success">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [phoneCode, setPhoneCode] = useState("+1");
  const [phoneNo, setPhoneNo] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Sync hook errors with local display error if any
  useEffect(() => {
    if (authError) {
      setError(authError);
    }
  }, [authError]);

  // International phone input state
  const [isCountryDropdownOpen, setIsCountryDropdownOpen] = useState(false);
  const [countrySearch, setCountrySearch] = useState("");

  const selectedCountry = COUNTRIES.find(c => c.code === phoneCode) || COUNTRIES[0];
  const filteredCountries = COUNTRIES.filter(c => 
    c.name.toLowerCase().includes(countrySearch.toLowerCase()) || 
    c.code.includes(countrySearch)
  );

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!email.trim() || !password.trim()) {
      setError("Please input complete identity parameters.");
      return;
    }

    try {
      const response = await loginWithEmail({ email, password });
      if (response && response.success && response.user) {
        onLoginSuccess(response.user);
      }
    } catch (err: any) {
      setError(err?.message || "Authentication credentials denied.");
    }
  };

  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!name.trim() || !email.trim() || !phoneNo.trim() || !password.trim()) {
      setError("All credentials must be declared, Sir.");
      return;
    }

    const cleanedPhone = phoneNo.replace(/\D/g, "");
    if (cleanedPhone.length < 8) {
      setError("Contact configuration failed. Please insert a valid number configuration.");
      return;
    }

    if (password.length < 6) {
      setError("Password length must be 6 or more characters for security protocol.");
      return;
    }

    try {
      const response = await signupWithEmail({
        name,
        email,
        phoneCode,
        phoneNo: cleanedPhone,
        password
      });

      if (response && response.success) {
        setSuccessMsg("Biometric signature logged successfully.");
        setView("success");
        setName("");
        setPhoneNo("");
      }
    } catch (err: any) {
      setError(err?.message || "Biometric credential registration failed.");
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    try {
      const response = await loginWithGoogle();
      if (response && response.success && response.user) {
        onLoginSuccess(response.user);
      }
    } catch (err: any) {
      // Handled in hook but captured here
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center relative p-4 overflow-hidden select-none font-mono">
      {/* HUD futuristic grid background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-30" />
      
      {/* Interactive overlay glow ambient circles */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[128px] animate-pulse pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-[128px] animate-pulse pointer-events-none" style={{ animationDelay: "2s" }} />

      <div className="w-full max-w-md bg-slate-950/80 backdrop-blur-xl border border-cyan-500/20 rounded-2xl shadow-2xl p-6 md:p-8 z-10 relative overflow-hidden">
        {/* Subtle decorative cyber corner notches */}
        <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cyan-400" />
        <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyan-400" />
        <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-cyan-400" />
        <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-cyan-400" />

        <AnimatePresence mode="wait">
          {view === "intro" && (
            <motion.div
              key="intro"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="flex flex-col items-center text-center space-y-6"
            >
              {/* Pulsing ARC Core Reactor Visual */}
              <div className="relative w-32 h-32 flex items-center justify-center">
                <div className="absolute inset-0 rounded-full border-4 border-dashed border-cyan-500/20 animate-[spin_40s_linear_infinite]" />
                <div className="absolute inset-2 rounded-full border border-double border-cyan-400/40 animate-[spin_20s_linear_infinite_reverse]" />
                <div className="absolute inset-4 rounded-full bg-cyan-500/5 border border-cyan-500/30 flex items-center justify-center shadow-[0_0_20px_rgba(34,211,238,0.15)]">
                  <Cpu className="w-10 h-10 text-cyan-400 animate-pulse" />
                </div>
                <div className="absolute -top-1 w-2 h-2 bg-cyan-400 rounded-full shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
                <div className="absolute -bottom-1 w-2 h-2 bg-cyan-400 rounded-full shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
              </div>

              <div className="space-y-2">
                <div className="text-2xl font-bold tracking-[0.25em] text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-cyan-200">
                  JARVIS AI
                </div>
                <div className="text-[9px] uppercase tracking-widest text-slate-500 flex items-center justify-center gap-1.5">
                  <ShieldCheck className="w-3 h-3 text-cyan-500" />
                  COGNITIVE DIRECTIVE SECURE v1.60
                </div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed max-w-sm px-2 font-sans">
                A high-fidelity machine interface engineered to coordinate system operations, real-time verbal interactions, and secure cloud synchronization.
              </p>

              <div className="w-full space-y-3 pt-4 font-mono">
                <button
                  id="btn-protocol-login"
                  onClick={() => { setError(null); setView("login"); }}
                  className="w-full py-2.5 px-4 bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/30 hover:border-cyan-400/60 rounded-lg text-xs font-semibold tracking-wider text-cyan-400 hover:text-cyan-300 transition-all duration-300 flex items-center justify-center gap-2 group cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.05)]"
                >
                  INITIATE SYSTEM PORTAL
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>

                <button
                  id="btn-protocol-signup"
                  onClick={() => { setError(null); setView("signup"); }}
                  className="w-full py-2.5 px-4 bg-slate-900/50 hover:bg-slate-800/60 border border-slate-800 hover:border-cyan-500/20 rounded-lg text-xs tracking-wider text-slate-400 hover:text-slate-200 transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
                >
                  REGISTER SECURE CREDENTIALS
                  <ChevronRight className="w-4 h-4 text-slate-500" />
                </button>
              </div>

              <div className="flex items-center justify-between w-full text-[9px] text-slate-600 border-t border-slate-900 pt-4 font-mono">
                <span className="flex items-center gap-1">
                  <Globe className="w-2.5 h-2.5 text-cyan-500/50" />
                  JARVIS SECURE NODE
                </span>
                <span className="flex items-center gap-1">
                  <Zap className="w-2.5 h-2.5 text-yellow-500/50 animate-pulse" />
                  ARC REACTOR: STABLE
                </span>
              </div>
            </motion.div>
          )}

          {view === "login" && (
            <motion.div
              key="login"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex flex-col items-center text-center space-y-1">
                <ShieldCheck className="w-8 h-8 text-cyan-400 animate-pulse" />
                <h2 className="text-lg font-bold tracking-widest text-slate-200 uppercase">ACCESS PROTOCOL</h2>
                <p className="text-[10px] text-slate-500 uppercase tracking-wider font-sans">Firebase Cloud Handshake Active</p>
              </div>

              {/* Firebase Firestore Cloud Connected Notice */}
              <div className="p-3 rounded-lg border text-xs bg-cyan-950/20 border-cyan-500/30 text-cyan-400">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    <span className="font-semibold uppercase tracking-wider text-[10px]">
                      Firestore Cloud Online
                    </span>
                  </div>
                  <span className="flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 bg-cyan-400"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
                  </span>
                </div>
                <p className="mt-1.5 text-[9px] text-slate-400 font-sans leading-relaxed">
                  All conversational intelligence records, memories, and task schedules are securely isolated and persisted in Firestore.
                </p>
              </div>

              {error && (
                <div className="p-3 bg-rose-950/20 border border-rose-500/30 text-rose-400 rounded-lg text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span className="font-sans leading-relaxed text-[11px]">{error}</span>
                </div>
              )}

              {/* Standard login form */}
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-500 uppercase tracking-wider block">IDENTITY EMAIL</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 w-4 h-4 text-cyan-500/50" />
                    <input
                      id="input-login-email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="user@jarvis.ai"
                      className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-cyan-500/10 focus:border-cyan-400 rounded-lg text-xs text-slate-200 placeholder-slate-700 outline-none transition-all duration-200"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-500 uppercase tracking-wider block">SECURITY PHRASE</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 w-4 h-4 text-cyan-500/50" />
                    <input
                      id="input-login-password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-10 py-2 bg-slate-950 border border-cyan-500/10 focus:border-cyan-400 rounded-lg text-xs text-slate-200 placeholder-slate-700 outline-none transition-all duration-200"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-slate-600 hover:text-cyan-400"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  id="btn-login-submit"
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/30 hover:border-cyan-400/60 rounded-lg text-xs font-semibold tracking-wider text-cyan-400 hover:text-cyan-300 transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isLoading ? "ESTABLISHING SECURITY PORT..." : "VERIFY CRYPTO-KEY COORDINATES"}
                </button>
              </form>

              {/* Premium Google Sign-In Trigger */}
              <div className="relative flex py-1 items-center">
                <div className="flex-grow border-t border-slate-900"></div>
                <span className="flex-shrink mx-4 text-slate-600 text-[9px] uppercase tracking-widest">or link neural grid</span>
                <div className="flex-grow border-t border-slate-900"></div>
              </div>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-cyan-500/30 rounded-lg text-xs font-semibold tracking-wider text-slate-300 hover:text-cyan-400 transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <svg className="w-4 h-4 text-cyan-400" viewBox="0 0 24 24">
                    <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  BIOMETRIC SIGN-IN via GOOGLE
                </button>
                <p className="text-[8px] text-center text-slate-600 uppercase tracking-wide leading-relaxed font-sans">
                  * Note: Google popup sandboxed inside iframe preview? Please select "Open in New Tab" at top-right for flawless authentication.
                </p>
              </div>

              <div className="flex flex-col items-center gap-2 border-t border-slate-900 pt-4 text-[10px]">
                <button
                  onClick={() => { setError(null); setView("signup"); }}
                  className="text-cyan-500 hover:text-cyan-400 cursor-pointer"
                >
                  Create new biometric signature registry
                </button>
                <button
                  onClick={() => { setError(null); if (onBackToLanding) { onBackToLanding(); } else { setView("intro"); } }}
                  className="text-slate-600 hover:text-slate-400 cursor-pointer"
                >
                  Back to mainframe console
                </button>
              </div>
            </motion.div>
          )}

          {view === "signup" && (
            <motion.div
              key="signup"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex flex-col items-center text-center space-y-1">
                <Cpu className="w-8 h-8 text-cyan-400 animate-bounce" />
                <h2 className="text-lg font-bold tracking-widest text-slate-200 uppercase">BIOMETRIC REGISTRY</h2>
                <p className="text-[10px] text-slate-500 uppercase tracking-wider font-sans">Register secure cloud coordinates</p>
              </div>

              {error && (
                <div className="p-3 bg-rose-950/20 border border-rose-500/30 text-rose-400 rounded-lg text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span className="font-sans leading-relaxed text-[11px]">{error}</span>
                </div>
              )}

              <form onSubmit={handleSignupSubmit} className="space-y-3.5">
                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 uppercase tracking-wider block">PILOT DESIGNATION</label>
                  <div className="relative">
                    <User className="absolute left-3 top-2.5 w-4 h-4 text-cyan-500/50" />
                    <input
                      id="input-signup-name"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Jarvis Pilot"
                      className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-cyan-500/10 focus:border-cyan-400 rounded-lg text-xs text-slate-200 placeholder-slate-700 outline-none transition-all duration-200"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 uppercase tracking-wider block">SECURE DIRECT EMAIL</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 w-4 h-4 text-cyan-500/50" />
                    <input
                      id="input-signup-email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="user@jarvis.ai"
                      className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-cyan-500/10 focus:border-cyan-400 rounded-lg text-xs text-slate-200 placeholder-slate-700 outline-none transition-all duration-200"
                    />
                  </div>
                </div>

                <div className="space-y-1 relative">
                  <label className="text-[10px] text-slate-500 uppercase tracking-wider block">CONTACT MATRIX (PHONE)</label>
                  
                  {isCountryDropdownOpen && (
                    <div 
                      className="fixed inset-0 z-40 cursor-default" 
                      onClick={() => {
                        setIsCountryDropdownOpen(false);
                        setCountrySearch("");
                      }} 
                    />
                  )}

                  <div className="relative flex items-center bg-slate-950 border border-cyan-500/10 focus-within:border-cyan-400 rounded-lg transition-all duration-200 z-50">
                    <div className="relative flex items-center shrink-0">
                      <button
                        id="btn-country-selector"
                        type="button"
                        onClick={() => setIsCountryDropdownOpen(!isCountryDropdownOpen)}
                        className="flex items-center gap-1 px-2.5 py-2 border-r border-cyan-500/10 hover:bg-cyan-950/20 text-xs text-slate-200 focus:outline-none transition-colors"
                      >
                        <span className="text-base select-none leading-none mt-0.5">{selectedCountry.flag}</span>
                        <span className="text-slate-400 font-bold text-[10px] leading-none">{selectedCountry.code}</span>
                        <span className="text-[7px] text-slate-600 scale-75">▼</span>
                      </button>

                      {isCountryDropdownOpen && (
                        <div className="absolute top-full left-0 mt-1 w-64 max-h-60 overflow-y-auto bg-slate-950/95 border border-cyan-500/30 rounded-lg shadow-2xl z-50 backdrop-blur-md font-mono">
                          <div className="p-2 border-b border-cyan-500/15 sticky top-0 bg-slate-950/95 z-10">
                            <input
                              type="text"
                              value={countrySearch}
                              onChange={(e) => setCountrySearch(e.target.value)}
                              placeholder="Search country..."
                              className="w-full px-2 py-1.5 bg-slate-900 border border-cyan-500/10 focus:border-cyan-400 rounded text-[10px] text-slate-200 placeholder-slate-600 outline-none"
                              onClick={(e) => e.stopPropagation()}
                            />
                          </div>
                          
                          <div className="py-1">
                            {filteredCountries.map((c) => (
                              <button
                                key={c.name + c.code}
                                type="button"
                                onClick={() => {
                                  setPhoneCode(c.code);
                                  setIsCountryDropdownOpen(false);
                                  setCountrySearch("");
                                }}
                                className={`w-full text-left px-3 py-1.5 hover:bg-cyan-950/40 text-xs flex items-center justify-between transition-colors ${
                                  phoneCode === c.code ? "bg-cyan-500/10 text-cyan-400" : "text-slate-300"
                                }`}
                              >
                                <span className="flex items-center gap-2">
                                  <span className="text-base select-none">{c.flag}</span>
                                  <span className="truncate max-w-[120px]">{c.name}</span>
                                </span>
                                <span className="text-slate-500 font-bold text-[10px]">{c.code}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="relative flex-1">
                      <input
                        id="input-signup-phone"
                        type="text"
                        value={phoneNo}
                        onChange={(e) => {
                          const val = e.target.value;
                          const clean = val.replace(/\D/g, "").slice(0, 10);
                          const formatted = clean.length <= 5 ? clean : `${clean.slice(0, 5)} ${clean.slice(5)}`;
                          setPhoneNo(formatted);
                        }}
                        placeholder="98765 43210"
                        className="w-full pl-3 pr-8 py-2 bg-transparent text-xs text-slate-200 placeholder-slate-700 outline-none font-mono"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 uppercase tracking-wider block">ENCRYPTION PIN/PASS</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 w-4 h-4 text-cyan-500/50" />
                    <input
                      id="input-signup-password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Minimum 6 characters"
                      className="w-full pl-9 pr-10 py-2 bg-slate-950 border border-cyan-500/10 focus:border-cyan-400 rounded-lg text-xs text-slate-200 placeholder-slate-700 outline-none transition-all duration-200"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-slate-600 hover:text-cyan-400"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  id="btn-signup-submit"
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/30 hover:border-cyan-400/60 rounded-lg text-xs font-semibold tracking-wider text-cyan-400 hover:text-cyan-300 transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer pt-2"
                >
                  {isLoading ? "REGISTRATION ACTIVE..." : "REGISTER CLOUD SYSTEM PROTOCOL"}
                </button>
              </form>

              <div className="flex flex-col items-center gap-2 border-t border-slate-900 pt-4 text-[10px]">
                <button
                  onClick={() => { setError(null); setView("login"); }}
                  className="text-cyan-500 hover:text-cyan-400 cursor-pointer"
                >
                  Have secure access codes? Sign In
                </button>
                <button
                  onClick={() => { setError(null); if (onBackToLanding) { onBackToLanding(); } else { setView("intro"); } }}
                  className="text-slate-600 hover:text-slate-400 cursor-pointer"
                >
                  Cancel system registration
                </button>
              </div>
            </motion.div>
          )}

          {view === "success" && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex flex-col items-center text-center space-y-6 py-4"
            >
              <div className="w-16 h-16 bg-cyan-500/10 border border-cyan-500/30 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(34,211,238,0.2)]">
                <CheckCircle className="w-8 h-8 text-cyan-400 animate-pulse" />
              </div>

              <div className="space-y-1.5">
                <h2 className="text-md font-bold tracking-widest text-cyan-400 uppercase">BIOMETRIC LOG RECORDED</h2>
                <p className="text-[10px] text-slate-500 uppercase tracking-widest">Protocol Sync: 100% Complete</p>
              </div>

              <div className="bg-slate-950 border border-cyan-500/5 p-4 rounded-xl space-y-2.5 text-left text-[11px] leading-relaxed text-slate-400 font-sans">
                <div className="flex items-center gap-2 text-cyan-500 font-semibold mb-1">
                  <Info className="w-4 h-4 shrink-0" />
                  <span>DECRYPTION REQUIRED</span>
                </div>
                Sir, your identity signature has been successfully cataloged inside our decentralized Jarvis-mainframe database. Under safety protocol, we must now ask you to verify your registered security credentials on the login screen.
              </div>

              <button
                id="btn-success-proceed"
                onClick={() => {
                  setError(null);
                  setView("login");
                }}
                className="w-full py-2.5 px-4 bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/30 hover:border-cyan-400/60 rounded-lg text-xs font-semibold tracking-wider text-cyan-400 hover:text-cyan-300 transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.1)]"
              >
                PROCEED TO SIGN-IN MATRIX
                <ArrowRight className="w-4 h-4" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
