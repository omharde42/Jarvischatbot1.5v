/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";

interface MarkdownRendererProps {
  content: string;
}

export default function MarkdownRenderer({ content }: MarkdownRendererProps) {
  const lines = content.split("\n");
  
  return (
    <div className="space-y-4 text-xs font-mono text-slate-300 leading-relaxed">
      {lines.map((line, idx) => {
        const trimmed = line.trim();
        
        if (trimmed === "" || trimmed === "---") {
          if (trimmed === "---") {
            return <hr key={idx} className="border-cyan-500/10 my-4" />;
          }
          return <div key={idx} className="h-1" />;
        }

        // Headers
        if (trimmed.startsWith("# ")) {
          return (
            <h1 key={idx} className="text-sm font-display font-black text-cyan-400 tracking-wider uppercase border-b border-cyan-500/20 pb-1.5 mb-4 mt-6 flex items-center gap-2">
              <span className="w-1.5 h-3.5 bg-cyan-400 inline-block animate-pulse shadow-[0_0_8px_#22d3ee]"></span>
              {trimmed.substring(2)}
            </h1>
          );
        }
        
        if (trimmed.startsWith("## ")) {
          return (
            <h2 key={idx} className="text-[11px] font-display font-bold text-purple-400 tracking-widest uppercase mt-6 mb-3 flex items-center gap-1.5">
              <span className="text-purple-500 font-black">//</span> {trimmed.substring(3)}
            </h2>
          );
        }

        if (trimmed.startsWith("### ")) {
          return (
            <h3 key={idx} className="text-[10px] font-display font-semibold text-slate-200 uppercase tracking-wider mt-4 mb-2">
              {trimmed.substring(4)}
            </h3>
          );
        }

        // Bullet point checklists / standard checklists
        if (trimmed.startsWith("- [✓]") || trimmed.startsWith("- [x]") || trimmed.startsWith("- [ ]") || trimmed.startsWith("- [checked]")) {
          const isChecked = trimmed.startsWith("- [✓]") || trimmed.startsWith("- [x]") || trimmed.includes("[checked]") || trimmed.includes("[x]");
          const cleanText = trimmed.replace(/^-\s*\[(?:✓|x| )\]\s*/, "").replace(/^-\s*\[checked\]\s*/, "");
          return (
            <div key={idx} className="flex items-start gap-2.5 pl-2 py-0.5 animate-in fade-in slide-in-from-left-2 duration-150">
              <span className={`flex-shrink-0 w-3.5 h-3.5 rounded border flex items-center justify-center text-[8px] font-bold ${
                isChecked 
                  ? "bg-emerald-950/35 border-emerald-500/50 text-emerald-400 shadow-[0_0_6px_rgba(16,185,129,0.2)]" 
                  : "bg-slate-950/50 border-cyan-500/20 text-slate-600"
              }`}>
                {isChecked ? "✓" : " "}
              </span>
              <span className={isChecked ? "text-slate-200" : "text-slate-400"}>
                {parseInlineFormatting(cleanText)}
              </span>
            </div>
          );
        }

        if (trimmed.startsWith("- ")) {
          const text = trimmed.substring(2);
          return (
            <div key={idx} className="flex items-start gap-2 pl-2">
              <span className="text-cyan-500 font-extrabold mr-1">•</span>
              <span>{parseInlineFormatting(text)}</span>
            </div>
          );
        }

        if (trimmed.match(/^\d+\.\s/)) {
          const dotIndex = trimmed.indexOf(". ");
          const num = trimmed.substring(0, dotIndex + 1);
          const text = trimmed.substring(dotIndex + 2);
          return (
            <div key={idx} className="flex items-start gap-2 pl-2 border-l border-cyan-500/10 py-1 bg-slate-950/15 rounded-r">
              <span className="text-cyan-400 font-extrabold font-mono pl-1.5">{num}</span>
              <span className="flex-1">{parseInlineFormatting(text)}</span>
            </div>
          );
        }

        // Standard paragraph
        return (
          <p key={idx} className="leading-relaxed">
            {parseInlineFormatting(line)}
          </p>
        );
      })}
    </div>
  );
}

// Simple inline parser for **bold** and `code` tags
function parseInlineFormatting(text: string): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  let currentText = text;
  let keyIdx = 0;

  while (currentText.length > 0) {
    const boldStart = currentText.indexOf("**");
    const codeStart = currentText.indexOf("`");

    // No bold or code remaining
    if (boldStart === -1 && codeStart === -1) {
      parts.push(<span key={keyIdx++}>{currentText}</span>);
      break;
    }

    // Determine which comes first
    const isBoldFirst = boldStart !== -1 && (codeStart === -1 || boldStart < codeStart);

    if (isBoldFirst) {
      // Add plain text before bold
      if (boldStart > 0) {
        parts.push(<span key={keyIdx++}>{currentText.substring(0, boldStart)}</span>);
      }
      const boldEnd = currentText.indexOf("**", boldStart + 2);
      if (boldEnd !== -1) {
        const boldText = currentText.substring(boldStart + 2, boldEnd);
        parts.push(
          <strong key={keyIdx++} className="font-bold text-cyan-300 tracking-wide shadow-[0_0_4px_rgba(34,211,238,0.15)]">
            {boldText}
          </strong>
        );
        currentText = currentText.substring(boldEnd + 2);
      } else {
        parts.push(<span key={keyIdx++}>**</span>);
        currentText = currentText.substring(boldStart + 2);
      }
    } else {
      // Code is first
      if (codeStart > 0) {
        parts.push(<span key={keyIdx++}>{currentText.substring(0, codeStart)}</span>);
      }
      const codeEnd = currentText.indexOf("`", codeStart + 1);
      if (codeEnd !== -1) {
        const codeText = currentText.substring(codeStart + 1, codeEnd);
        parts.push(
          <code key={keyIdx++} className="bg-slate-950 px-1.5 py-0.5 rounded border border-cyan-500/15 text-cyan-400 font-mono text-[10px]">
            {codeText}
          </code>
        );
        currentText = currentText.substring(codeEnd + 1);
      } else {
        parts.push(<span key={keyIdx++}>`</span>);
        currentText = currentText.substring(codeStart + 1);
      }
    }
  }

  return parts;
}
