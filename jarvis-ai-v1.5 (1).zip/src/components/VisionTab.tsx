/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { useJarvisStore } from "../stores/jarvisStore";
import { motion, AnimatePresence } from "motion/react";
import { 
  Camera, 
  Video, 
  VideoOff, 
  Sparkles, 
  Activity, 
  Eye, 
  ScanLine, 
  Cpu, 
  RotateCw, 
  Volume2, 
  Shield, 
  AlertTriangle,
  Lightbulb,
  Maximize2,
  Minimize2,
  Trash2
} from "lucide-react";

interface ObjectDetection {
  id: string;
  label: string;
  confidence: number;
  color: string;
  x: number; // css percentage
  y: number; // css percentage
  w: number; // css percentage
  h: number; // css percentage
}

export default function VisionTab() {
  const {
    capturedImage,
    setCapturedImage,
    analyzeCapturedImage,
    visionAnalysis,
    visionLoading,
    settings,
    speakText,
    addToast,
    addRecentActivity
  } = useJarvisStore();

  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [showMockBoxes, setShowMockBoxes] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  // Interactive HUD States
  const [luminosity, setLuminosity] = useState(240); // Lux
  const [motionRate, setMotionRate] = useState(2.4); // m/s²
  const [audioDecibels, setAudioDecibels] = useState(38); // dB
  const [sceneMode, setSceneMode] = useState<"study" | "dev" | "idle" | "empty">("dev");

  // Mock Dynamic Detections
  const [detections, setDetections] = useState<ObjectDetection[]>([
    { id: "det-1", label: "PRIMARY OPERATOR (USER)", confidence: 99.8, color: "border-cyan-400 text-cyan-400 bg-cyan-950/20", x: 25, y: 15, w: 45, h: 65 },
    { id: "det-2", label: "DEVELOPMENT MAINFRAME", confidence: 98.4, color: "border-purple-400 text-purple-400 bg-purple-950/20", x: 68, y: 35, w: 25, h: 45 },
    { id: "det-3", label: "HYDRATION CORE", confidence: 95.1, color: "border-amber-400 text-amber-400 bg-amber-950/20", x: 10, y: 65, w: 12, h: 20 }
  ]);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Theme support
  const resolvedMode = React.useMemo(() => {
    const m = settings?.appearance?.mode || "dark";
    if (m === "system") {
      if (typeof window !== "undefined" && window.matchMedia) {
        return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      }
      return "dark";
    }
    return m;
  }, [settings?.appearance?.mode]);

  const isLight = resolvedMode === "light";

  // Simulate box floating movement to look like organic computer vision tracking
  useEffect(() => {
    if (!cameraActive) return;

    const interval = setInterval(() => {
      setDetections(prev => 
        prev.map(det => {
          // Add micro drift to coordinates
          const driftX = (Math.random() - 0.5) * 1.5;
          const driftY = (Math.random() - 0.5) * 1.5;
          const driftConf = (Math.random() - 0.5) * 0.4;
          
          let newX = Math.max(5, Math.min(85, det.x + driftX));
          let newY = Math.max(5, Math.min(80, det.y + driftY));
          let newConf = Math.max(90, Math.min(99.9, det.confidence + driftConf));

          return {
            ...det,
            x: parseFloat(newX.toFixed(2)),
            y: parseFloat(newY.toFixed(2)),
            confidence: parseFloat(newConf.toFixed(1))
          };
        })
      );

      // Fluctuate environment telemetry slightly
      setLuminosity(prev => Math.max(120, Math.min(450, prev + Math.floor((Math.random() - 0.5) * 20))));
      setMotionRate(prev => Math.max(0.1, Math.min(12.0, parseFloat((prev + (Math.random() - 0.5) * 0.6).toFixed(1)))));
      setAudioDecibels(prev => Math.max(20, Math.min(85, prev + Math.floor((Math.random() - 0.5) * 6))));
    }, 1500);

    return () => clearInterval(interval);
  }, [cameraActive]);

  // Voice notifications triggered by Interactive Vision Assistant buttons
  const playAssistantSpeech = (text: string, title: string) => {
    addToast(`[Vision Intel] ${title}`, "info");
    speakText(text);
    addRecentActivity(`Vision Assistant: ${title}`, "system_event", `JARVIS Vocalized diagnostic: "${text}"`);
  };

  // Camera Lifecycle
  const startCamera = async () => {
    setCameraError(null);
    try {
      const constraints = {
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: "user"
        },
        audio: false
      };

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(mediaStream);
      setCameraActive(true);
      addToast("Optical sensors active. Calibrating HUD overlays.", "success");
      addRecentActivity("Camera Activated", "webcam_accessed", "Engaged primary webcam capture feed");

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.play().catch(err => console.error("Video play failed:", err));
      }
    } catch (err: any) {
      console.error("Camera access failed:", err);
      setCameraError(err?.message || "Permission denied or no camera device found.");
      addToast("Failed to initialize camera sensor.", "error");
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setCameraActive(false);
    addToast("Camera sensors set to standby.", "info");
  };

  // Cleanup camera stream on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  // Handle capture frame and send to Gemini Multi-modal API
  const captureFrameAndScan = async () => {
    if (!videoRef.current || !cameraActive) {
      addToast("Camera must be active to capture mainframe snapshot.", "warning");
      return;
    }

    try {
      const canvas = document.createElement("canvas");
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Could not construct 2D context.");

      // Mirror-flip if using front camera
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
      
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      
      const base64Data = canvas.toDataURL("image/jpeg");
      setCapturedImage(base64Data);
      
      addToast("Mainframe snapshot captured. Analyzing slices...", "info");
      
      // Trigger actual Gemini analysis with optimized operator prompt
      await analyzeCapturedImage("Analyze this environment image as JARVIS. Act as an operating system assistant. Scan the surroundings and describe what is visible: objects, people, lighting conditions, and potential developer tasks in progress, Sir. Be precise, polite, and British.");
    } catch (err: any) {
      console.error("Failed to capture video slice:", err);
      addToast("Visual capture pipeline failed.", "error");
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 h-full overflow-y-auto xl:overflow-hidden pb-10 xl:pb-0">
      
      {/* LEFT BLOCK: HOLOGRAPHIC CAMERA HUB (7 columns) */}
      <div className={`xl:col-span-7 flex flex-col gap-4 ${isFullscreen ? "fixed inset-0 z-50 p-4 bg-slate-950" : ""}`}>
        
        {/* Cam Frame Panel */}
        <div className={`relative flex-1 min-h-[300px] sm:min-h-[400px] md:min-h-[480px] border rounded-2xl overflow-hidden shadow-2xl transition-all duration-300 flex items-center justify-center ${
          isLight 
            ? "bg-slate-100 border-slate-300 shadow-slate-200/50" 
            : "bg-radial from-[#071328] to-[#03050a] border-cyan-500/20 shadow-cyan-950/20"
        }`}>
          {/* Cybernetic Micro-grid BG Overlay */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(18,100,150,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(18,100,150,0.05)_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

          {/* Futuristic Telemetry HUD Corners */}
          <div className="absolute top-3 left-3 w-5 h-5 border-t-2 border-l-2 border-cyan-400/60 rounded-tl-sm pointer-events-none" />
          <div className="absolute top-3 right-3 w-5 h-5 border-t-2 border-r-2 border-cyan-400/60 rounded-tr-sm pointer-events-none" />
          <div className="absolute bottom-3 left-3 w-5 h-5 border-b-2 border-l-2 border-cyan-400/60 rounded-bl-sm pointer-events-none" />
          <div className="absolute bottom-3 right-3 w-5 h-5 border-b-2 border-r-2 border-cyan-400/60 rounded-br-sm pointer-events-none" />

          {/* Absolute HUD Top Banner */}
          <div className="absolute top-3 left-1/2 transform -translate-x-1/2 px-3 py-1 bg-slate-900/80 border border-cyan-500/30 rounded-full flex items-center gap-2 z-20 shadow-lg backdrop-blur-md select-none">
            <ScanLine className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span className="text-[10px] font-mono text-cyan-400 tracking-widest font-bold">
              {cameraActive ? "OPTICAL_FEED: ONLINE" : "OPTICAL_FEED: STANDBY"}
            </span>
            {cameraActive && (
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
            )}
          </div>

          {/* ACTUAL VIDEO SENSOR FEED */}
          {cameraActive && (
            <div className="w-full h-full relative">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover rounded-2xl transform -scale-x-100"
              />

              {/* Holographic scanner laser line effect */}
              <div className="absolute inset-x-0 h-0.5 bg-cyan-400/50 shadow-[0_0_10px_rgba(34,211,238,0.7)] animate-laser-scan pointer-events-none z-10" />

              {/* HOLOGRAPHIC SCANNING OVERLAYS */}
              {showMockBoxes && (
                <div className="absolute inset-0 z-10 pointer-events-none">
                  {detections.map(det => (
                    <div
                      key={det.id}
                      style={{
                        left: `${det.x}%`,
                        top: `${det.y}%`,
                        width: `${det.w}%`,
                        height: `${det.h}%`
                      }}
                      className={`absolute border-2 rounded-lg transition-all duration-1000 flex flex-col justify-between p-1 shadow-md ${det.color}`}
                    >
                      {/* Sub-bounding indicator box brackets */}
                      <div className="text-[8px] font-mono font-black uppercase flex items-center justify-between px-1 bg-slate-900/90 py-0.5 rounded border border-current max-w-max">
                        <span>{det.label}</span>
                        <span className="ml-1.5 text-emerald-400">{det.confidence}%</span>
                      </div>
                      <div className="self-end text-[7px] font-mono text-current p-0.5 select-none">
                        LOC_COORD: [{det.x}, {det.y}]
                      </div>
                    </div>
                  ))}

                  {/* High-tech central scope reticle */}
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-28 h-28 border border-dashed border-cyan-400/20 rounded-full flex items-center justify-center animate-spin-slow">
                    <div className="w-20 h-20 border border-cyan-400/30 rounded-full flex items-center justify-center">
                      <div className="w-2 h-2 bg-red-500 rounded-full animate-ping" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* FAKE RADAR MATRIX (When Camera is Standby) */}
          {!cameraActive && (
            <div className="flex flex-col items-center justify-center p-6 text-center z-10 space-y-5 select-none w-full max-w-sm">
              <div className="relative w-44 h-44 rounded-full border border-cyan-500/20 flex items-center justify-center shadow-inner">
                {/* Micro rotating circles */}
                <div className="absolute inset-0 rounded-full border border-dashed border-cyan-500/20 animate-spin-slow" />
                <div className="absolute inset-4 rounded-full border border-double border-purple-500/20 animate-spin-reverse" />
                <div className="absolute inset-10 rounded-full border border-cyan-500/30 animate-pulse flex items-center justify-center">
                  <Eye className="w-10 h-10 text-cyan-400/40" />
                </div>
                {/* Scanning sweep radar hand */}
                <div className="absolute inset-0 rounded-full bg-conic-radar opacity-10 animate-radar-sweep" />
              </div>

              <div className="space-y-1.5">
                <h3 className="font-display font-bold text-sm text-slate-200 uppercase tracking-widest">
                  ENGAGE OPTICAL ARRAY
                </h3>
                <p className="text-[10px] font-mono text-slate-500 max-w-xs leading-relaxed">
                  Calibrate camera to deploy YOLO real-time computer vision matrices, spatial overlays, and face signature recognizers.
                </p>
              </div>

              {cameraError && (
                <div className="text-[10px] font-mono text-rose-400 bg-rose-950/20 border border-rose-500/30 rounded-lg p-2 max-w-xs mt-2 flex items-center gap-2">
                  <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 text-rose-500" />
                  <span className="text-left">{cameraError}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Lower Action Controllers Row */}
        <div className={`p-3 border ${
          isLight ? "bg-white border-slate-300 shadow-sm" : "bg-slate-950/60 border-cyan-500/10 shadow-lg"
        } rounded-xl flex flex-wrap items-center justify-between gap-3`}>
          <div className="flex items-center gap-2">
            {!cameraActive ? (
              <button
                id="engage-cam-btn"
                onClick={startCamera}
                className="px-4 py-2.5 rounded-lg text-[10px] font-display font-black tracking-widest bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-[0_0_12px_rgba(6,182,212,0.3)] transition-all cursor-pointer flex items-center gap-2 hover:scale-[1.02] active:scale-[0.98]"
              >
                <Camera className="w-3.5 h-3.5" />
                ENGAGE CAM
              </button>
            ) : (
              <button
                id="disengage-cam-btn"
                onClick={stopCamera}
                className="px-4 py-2.5 rounded-lg text-[10px] font-display font-black tracking-widest bg-rose-500 hover:bg-rose-400 text-slate-950 shadow-[0_0_12px_rgba(244,63,94,0.3)] transition-all cursor-pointer flex items-center gap-2 hover:scale-[1.02] active:scale-[0.98]"
              >
                <VideoOff className="w-3.5 h-3.5" />
                STANDBY SENSORS
              </button>
            )}

            <button
              id="gemini-intel-scan-btn"
              onClick={captureFrameAndScan}
              disabled={!cameraActive || visionLoading}
              className={`px-4 py-2.5 rounded-lg text-[10px] font-display font-black tracking-widest transition-all cursor-pointer flex items-center gap-2 ${
                !cameraActive
                  ? "border border-slate-800 bg-slate-900/40 text-slate-600 cursor-not-allowed"
                  : visionLoading
                    ? "bg-purple-950/40 border border-purple-500/30 text-purple-400 animate-pulse"
                    : "bg-purple-600 hover:bg-purple-500 text-white shadow-[0_0_12px_rgba(147,51,234,0.3)] hover:scale-[1.02] active:scale-[0.98]"
              }`}
            >
              <Sparkles className={`w-3.5 h-3.5 ${visionLoading ? "animate-spin" : ""}`} />
              INTEL SCAN
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="mock-overlay-toggle"
              onClick={() => setShowMockBoxes(!showMockBoxes)}
              disabled={!cameraActive}
              className={`px-3 py-2 border rounded-lg text-[10px] font-mono tracking-wider transition-all cursor-pointer ${
                !cameraActive 
                  ? "border-slate-800 text-slate-600" 
                  : showMockBoxes
                    ? "border-cyan-400 bg-cyan-500/10 text-cyan-400"
                    : "border-slate-700 hover:border-slate-600 text-slate-400 hover:text-slate-200"
              }`}
              title="Toggle YOLO Computer Vision Bounding Boxes"
            >
              BOX OVERLAYS
            </button>

            <button
              id="vision-fullscreen-toggle"
              onClick={() => setIsFullscreen(!isFullscreen)}
              className={`p-2 border rounded-lg transition-all cursor-pointer ${
                isLight 
                  ? "border-slate-300 bg-slate-100 hover:bg-slate-200 text-slate-600" 
                  : "border-cyan-500/20 bg-cyan-950/20 hover:bg-cyan-900/30 text-cyan-400"
              }`}
              title={isFullscreen ? "Minimize Panel" : "Maximize Optical Panel"}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* RIGHT BLOCK: COMPUTER VISION TELEMETRY ANALYSIS & CONSOLE (5 columns) */}
      <div className="xl:col-span-5 flex flex-col gap-4 min-h-0">
        
        {/* INTERACTIVE VISION ASSISTANT: Quick announcements trigger */}
        <div className={`p-4 border ${
          isLight ? "bg-white border-slate-300 shadow-sm text-slate-800" : "bg-slate-950/70 border-cyan-500/15 shadow-xl text-slate-100"
        } rounded-xl`}>
          <div className="flex items-center gap-2 mb-3">
            <Volume2 className="w-4 h-4 text-cyan-400 animate-pulse" />
            <h3 className={`font-display font-medium text-xs ${isLight ? "text-cyan-700" : "text-cyan-400"} uppercase tracking-widest font-black`}>
              Interactive Vision Assistant
            </h3>
          </div>

          <p className="text-[10px] font-mono text-slate-500 mb-3.5 leading-relaxed">
            Configure autonomous diagnostics triggers. Click below to command JARVIS to run live acoustic telemetry simulations:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {[
              {
                title: "Study Check",
                desc: "Looks like you're studying. Stay focused.",
                speech: "Looks like you are studying, Sir. Stay focused. I have muted incoming non-critical telemetry logs to maintain your productivity state."
              },
              {
                title: "Workspace Detection",
                desc: "Development environment detected.",
                speech: "Development environment detected, Sir. Compiler checks and background diagnostics logs are set to active monitor mode."
              },
              {
                title: "Display Scope",
                desc: "That appears to be a monitor.",
                speech: "That appears to be a secondary monitor array, Sir. Signal routing is clean and secure."
              },
              {
                title: "Activity Alert",
                desc: "Motion detected.",
                speech: "Secured mainframe boundary alert: Motion has been detected in the primary optical camera field, Sir."
              },
              {
                title: "Inactivity Check",
                desc: "You've been idle for some time.",
                speech: "You have been idle for some time, Sir. System thermals have cooled to 31 degrees Celsius. Standby power mode is primed."
              }
            ].map((voiceCard, index) => (
              <button
                key={index}
                id={`voice-card-${index}`}
                onClick={() => playAssistantSpeech(voiceCard.speech, voiceCard.title)}
                className={`p-2 rounded-lg border text-left cursor-pointer transition-all hover:scale-[1.01] active:scale-[0.99] flex flex-col justify-between ${
                  isLight
                    ? "border-slate-200 hover:border-cyan-400 hover:bg-cyan-50 text-slate-700"
                    : "border-cyan-500/5 hover:border-cyan-500/30 bg-slate-950/90 hover:bg-cyan-950/35 text-slate-300 hover:text-cyan-300"
                }`}
              >
                <span className="text-[10px] font-display font-bold text-cyan-400 tracking-wider mb-1 uppercase">
                  {voiceCard.title}
                </span>
                <span className="text-[9px] font-mono text-slate-500">
                  {voiceCard.desc}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* METRICS & ENVIRONS HUD STATUS */}
        <div className={`p-4 border ${
          isLight ? "bg-white border-slate-300 shadow-sm text-slate-800" : "bg-slate-950/70 border-cyan-500/15 shadow-xl text-slate-100"
        } rounded-xl space-y-4`}>
          <div className="flex items-center gap-2 justify-between border-b border-cyan-500/10 pb-2">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-purple-400" />
              <h3 className={`font-display font-medium text-xs ${isLight ? "text-purple-700" : "text-purple-400"} uppercase tracking-widest font-black`}>
                Environmental Analytics
              </h3>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              <span className="font-mono text-[9px] text-slate-500 uppercase font-bold">ARC CORE SYNCED</span>
            </div>
          </div>

          {/* Interactive sliders to mock or simulate environment telemetry changes */}
          <div className="space-y-3 font-mono text-[10px]">
            {/* Luminosity Slider */}
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">AMBIENT LUMINOSITY</span>
                <span className="text-cyan-400 font-bold">{luminosity} LUX</span>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="50"
                  max="1000"
                  value={luminosity}
                  onChange={(e) => setLuminosity(parseInt(e.target.value))}
                  className="flex-1 accent-cyan-400 cursor-pointer h-1 rounded"
                />
                <span className="text-[8px] text-slate-600">{luminosity < 150 ? "DIM" : luminosity > 600 ? "BRIGHT" : "OPTIMAL"}</span>
              </div>
            </div>

            {/* Motion intensity Slider */}
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">MOTION INDEX</span>
                <span className="text-purple-400 font-bold">{motionRate} m/s²</span>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="0"
                  max="20"
                  step="0.1"
                  value={motionRate}
                  onChange={(e) => setMotionRate(parseFloat(e.target.value))}
                  className="flex-1 accent-purple-400 cursor-pointer h-1 rounded"
                />
                <span className="text-[8px] text-slate-600">{motionRate < 0.5 ? "STATIONARY" : motionRate > 8 ? "DANGER" : "FLOW"}</span>
              </div>
            </div>

            {/* Audio Decibel level Slider */}
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">ACOUSTIC DENSITY</span>
                <span className="text-pink-400 font-bold">{audioDecibels} dB</span>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="10"
                  max="110"
                  value={audioDecibels}
                  onChange={(e) => setAudioDecibels(parseInt(e.target.value))}
                  className="flex-1 accent-pink-400 cursor-pointer h-1 rounded"
                />
                <span className="text-[8px] text-slate-600">{audioDecibels < 30 ? "MUTED" : audioDecibels > 80 ? "NOISY" : "SECURE"}</span>
              </div>
            </div>
          </div>

          {/* Quick status box grid */}
          <div className="grid grid-cols-2 gap-2 mt-2">
            <div className="p-2 border border-cyan-500/5 bg-slate-950/40 rounded-lg text-center font-mono text-[9px] space-y-0.5">
              <span className="text-slate-500 block uppercase">SCENE CATEGORY</span>
              <span className="font-bold text-cyan-400 uppercase tracking-widest block text-[10px]">
                {sceneMode === "dev" ? "DEV CORE GRID" : sceneMode === "study" ? "RESEARCH LAB" : "IDLE STATION"}
              </span>
              <div className="flex items-center justify-center gap-1.5 pt-1">
                {["dev", "study", "idle"].map(m => (
                  <button
                    key={m}
                    onClick={() => setSceneMode(m as any)}
                    className={`w-2 h-2 rounded-full border border-current ${
                      sceneMode === m ? "bg-cyan-400" : "bg-transparent opacity-30"
                    }`}
                    title={`Set scene mode to ${m}`}
                  />
                ))}
              </div>
            </div>

            <div className="p-2 border border-cyan-500/5 bg-slate-950/40 rounded-lg text-center font-mono text-[9px] flex flex-col justify-center items-center">
              <span className="text-slate-500 block uppercase">THERMAL SCAN</span>
              <span className="font-bold text-purple-400 text-[11px] block mt-1">32.4°C STATUS</span>
              <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden mt-1 max-w-[60px]">
                <div className="bg-gradient-to-r from-cyan-400 to-purple-500 h-full w-[45%]" />
              </div>
            </div>
          </div>
        </div>

        {/* GEMINI REAL-TIME VISION INSIGHTS SECTION */}
        <div className={`p-4 border ${
          isLight ? "bg-white border-slate-300 shadow-sm text-slate-800" : "bg-slate-950/70 border-cyan-500/15 shadow-xl text-slate-100"
        } rounded-xl flex-1 flex flex-col min-h-[180px]`}>
          <div className="flex items-center justify-between mb-3 border-b border-cyan-500/10 pb-2">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-purple-500" />
              <h3 className={`font-display font-medium text-xs ${isLight ? "text-purple-700" : "text-purple-400"} uppercase tracking-widest font-black`}>
                Gemini Live AI Visual Insight
              </h3>
            </div>
            {visionAnalysis && (
              <button
                onClick={() => setCapturedImage(null)}
                className="text-[9px] font-mono text-rose-400 hover:text-rose-300 border border-rose-500/30 px-1.5 py-0.5 rounded cursor-pointer"
              >
                CLEAR
              </button>
            )}
          </div>

          <div className="flex-1 flex flex-col justify-center relative min-h-0">
            {visionLoading ? (
              <div className="flex flex-col items-center justify-center text-center py-6 space-y-3">
                <div className="relative">
                  <RotateCw className="w-8 h-8 text-purple-400 animate-spin" />
                  <Sparkles className="w-4 h-4 text-cyan-400 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 animate-pulse" />
                </div>
                <div className="space-y-1">
                  <span className="font-mono text-[10px] text-purple-400 animate-pulse font-bold uppercase tracking-widest block">
                    TRANSMITTING NEURAL LAYERS
                  </span>
                  <span className="font-mono text-[9px] text-slate-500 uppercase block">
                    Gemini model formulating visual analytics...
                  </span>
                </div>
              </div>
            ) : visionAnalysis ? (
              <div className="overflow-y-auto max-h-[180px] xl:max-h-[240px] scrollbar-thin font-mono text-[10px] leading-relaxed text-slate-300 bg-slate-950/40 p-3 rounded-lg border border-cyan-500/5 select-text">
                {visionAnalysis}
              </div>
            ) : capturedImage ? (
              <div className="flex flex-col items-center justify-center text-center py-6 space-y-2">
                <div className="w-24 h-16 rounded border border-cyan-500/20 overflow-hidden shadow">
                  <img src={capturedImage} alt="Captured preview" className="w-full h-full object-cover transform -scale-x-100" referrerPolicy="no-referrer" />
                </div>
                <div className="space-y-1">
                  <span className="font-mono text-[10px] text-cyan-400 block font-bold">IMAGE CACHED IN MAINFRAME</span>
                  <button
                    onClick={() => analyzeCapturedImage("Analyze this environment image as JARVIS. Act as an operating system assistant. Scan the surroundings and describe what is visible: objects, people, lighting conditions, and potential developer tasks in progress, Sir. Be precise, polite, and British.")}
                    className="mt-1 px-3 py-1 bg-purple-600 hover:bg-purple-500 text-white font-mono text-[9px] font-black uppercase tracking-widest rounded shadow cursor-pointer"
                  >
                    TRIGGER ANALYSIS
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <ScanLine className="w-8 h-8 text-slate-600/60 mx-auto mb-2 animate-pulse" />
                <span className="font-mono text-[10px] text-slate-500 uppercase tracking-wider block font-bold">
                  Telemetry Scan Cache Empty
                </span>
                <span className="font-mono text-[9px] text-slate-600 uppercase block mt-0.5">
                  Point camera and click INTEL SCAN to run deep learning scene audits
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
