/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from "react";
import { useJarvisStore } from "../stores/jarvisStore";
import { Sparkles, Mic, Activity, Eye, Move, Cpu, Layers } from "lucide-react";

export default function AICore() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const waveformMode = useJarvisStore((state) => state.waveformMode);
  const systemStatus = useJarvisStore((state) => state.systemStatus);
  const isListening = useJarvisStore((state) => state.isListening);
  const isSpeaking = useJarvisStore((state) => state.isSpeaking);
  const startListening = useJarvisStore((state) => state.startListening);
  const stopListening = useJarvisStore((state) => state.stopListening);
  const stopSpeaking = useJarvisStore((state) => state.stopSpeaking);
  const addToast = useJarvisStore((state) => state.addToast);
  const settings = useJarvisStore((state) => state.settings);
  const batteryLevel = useJarvisStore((state) => state.batteryLevel);
  const setTab = useJarvisStore((state) => state.setTab);

  // Audio elements for microphone visualizer
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const dataArrayRef = useRef<Uint8Array | null>(null);

  // Hover and Drag States
  const [isHovered, setIsHovered] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const dragStartRef = useRef({ x: 0, y: 0 });
  const currentDragOffsetRef = useRef({ x: 0, y: 0 });

  // Cursor and Inertia trackers for animation loop
  const mousePosRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const velocityRef = useRef(0);
  const prevMousePosRef = useRef({ x: 0, y: 0 });
  const deviceTiltRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    let active = true;

    async function setupMic() {
      if (!isListening) return;

      try {
        const AudioCtx = (window as any).AudioContext || (window as any).webkitAudioContext;
        if (!AudioCtx) {
          console.warn("AudioContext is not supported in this environment.");
          return;
        }

        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        if (!active) {
          stream.getTracks().forEach((track) => track.stop());
          return;
        }

        const audioCtx = new AudioCtx();
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 256;

        const source = audioCtx.createMediaStreamSource(stream);
        source.connect(analyser);

        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);

        audioContextRef.current = audioCtx;
        analyserRef.current = analyser;
        streamRef.current = stream;
        dataArrayRef.current = dataArray;
      } catch (err) {
        console.warn("Failed to access microphone for visualizer:", err);
      }
    }

    if (isListening) {
      setupMic();
    }

    return () => {
      active = false;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
      if (audioContextRef.current && audioContextRef.current.state !== "closed") {
        audioContextRef.current.close().catch(() => {});
        audioContextRef.current = null;
      }
      analyserRef.current = null;
      dataArrayRef.current = null;
    };
  }, [isListening]);

  // Pointer event listeners to handle dragging the orb with spring physics
  const handlePointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    setIsDragging(true);
    const container = containerRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const clickX = e.clientX - rect.left - rect.width / 2;
    const clickY = e.clientY - rect.top - rect.height / 2;

    dragStartRef.current = {
      x: clickX - currentDragOffsetRef.current.x,
      y: clickY - currentDragOffsetRef.current.y
    };
    container.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const container = containerRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const clickX = e.clientX - rect.left - rect.width / 2;
    const clickY = e.clientY - rect.top - rect.height / 2;

    const newX = clickX - dragStartRef.current.x;
    const newY = clickY - dragStartRef.current.y;

    // Limit drag offset bounds
    const maxBound = Math.min(rect.width, rect.height) * 0.4;
    const distance = Math.sqrt(newX * newX + newY * newY);
    if (distance < maxBound) {
      currentDragOffsetRef.current = { x: newX, y: newY };
      setDragOffset({ x: newX, y: newY });
    } else {
      const angle = Math.atan2(newY, newX);
      const bx = Math.cos(angle) * maxBound;
      const by = Math.sin(angle) * maxBound;
      currentDragOffsetRef.current = { x: bx, y: by };
      setDragOffset({ x: bx, y: by });
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    const container = containerRef.current;
    if (container) {
      container.releasePointerCapture(e.pointerId);
    }
    addToast("Orb telemetry grid stabilized.", "info");
  };

  const handleCoreClick = () => {
    if (isSpeaking) {
      stopSpeaking();
      addToast("Synthesizer vocal feed paused.", "info");
    } else if (isListening) {
      stopListening();
      addToast("Acoustics mic feed deactivated.", "warning");
    } else {
      startListening();
      addToast("Cognitive Arc Core engaging acoustics...", "success");
    }
  };

  // Track cursor coordinates on window for responsive 360 rotation and eye contact
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const rect = canvas.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;

      // Track target normalized values (-1 to 1)
      mousePosRef.current.targetX = (e.clientX - cx) / (rect.width / 2 || 200);
      mousePosRef.current.targetY = (e.clientY - cy) / (rect.height / 2 || 200);

      // Clamp mouse coordinates
      mousePosRef.current.targetX = Math.max(-1.5, Math.min(1.5, mousePosRef.current.targetX));
      mousePosRef.current.targetY = Math.max(-1.5, Math.min(1.5, mousePosRef.current.targetY));
    };

    // Gyroscope mobile support
    const handleDeviceOrientation = (e: DeviceOrientationEvent) => {
      if (e.gamma !== null && e.beta !== null) {
        // gamma is left-to-right tilt (-90 to 90), beta is front-to-back tilt (-180 to 180)
        deviceTiltRef.current.x = e.gamma / 45; // scale to rough -1 to 1
        deviceTiltRef.current.y = (e.beta - 45) / 45; 
      }
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("deviceorientation", handleDeviceOrientation);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("deviceorientation", handleDeviceOrientation);
    };
  }, []);

  // Main high-fidelity canvas rendering loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let rotationAngle1 = 0;
    let rotationAngle2 = 0;
    let rotationAngle3 = 0;
    let pulseFactor = 1;
    let pulseDirection = 1;
    let waveOffset = 0;

    // Handle resizing to contain within parent bento box
    const resizeCanvas = () => {
      const rect = canvas.parentElement?.getBoundingClientRect();
      canvas.width = (rect?.width || 400) * window.devicePixelRatio;
      canvas.height = (rect?.height || 400) * window.devicePixelRatio;
      canvas.style.width = "100%";
      canvas.style.height = "100%";
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };

    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    // Particle nodes for holographic grid
    const particles: Array<{ x: number; y: number; r: number; speedX: number; speedY: number; alpha: number }> = [];
    for (let i = 0; i < 45; i++) {
      particles.push({
        x: Math.random() * 300 - 150,
        y: Math.random() * 300 - 150,
        r: Math.random() * 2 + 0.5,
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.5,
        alpha: Math.random() * 0.5 + 0.3,
      });
    }

    // Animation Loop
    const render = () => {
      const w = canvas.width / window.devicePixelRatio;
      const h = canvas.height / window.devicePixelRatio;
      const baseCx = w / 2;
      const baseCy = h / 2;

      // Handle spring mechanics for drag offset
      if (!isDragging) {
        currentDragOffsetRef.current.x += (0 - currentDragOffsetRef.current.x) * 0.08;
        currentDragOffsetRef.current.y += (0 - currentDragOffsetRef.current.y) * 0.08;
      }

      // Smooth inertia on cursor coordinates
      mousePosRef.current.x += (mousePosRef.current.targetX - mousePosRef.current.x) * 0.08;
      mousePosRef.current.y += (mousePosRef.current.targetY - mousePosRef.current.y) * 0.08;

      // Combined gyroscope orientation and cursor offsets
      const finalOffsetX = mousePosRef.current.x + deviceTiltRef.current.x;
      const finalOffsetY = mousePosRef.current.y + deviceTiltRef.current.y;

      // Eye-contact simulation: shift center of drawing based on mouse coordinates + drag offset
      const cx = baseCx + finalOffsetX * 20 + currentDragOffsetRef.current.x;
      const cy = baseCy + finalOffsetY * 20 + currentDragOffsetRef.current.y;

      // Calculate cursor velocity for trails
      const dx = mousePosRef.current.x - prevMousePosRef.current.x;
      const dy = mousePosRef.current.y - prevMousePosRef.current.y;
      const currentVel = Math.sqrt(dx * dx + dy * dy);
      velocityRef.current += (currentVel - velocityRef.current) * 0.1;
      
      prevMousePosRef.current.x = mousePosRef.current.x;
      prevMousePosRef.current.y = mousePosRef.current.y;

      // Expand on hover
      const hoverSizeMultiplier = isHovered ? 1.15 : 1.0;
      const coreSize = Math.min(w, h) * 0.35 * hoverSizeMultiplier;

      ctx.clearRect(0, 0, w, h);

      // Read microphone volume if listening
      let micVolume = 0;
      const hasMicData = waveformMode === "listening" && analyserRef.current && dataArrayRef.current;
      if (hasMicData && analyserRef.current && dataArrayRef.current) {
        analyserRef.current.getByteTimeDomainData(dataArrayRef.current);
        let sum = 0;
        for (let i = 0; i < dataArrayRef.current.length; i++) {
          sum += Math.abs(dataArrayRef.current[i] - 128);
        }
        micVolume = sum / dataArrayRef.current.length;
      }

      // Adjust variables based on active core mode and velocity
      // High cursor velocity triggers energy trails and faster spin!
      let speedMultiplier = 1.0 + velocityRef.current * 8.0;
      let particleGlowColor = "rgba(6, 182, 212, "; // Cyan
      let outerGlowColor = "rgba(6, 182, 212, 0.1)";
      let waveFrequency = 0.05;
      let waveAmplitude = 10;

      if (waveformMode === "listening") {
        speedMultiplier += 2.0 + (micVolume / 10);
        particleGlowColor = "rgba(168, 85, 247, "; // Purple for listening
        outerGlowColor = "rgba(168, 85, 247, 0.2)";
        waveFrequency = 0.15;
        waveAmplitude = 25 + micVolume * 1.5;
      } else if (waveformMode === "speaking") {
        speedMultiplier += 1.2;
        particleGlowColor = "rgba(6, 182, 212, "; // Cyan
        outerGlowColor = "rgba(6, 182, 212, 0.25)";
        waveFrequency = 0.08;
        waveAmplitude = Math.sin(Date.now() * 0.02) * 15 + 20;
      } else if (waveformMode === "thinking") {
        speedMultiplier += 3.0;
        particleGlowColor = "rgba(236, 72, 153, "; // Magenta for thinking
        outerGlowColor = "rgba(236, 72, 153, 0.2)";
        waveFrequency = 0.25;
        waveAmplitude = 8;
      }

      // Apply Power Save mode throttle
      const isPowerSaveActive = settings?.appearance?.powerSaveMode && batteryLevel !== null && batteryLevel < 15;
      if (isPowerSaveActive) {
        speedMultiplier *= 0.25;
      }

      // Smooth 360 degree rotation
      rotationAngle1 += 0.005 * speedMultiplier;
      rotationAngle2 -= 0.008 * speedMultiplier;
      rotationAngle3 += 0.012 * speedMultiplier;

      // Core pulse
      pulseFactor += 0.01 * pulseDirection * speedMultiplier;
      if (pulseFactor > 1.15) pulseDirection = -1;
      if (pulseFactor < 0.85) pulseDirection = 1;

      // Idle float (sinusoidal offset to feel alive when cursor is static)
      const idleOffset = Math.sin(Date.now() * 0.001) * 4;
      const finalCy = cy + idleOffset;

      let dynamicPulseFactor = pulseFactor;
      if (waveformMode === "listening" && micVolume > 0.5) {
        dynamicPulseFactor += (micVolume / 45);
        if (dynamicPulseFactor > 1.5) dynamicPulseFactor = 1.5;
      }

      waveOffset += 0.05 * speedMultiplier;

      // 1. Diagnostics Grid System
      ctx.strokeStyle = "rgba(6, 182, 212, 0.025)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = 0; x < w; x += 30) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
      }
      for (let y = 0; y < h; y += 30) {
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
      }
      ctx.stroke();

      // 2. High velocity "Energy Trails"
      if (velocityRef.current > 0.15) {
        ctx.strokeStyle = particleGlowColor + "0.08)";
        ctx.lineWidth = 6 * velocityRef.current;
        ctx.beginPath();
        ctx.arc(cx, finalCy, coreSize * 1.05, rotationAngle1 - velocityRef.current * 2, rotationAngle1);
        ctx.stroke();
      }

      // 3. Outer glowing ring
      ctx.shadowBlur = isHovered ? 30 : 15;
      ctx.shadowColor = particleGlowColor + "0.4)";
      ctx.strokeStyle = particleGlowColor + "0.15)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, finalCy, coreSize, 0, Math.PI * 2);
      ctx.stroke();

      // 4. Rotating dashed ring 1
      ctx.strokeStyle = particleGlowColor + "0.35)";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([10, 15, 30, 15]);
      ctx.beginPath();
      ctx.arc(cx, finalCy, coreSize * 0.85, rotationAngle1, rotationAngle1 + Math.PI * 2);
      ctx.stroke();

      // 5. Rotating ring 2 (ticks)
      ctx.strokeStyle = particleGlowColor + "0.55)";
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 12]);
      ctx.beginPath();
      ctx.arc(cx, finalCy, coreSize * 0.7, rotationAngle2, rotationAngle2 + Math.PI * 2);
      ctx.stroke();

      // 6. 3D Space orbiting particles
      ctx.setLineDash([]);
      ctx.shadowBlur = 0;
      particles.forEach((p) => {
        p.x += p.speedX * speedMultiplier;
        p.y += p.speedY * speedMultiplier;

        // Sphere boundary check
        const dist = Math.sqrt(p.x * p.x + p.y * p.y);
        const maxDist = coreSize * 0.65;
        if (dist > maxDist) {
          const angle = Math.atan2(p.y, p.x);
          p.x = Math.cos(angle) * -maxDist;
          p.y = Math.sin(angle) * -maxDist;
        }

        // Apply visual tilt to particles
        const drawX = cx + p.x + finalOffsetX * 10;
        const drawY = finalCy + p.y + finalOffsetY * 10;

        ctx.fillStyle = particleGlowColor + p.alpha + ")";
        ctx.shadowBlur = isHovered ? 12 : 6;
        ctx.shadowColor = particleGlowColor + "0.8)";
        ctx.beginPath();
        ctx.arc(drawX, drawY, p.r, 0, Math.PI * 2);
        ctx.fill();

        // Connected mesh bonds
        particles.forEach((other) => {
          const opDist = Math.sqrt(Math.pow(p.x - other.x, 2) + Math.pow(p.y - other.y, 2));
          if (opDist < 40) {
            ctx.strokeStyle = particleGlowColor + "0.06)";
            ctx.lineWidth = 0.5;
            ctx.shadowBlur = 0;
            ctx.beginPath();
            ctx.moveTo(cx + p.x + finalOffsetX * 10, finalCy + p.y + finalOffsetY * 10);
            ctx.lineTo(cx + other.x + finalOffsetX * 10, finalCy + other.y + finalOffsetY * 10);
            ctx.stroke();
          }
        });
      });

      // 7. Core Plasma Glow (Reactor Core)
      const gradient = ctx.createRadialGradient(cx, finalCy, 2, cx, finalCy, coreSize * 0.38 * dynamicPulseFactor);
      if (waveformMode === "listening") {
        gradient.addColorStop(0, "rgba(255, 255, 255, 1)");
        gradient.addColorStop(0.2, "rgba(192, 132, 252, 0.85)");
        gradient.addColorStop(0.6, "rgba(168, 85, 247, 0.4)");
        gradient.addColorStop(1, "rgba(168, 85, 247, 0)");
      } else if (waveformMode === "thinking") {
        gradient.addColorStop(0, "rgba(255, 255, 255, 1)");
        gradient.addColorStop(0.2, "rgba(244, 114, 182, 0.85)");
        gradient.addColorStop(0.6, "rgba(236, 72, 153, 0.4)");
        gradient.addColorStop(1, "rgba(236, 72, 153, 0)");
      } else {
        gradient.addColorStop(0, "rgba(255, 255, 255, 1)");
        gradient.addColorStop(0.2, "rgba(34, 211, 238, 0.85)");
        gradient.addColorStop(0.6, "rgba(6, 182, 212, 0.4)");
        gradient.addColorStop(1, "rgba(6, 182, 212, 0)");
      }

      ctx.fillStyle = gradient;
      ctx.shadowBlur = isHovered ? 40 : 25;
      ctx.shadowColor = particleGlowColor + "0.95)";
      ctx.beginPath();
      ctx.arc(cx, finalCy, coreSize * 0.38 * dynamicPulseFactor, 0, Math.PI * 2);
      ctx.fill();

      // 8. Rotating vector alignment crosshairs
      ctx.shadowBlur = 0;
      ctx.strokeStyle = particleGlowColor + "0.65)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < 4; i++) {
        const angle = rotationAngle3 + (i * Math.PI) / 2;
        const startRad = coreSize * 0.72;
        const endRad = coreSize * 0.78;
        ctx.moveTo(cx + Math.cos(angle) * startRad, finalCy + Math.sin(angle) * startRad);
        ctx.lineTo(cx + Math.cos(angle) * endRad, finalCy + Math.sin(angle) * endRad);
        
        const capAngle = angle + 0.05;
        ctx.lineTo(cx + Math.cos(capAngle) * endRad, finalCy + Math.sin(capAngle) * endRad);
      }
      ctx.stroke();

      // 9. Acoustics frequency oscillator
      ctx.shadowBlur = 10;
      ctx.shadowColor = particleGlowColor + "0.45)";
      ctx.strokeStyle = particleGlowColor + "0.75)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      
      const numPoints = Math.floor((coreSize * 2) / 4) + 1;
      for (let i = 0; i < numPoints; i++) {
        const relativeX = (i * 4) - coreSize;
        const x = cx + relativeX;
        const scale = 1 - Math.pow(relativeX / coreSize, 2);
        
        let offsetValue = 0;
        if (hasMicData && dataArrayRef.current) {
          const dataIdx = Math.min(
            dataArrayRef.current.length - 1,
            Math.floor((i / numPoints) * dataArrayRef.current.length)
          );
          const rawValue = dataArrayRef.current[dataIdx];
          const normalized = (rawValue - 128) / 128;
          offsetValue = normalized * waveAmplitude * 2.2;
        } else {
          offsetValue = Math.sin(relativeX * waveFrequency + waveOffset) * waveAmplitude;
        }
        
        const waveY = finalCy + coreSize * 0.5 + offsetValue * scale;
        if (i === 0) {
          ctx.moveTo(x, waveY);
        } else {
          ctx.lineTo(x, waveY);
        }
      }
      ctx.stroke();

      // 10. Digital label systems
      ctx.shadowBlur = 0;
      ctx.fillStyle = "rgba(6, 182, 212, 0.65)";
      ctx.font = "normal 500 9px 'JetBrains Mono'";
      ctx.textAlign = "center";
      ctx.fillText(`ARC_REACTION_FLUX: ${(98.4 + Math.sin(rotationAngle1) * 0.5 + velocityRef.current * 10).toFixed(2)}%`, cx, finalCy - coreSize * 1.12);
      ctx.fillText(`CORE_MODE: ${waveformMode.toUpperCase()}`, cx, finalCy + coreSize * 1.15);

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", resizeCanvas);
    };
  }, [waveformMode, isHovered, isDragging]);

  return (
    <div 
      ref={containerRef}
      id="jarvis_core_container" 
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="relative w-full h-full flex items-center justify-center bg-radial from-[#09152a] to-[#04060f] border border-cyan-500/20 hover:border-cyan-400/50 hover:shadow-[0_0_15px_rgba(6,182,212,0.15)] rounded-2xl overflow-hidden shadow-inner shadow-cyan-950/40 cursor-grab active:cursor-grabbing transition-all duration-300"
    >
      {/* Absolute futuristic overlay details */}
      <div className="absolute top-4 left-4 font-mono text-[10px] text-cyan-400/50 hidden sm:flex flex-col gap-1 select-none pointer-events-none">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-ping"></span>
          <span>SYSTEM_CORE_ENGAGED</span>
        </div>
        <div>MARK_1.5_BLUEPRINT</div>
        <div>RADAR_RANGE: SECURE</div>
      </div>

      <div className="absolute top-4 right-4 font-mono text-[10px] text-right text-cyan-400/50 hidden sm:flex flex-col gap-1 select-none pointer-events-none">
        <div>INTEGRITY: {systemStatus?.diagnostics.integrity || "100%"}</div>
        <div>TEMP: {systemStatus?.serverMetrics.temperature || "34°C"}</div>
        <div>ARC_CORE: STABLE</div>
      </div>

      <div className="absolute bottom-4 left-4 font-mono text-[9px] text-cyan-400/30 select-none pointer-events-none hidden sm:block">
        PROT_JARVIS_918 // SECURE_MAIN
      </div>

      <canvas ref={canvasRef} className="w-full h-full block" />

      {/* Hover Quick Actions Overlay */}
      <div 
        className={`absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center gap-3 transition-all duration-300 ${
          isHovered && !isDragging ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
      >
        <span className="text-[10px] font-bold uppercase tracking-widest text-cyan-400 animate-pulse">
          Cognitive Core Interceptor
        </span>
        
        <div className="grid grid-cols-2 gap-2 max-w-[280px]">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setTab("companion");
              addToast("Accessing premium companion controls...", "success");
            }}
            className="px-3 py-1.5 border border-cyan-500/30 hover:border-cyan-400 bg-cyan-950/20 text-cyan-400 text-[9px] font-bold rounded-lg cursor-pointer uppercase transition-all flex items-center justify-center gap-1.5 hover:scale-105"
          >
            <Sparkles className="w-3.5 h-3.5" />
            COMPANION
          </button>
          
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleCoreClick();
            }}
            className="px-3 py-1.5 border border-cyan-500/30 hover:border-cyan-400 bg-cyan-950/20 text-cyan-400 text-[9px] font-bold rounded-lg cursor-pointer uppercase transition-all flex items-center justify-center gap-1.5 hover:scale-105"
          >
            <Mic className="w-3.5 h-3.5" />
            {isListening ? "Mute Mic" : "Engage Mic"}
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              setTab("chat");
              addToast("Accessing communication node...", "success");
            }}
            className="px-3 py-1.5 border border-cyan-500/30 hover:border-cyan-400 bg-cyan-950/20 text-cyan-400 text-[9px] font-bold rounded-lg cursor-pointer uppercase transition-all flex items-center justify-center gap-1.5 hover:scale-105"
          >
            <Cpu className="w-3.5 h-3.5" />
            OPEN CHAT
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              addToast("Reactor core power peak optimized: speed levels stabilized.", "success");
            }}
            className="px-3 py-1.5 border border-cyan-500/30 hover:border-cyan-400 bg-cyan-950/20 text-cyan-400 text-[9px] font-bold rounded-lg cursor-pointer uppercase transition-all flex items-center justify-center gap-1.5 hover:scale-105"
          >
            <Layers className="w-3.5 h-3.5" />
            BOOST CORES
          </button>
        </div>
        
        <span className="text-[8px] text-slate-500 mt-1 font-mono flex items-center gap-1">
          <Move className="w-3 h-3 text-cyan-500 animate-bounce" /> Drag core sphere to re-align coordinates
        </span>
      </div>
    </div>
  );
}
