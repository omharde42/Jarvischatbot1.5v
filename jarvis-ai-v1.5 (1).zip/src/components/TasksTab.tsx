/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { useJarvisStore } from "../stores/jarvisStore";
import { motion, AnimatePresence } from "motion/react";
import { 
  Play, 
  Square, 
  RotateCcw, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  AlertTriangle,
  Zap,
  Flame,
  Bell,
  Clock, 
  Terminal, 
  Plus, 
  Sliders, 
  ListTodo,
  Cpu,
  ChevronDown,
  Activity
} from "lucide-react";

const holographicContainerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const holographicSectionVariants = {
  hidden: { 
    opacity: 0, 
    y: 20,
    filter: "hue-rotate(-15deg) brightness(1.3) contrast(1.1) drop-shadow(0 0 12px rgba(6,182,212,0.4))",
  },
  visible: { 
    opacity: 1, 
    y: 0,
    filter: "hue-rotate(0deg) brightness(1) contrast(1) drop-shadow(0 0 0px rgba(0,0,0,0))",
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 15,
    },
  },
};

export default function TasksTab() {
  const { tasks, tasksLoading, fetchTasks, addTask, cancelTask, retryTask } = useJarvisStore();
  const [newTaskName, setNewTaskName] = useState("");
  const [selectedType, setSelectedType] = useState("Automation");
  const [selectedPriority, setSelectedPriority] = useState<"low" | "medium" | "high" | "critical">("medium");
  const [deadlineSecs, setDeadlineSecs] = useState<number>(0); // 0 means none
  const [selectedCategory, setSelectedCategory] = useState("Development");
  const [filterCategory, setFilterCategory] = useState("All");
  const [tick, setTick] = useState(0);

  useEffect(() => {
    fetchTasks();
    // Refresh tasks queue periodically for mock state progression
    const interval = setInterval(() => {
      fetchTasks();
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // Set up high frequency ticker for smooth ticking countdown display
  useEffect(() => {
    const clock = setInterval(() => {
      setTick((t) => t + 1);
    }, 1000);
    return () => clearInterval(clock);
  }, []);

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskName.trim() === "") return;

    let deadlineIso: string | undefined = undefined;
    if (deadlineSecs > 0) {
      deadlineIso = new Date(Date.now() + deadlineSecs * 1000).toISOString();
    }

    await addTask(newTaskName, selectedType, selectedPriority, deadlineIso, selectedCategory);
    setNewTaskName("");
    setDeadlineSecs(0);
  };

  const getRemainingSeconds = (deadlineStr?: string) => {
    if (!deadlineStr) return null;
    const diff = new Date(deadlineStr).getTime() - Date.now();
    return Math.max(0, Math.ceil(diff / 1000));
  };

  const runningTasks = tasks.filter((t) => t.status === "running");
  const completedTasks = tasks.filter((t) => t.status === "completed");
  const failedTasks = tasks.filter((t) => t.status === "failed");

  const filteredTasks = tasks.filter((task) => {
    if (filterCategory === "All") return true;
    return (task.category || "Maintenance").toLowerCase() === filterCategory.toLowerCase();
  });

  return (
    <motion.div
      id="jarvis_tasks_tab"
      initial="hidden"
      animate="visible"
      variants={holographicContainerVariants}
      className="grid grid-cols-1 lg:grid-cols-4 gap-4 overflow-visible lg:overflow-hidden h-auto lg:h-[550px] xl:h-full"
    >
      {/* Side Creation Panel */}
      <motion.div
        variants={holographicSectionVariants}
        className="lg:col-span-1 flex flex-col gap-4 h-auto lg:h-full overflow-y-auto lg:overflow-hidden"
      >
        {/* Quick Create Task */}
        <div className="glassmorphism rounded-xl border border-cyan-500/20 p-4">
          <div className="flex items-center gap-2 mb-3">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="font-display font-medium text-sm text-slate-200 uppercase tracking-widest">Task Launcher</h3>
          </div>
          
          <form onSubmit={handleCreateTask} className="space-y-3">
            <div>
              <label className="block text-[9px] font-mono text-cyan-400/70 uppercase tracking-widest mb-1.5">Task Class</label>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="w-full bg-slate-950/80 border border-cyan-500/20 rounded-lg px-2.5 py-1.5 font-sans text-xs text-slate-200 focus:outline-none focus:border-cyan-400"
              >
                <option value="Automation">Automation Thread</option>
                <option value="Diagnostics">Systems Diagnosis</option>
                <option value="Calibration">Reactor Calibration</option>
                <option value="Defense">Sentinel Security</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] font-mono text-cyan-400/70 uppercase tracking-widest mb-1.5">Task Priority</label>
              <select
                value={selectedPriority}
                onChange={(e) => setSelectedPriority(e.target.value as any)}
                className="w-full bg-slate-950/80 border border-cyan-500/20 rounded-lg px-2.5 py-1.5 font-sans text-xs text-slate-200 focus:outline-none focus:border-cyan-400"
              >
                <option value="low">Low (System Routine)</option>
                <option value="medium">Medium (Nominal Operation)</option>
                <option value="high">High (Subsystem Sync)</option>
                <option value="critical">Critical (Reactor Core)</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] font-mono text-cyan-400/70 uppercase tracking-widest mb-1.5">Task Deadline</label>
              <select
                value={deadlineSecs}
                onChange={(e) => setDeadlineSecs(Number(e.target.value))}
                className="w-full bg-slate-950/80 border border-cyan-500/20 rounded-lg px-2.5 py-1.5 font-sans text-xs text-slate-200 focus:outline-none focus:border-cyan-400"
              >
                <option value={0}>No Simulated Deadline</option>
                <option value={15}>15 Seconds (Quick Fire)</option>
                <option value={30}>30 Seconds (Rapid Staged)</option>
                <option value={60}>1 Minute (Standard Process)</option>
                <option value={120}>2 Minutes (Macro Cycle)</option>
                <option value={300}>5 Minutes (Long Term)</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] font-mono text-cyan-400/70 uppercase tracking-widest mb-1.5">Task Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full bg-slate-950/80 border border-cyan-500/20 rounded-lg px-2.5 py-1.5 font-sans text-xs text-slate-200 focus:outline-none focus:border-cyan-400"
              >
                <option value="Development">Development</option>
                <option value="Maintenance">Maintenance</option>
                <option value="Research">Research</option>
                <option value="Personal">Personal</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] font-mono text-cyan-400/70 uppercase tracking-widest mb-1.5">Task Title</label>
              <input
                type="text"
                placeholder="e.g. Map Armor Telemetry..."
                value={newTaskName}
                onChange={(e) => setNewTaskName(e.target.value)}
                className="w-full bg-slate-950/80 border border-cyan-500/20 rounded-lg px-2.5 py-1.5 font-sans text-xs text-slate-200 placeholder-cyan-500/35 focus:outline-none focus:border-cyan-400"
              />
            </div>

            <button
              type="submit"
              disabled={newTaskName.trim() === ""}
              className="w-full py-2 border border-cyan-400 bg-cyan-950/10 hover:bg-cyan-500 hover:text-slate-950 text-cyan-400 font-bold font-display text-xs rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:hover:bg-cyan-950/10 disabled:hover:text-cyan-400"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>DEPLOY TASK</span>
            </button>
          </form>
        </div>

        {/* Diagnostic Status Dashboard Card */}
        <div className="glassmorphism rounded-xl border border-cyan-500/20 p-4 flex-1">
          <div className="flex items-center gap-2 mb-3">
            <ListTodo className="w-4 h-4 text-cyan-400" />
            <h3 className="font-display font-medium text-sm text-slate-200 uppercase tracking-widest">JARVIS Queue Info</h3>
          </div>
          <div className="space-y-3 font-mono text-xs text-slate-400">
            <div className="flex items-center justify-between border-b border-cyan-500/5 pb-1.5">
              <span>Running processes:</span>
              <span className="text-cyan-400 font-bold">{runningTasks.length}</span>
            </div>
            <div className="flex items-center justify-between border-b border-cyan-500/5 pb-1.5">
              <span>Successful tasks:</span>
              <span className="text-green-400">{completedTasks.length}</span>
            </div>
            <div className="flex items-center justify-between border-b border-cyan-500/5 pb-1.5">
              <span>Failed threads:</span>
              <span className="text-red-400">{failedTasks.length}</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Diagnostics priority:</span>
              <span className="text-cyan-500/80">OVERRIDE-A</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Main Task Queue Monitor */}
      <motion.div
        variants={holographicSectionVariants}
        className="lg:col-span-3 flex flex-col glassmorphism rounded-xl border border-cyan-500/20 p-4 h-[480px] lg:h-full overflow-hidden"
      >
        <div className="flex items-center justify-between gap-2.5 mb-4 border-b border-cyan-500/10 pb-3">
          <div className="flex items-center gap-2.5">
            <Cpu className="w-5 h-5 text-cyan-400 animate-spin [animation-duration:10s]" />
            <div>
              <h2 className="font-display text-sm font-semibold text-slate-100 tracking-wider uppercase">Active Automation Mainframe</h2>
              <p className="text-[10px] text-slate-500 font-mono">PARALLEL SYSTEM DIAGNOSTIC RUNTIME QUEUES</p>
            </div>
          </div>
          {/* Mainframe Status Badge */}
          {(() => {
            const activeAlerts = tasks
              .filter((task) => task.status === "running")
              .map((task) => {
                const remainingSecs = getRemainingSeconds(task.deadline);
                const isDeadlineApproaching = remainingSecs !== null && remainingSecs > 0 && remainingSecs <= 15;
                const isHighPriorityCompleting =
                  (task.priority === "high" || task.priority === "critical") &&
                  task.progress >= 85 &&
                  task.progress < 100;

                if (isDeadlineApproaching || isHighPriorityCompleting) {
                  return { task, type: isDeadlineApproaching ? "deadline" : "completion", remainingSecs };
                }
                return null;
              })
              .filter((alert): alert is NonNullable<typeof alert> => alert !== null);

            return (
              <div className={`px-2.5 py-1 rounded-full border text-[10px] font-mono flex items-center gap-1.5 ${
                activeAlerts.length > 0 
                  ? "bg-red-950/40 text-red-400 border-red-500/30 animate-pulse" 
                  : "bg-emerald-950/20 text-emerald-400 border-emerald-500/20"
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${activeAlerts.length > 0 ? "bg-red-400 animate-ping" : "bg-emerald-400"}`} />
                <span>{activeAlerts.length > 0 ? `${activeAlerts.length} ALERTS INSTANCED` : "SYSTEM SECURE"}</span>
              </div>
            );
          })()}
        </div>

        {/* Dynamic Holographic Alert Board */}
        {(() => {
          const activeAlerts = tasks
            .filter((task) => task.status === "running")
            .map((task) => {
              const remainingSecs = getRemainingSeconds(task.deadline);
              const isDeadlineApproaching = remainingSecs !== null && remainingSecs > 0 && remainingSecs <= 15;
              const isHighPriorityCompleting =
                (task.priority === "high" || task.priority === "critical") &&
                task.progress >= 85 &&
                task.progress < 100;

              if (isDeadlineApproaching || isHighPriorityCompleting) {
                return { task, type: isDeadlineApproaching ? "deadline" : "completion", remainingSecs };
              }
              return null;
            })
            .filter((alert): alert is NonNullable<typeof alert> => alert !== null);

          if (activeAlerts.length === 0) return null;

          return (
            <div className="mb-4 overflow-hidden">
              <div className="border border-red-500/35 bg-red-950/15 rounded-xl p-3 space-y-2">
                <div className="flex items-center gap-2 text-red-400 font-display text-[10px] font-bold tracking-widest uppercase mb-1 animate-pulse">
                  <AlertTriangle className="w-4 h-4 text-red-400 animate-bounce" />
                  <span>CRITICAL COGNITIVE ALERTS DETECTED</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-36 overflow-y-auto scrollbar-thin">
                  {activeAlerts.map(({ task, type, remainingSecs }) => (
                    <div
                      key={`${task.id}-${type}`}
                      className={`p-2.5 rounded-lg border flex items-start gap-2.5 font-mono text-[10px] ${
                        type === "deadline"
                          ? "bg-amber-950/30 border-amber-500/35 text-amber-300"
                          : "bg-purple-950/30 border-purple-500/35 text-purple-300"
                      }`}
                    >
                      {type === "deadline" ? (
                        <Flame className="w-4 h-4 text-amber-400 shrink-0 mt-0.5 animate-pulse" />
                      ) : (
                        <Zap className="w-4 h-4 text-purple-400 shrink-0 mt-0.5 animate-pulse" />
                      )}
                      <div className="flex-1 space-y-0.5 overflow-hidden">
                        <div className="font-bold flex items-center justify-between">
                          <span>
                            {type === "deadline" ? "DEADLINE IMMINENT" : "STAGE FINALIZATION"}
                          </span>
                          <span className={`px-1 text-[8px] border uppercase rounded ${
                            task.priority === "critical"
                              ? "bg-red-950 text-red-400 border-red-800"
                              : "bg-amber-950 text-amber-400 border-amber-800"
                          }`}>
                            {task.priority || "medium"}
                          </span>
                        </div>
                        <p className="text-slate-300 text-[10px] font-sans truncate">{task.name}</p>
                        <p className="text-[9px] text-slate-400/80">
                          {type === "deadline"
                            ? `⚠️ Force termination imminent in ${remainingSecs} seconds!`
                            : `⚡ Completion vector at ${task.progress}%. Buffer stabilized.`}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })()}

        {/* Category Filter Tabs */}
        <div className="flex items-center gap-1.5 mb-4 bg-slate-950/40 p-1.5 rounded-xl border border-cyan-500/15 overflow-x-auto shrink-0 scrollbar-none">
          <span className="text-[9px] font-mono text-cyan-500/50 uppercase tracking-widest pl-1.5 pr-2 border-r border-cyan-500/10 hidden sm:inline">Filter Category:</span>
          {["All", "Development", "Maintenance", "Research", "Personal", "Work"].map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-3 py-1 text-[10px] font-mono rounded-lg transition-all cursor-pointer shrink-0 ${
                filterCategory === cat
                  ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold shadow-[0_0_8px_rgba(6,182,212,0.15)]"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent"
              }`}
            >
              {cat.toUpperCase()}
            </button>
          ))}
        </div>

        {/* Task List Container */}
        <div className="flex-1 overflow-y-auto space-y-4 scrollbar-thin pr-1">
          {tasksLoading && tasks.length === 0 ? (
            <div className="flex items-center justify-center py-16 font-mono text-xs text-cyan-400 animate-pulse">
              SYNCING WITH SYSTEM PROCESSOR CORES...
            </div>
          ) : filteredTasks.length === 0 ? (
            <div className="text-center py-16 text-slate-500 font-mono text-xs">
              {tasks.length === 0 
                ? "No processes are currently cataloged in JARVIS central memory." 
                : `No tasks match the active '${filterCategory}' category filter.`}
            </div>
          ) : (
            filteredTasks.map((task) => {
              const remainingSecs = getRemainingSeconds(task.deadline);
              const isDeadlineApproaching = task.status === "running" && remainingSecs !== null && remainingSecs > 0 && remainingSecs <= 15;
              const isHighPriorityCompleting = task.status === "running" && 
                (task.priority === "high" || task.priority === "critical") && 
                task.progress >= 85 && task.progress < 100;

              let cardClasses = "";
              if (isDeadlineApproaching) {
                cardClasses = "bg-amber-950/15 border-amber-500/50 shadow-[0_0_15px_rgba(245,158,11,0.25)]";
              } else if (isHighPriorityCompleting) {
                cardClasses = "bg-purple-950/15 border-purple-500/50 shadow-[0_0_15px_rgba(168,85,247,0.25)]";
              } else if (task.status === "running") {
                cardClasses = "bg-cyan-950/10 border-cyan-500/25";
              } else if (task.status === "completed") {
                cardClasses = "bg-green-950/5 border-green-500/20 opacity-80";
              } else {
                cardClasses = "bg-red-950/5 border-red-500/20 opacity-80";
              }

              return (
                <div
                  key={task.id}
                  className={`p-4 rounded-xl border transition-all duration-300 ${cardClasses}`}
                >
                  {/* Header Information */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      {task.status === "running" ? (
                        <span className={`w-2 h-2 rounded-full ${isDeadlineApproaching ? "bg-amber-400 animate-ping" : "bg-cyan-400 animate-ping"}`}></span>
                      ) : task.status === "completed" ? (
                        <CheckCircle className="w-4 h-4 text-green-400 shrink-0" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                      )}
                      <h3 className="font-sans font-medium text-xs text-slate-200">{task.name}</h3>
                      <span className="text-[9px] font-mono bg-slate-950/60 border border-cyan-500/10 px-1.5 py-0.5 rounded text-cyan-400">
                        {task.type}
                      </span>
                      {task.priority && (() => {
                        const pri = task.priority.toLowerCase();
                        if (pri === "critical") {
                          return (
                            <span className="inline-flex items-center gap-1 text-[9px] font-mono uppercase px-2 py-0.5 rounded-md bg-red-950/60 text-red-400 border border-red-500/30 animate-pulse font-bold shadow-[0_0_8px_rgba(239,68,68,0.2)]">
                              <Flame className="w-3 h-3 text-red-400 shrink-0" />
                              <span>Critical</span>
                            </span>
                          );
                        }
                        if (pri === "high") {
                          return (
                            <span className="inline-flex items-center gap-1 text-[9px] font-mono uppercase px-2 py-0.5 rounded-md bg-amber-950/60 text-amber-400 border border-amber-500/30 font-semibold shadow-[0_0_6px_rgba(245,158,11,0.15)]">
                              <Zap className="w-2.5 h-2.5 text-amber-400 shrink-0" />
                              <span>High</span>
                            </span>
                          );
                        }
                        if (pri === "low") {
                          return (
                            <span className="inline-flex items-center gap-1 text-[9px] font-mono uppercase px-2 py-0.5 rounded-md bg-slate-900/80 text-slate-400 border border-slate-800">
                              <ChevronDown className="w-2.5 h-2.5 text-slate-400 shrink-0" />
                              <span>Low</span>
                            </span>
                          );
                        }
                        // Default to medium
                        return (
                          <span className="inline-flex items-center gap-1 text-[9px] font-mono uppercase px-2 py-0.5 rounded-md bg-cyan-950/60 text-cyan-400 border border-cyan-500/30">
                            <Activity className="w-2.5 h-2.5 text-cyan-400 shrink-0" />
                            <span>Medium</span>
                          </span>
                        );
                      })()}
                      {(() => {
                        const cat = (task.category || "Maintenance").toLowerCase();
                        let badgeStyle = "bg-slate-950/80 text-slate-400 border-slate-800";
                        if (cat === "development") {
                          badgeStyle = "bg-blue-950/80 text-blue-400 border-blue-500/35";
                        } else if (cat === "maintenance") {
                          badgeStyle = "bg-amber-950/80 text-amber-400 border-amber-500/35";
                        } else if (cat === "research") {
                          badgeStyle = "bg-emerald-950/80 text-emerald-400 border-emerald-500/35";
                        } else if (cat === "personal") {
                          badgeStyle = "bg-purple-950/80 text-purple-400 border-purple-500/35";
                        } else if (cat === "work") {
                          badgeStyle = "bg-indigo-950/80 text-indigo-400 border-indigo-500/35";
                        }
                        return (
                          <span className={`text-[8px] font-mono uppercase px-1.5 py-0.5 rounded border ${badgeStyle}`}>
                            {task.category || "Maintenance"}
                          </span>
                        );
                      })()}
                    </div>

                    <div className="flex items-center gap-3">
                      {task.status === "running" && task.deadline && (
                        <span className={`flex items-center gap-1 text-[9px] font-mono px-1.5 py-0.5 rounded border ${
                          isDeadlineApproaching 
                            ? "bg-red-950/80 text-red-400 border-red-500/40 animate-pulse font-bold" 
                            : "bg-slate-950/80 text-amber-400 border-amber-500/20"
                        }`}>
                          <Clock className={`w-2.5 h-2.5 ${isDeadlineApproaching ? "animate-spin" : ""}`} />
                          <span>DL: {remainingSecs !== null && remainingSecs > 0 ? `${remainingSecs}s` : "Overrun"}</span>
                        </span>
                      )}

                      <span className="flex items-center gap-1 text-[9px] font-mono text-slate-500">
                        <Clock className="w-3 h-3" />
                        {new Date(task.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                      </span>

                      {/* Quick Core Actions */}
                      <div className="flex items-center gap-1.5">
                        {task.status === "running" && (
                          <button
                            onClick={() => cancelTask(task.id)}
                            className="px-2 py-0.5 text-[9px] font-mono border border-red-500/40 hover:border-red-400 bg-red-950/10 hover:bg-red-900/20 text-red-400 rounded transition-colors cursor-pointer"
                            title="Terminate process"
                          >
                            KILL
                          </button>
                        )}
                        {(task.status === "completed" || task.status === "failed") && (
                          <button
                            onClick={() => retryTask(task.id)}
                            className="px-2 py-0.5 text-[9px] font-mono border border-cyan-500/40 hover:border-cyan-400 bg-cyan-950/10 hover:bg-cyan-900/20 text-cyan-400 rounded transition-colors cursor-pointer flex items-center gap-1"
                            title="Retry process"
                          >
                            <RotateCcw className="w-2.5 h-2.5" />
                            <span>RETRY</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Visual Alerts Warning inside Card */}
                  {isDeadlineApproaching && (
                    <div className="mb-3 flex items-center gap-2 px-3 py-1.5 bg-red-950/40 border border-red-500/30 rounded-lg text-red-400 text-[10px] font-mono animate-pulse">
                      <AlertCircle className="w-3.5 h-3.5 animate-bounce text-red-400 shrink-0" />
                      <span className="font-bold truncate">SYSTEM THREAT: TIMESTEP OVERRUN IMMINENT — TERMINATION IN {remainingSecs}S</span>
                    </div>
                  )}

                  {isHighPriorityCompleting && (
                    <div className="mb-3 flex items-center gap-2 px-3 py-1.5 bg-purple-950/40 border border-purple-500/30 rounded-lg text-purple-300 text-[10px] font-mono animate-pulse">
                      <Zap className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                      <span className="truncate">COGNITIVE PIPELINE: HIGH-PRIORITY PROCESS NEARLY COMPLETE ({task.progress}%)</span>
                    </div>
                  )}

                  {/* Progress Bar Container */}
                  <div className="mb-3.5">
                    <div className="flex justify-between text-[9px] font-mono text-slate-500 mb-1">
                      <span>PROGRESS_VECTOR</span>
                      <span className={task.status === "running" ? (isDeadlineApproaching ? "text-amber-400 font-bold" : isHighPriorityCompleting ? "text-purple-400 font-bold" : "text-cyan-400 font-bold") : task.status === "completed" ? "text-green-400" : "text-red-400"}>
                        {task.progress}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-950 border border-cyan-500/10 h-2.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-1000 ${
                          isDeadlineApproaching
                            ? "bg-gradient-to-r from-amber-500 to-red-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]"
                            : isHighPriorityCompleting
                            ? "bg-gradient-to-r from-purple-500 to-indigo-500 shadow-[0_0_8px_rgba(168,85,247,0.5)] animate-pulse"
                            : task.status === "running"
                            ? "bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.5)]"
                            : task.status === "completed"
                            ? "bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]"
                            : "bg-red-500"
                        }`}
                        style={{ width: `${task.progress}%` }}
                      />
                    </div>
                  </div>

                  {/* Terminal Sub-Logs */}
                  <div className="bg-slate-950/90 border border-cyan-500/5 rounded-lg p-2 font-mono text-[9px] text-slate-400/90 space-y-1 max-h-24 overflow-y-auto scrollbar-none">
                    <div className="flex items-center gap-1.5 text-cyan-500/60 border-b border-cyan-500/5 pb-1 mb-1">
                      <Terminal className="w-3 h-3 text-cyan-400 shrink-0" />
                      <span>PROCESSOR_LOG_STREAM</span>
                    </div>
                    {task.logs.map((log, idx) => (
                      <div key={idx} className="flex items-start gap-1.5">
                        <span className="text-cyan-400 shrink-0">❯</span>
                        <span>{log}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
