/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { useJarvisStore } from "../stores/jarvisStore";
import { motion } from "motion/react";
import { 
  Folder, 
  Upload, 
  Trash2, 
  Download, 
  Eye, 
  Search, 
  FileText, 
  FileCode, 
  FileArchive, 
  File, 
  HardDrive,
  Plus,
  ArrowUp,
  X,
  MessageSquare,
  Cpu
} from "lucide-react";

export default function FilesTab() {
  const { 
    files, 
    filesLoading, 
    fetchFiles, 
    uploadFile, 
    deleteFile,
    conversations,
    diagnosticsReport,
    systemStatus,
    addToast
  } = useJarvisStore();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const [previewContent, setPreviewContent] = useState<string | null>(null);
  const [previewName, setPreviewName] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    fetchFiles();
  }, []);

  const downloadFile = (content: string, fileName: string, contentType: string) => {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleExportChatJson = () => {
    if (!conversations || conversations.length === 0) {
      addToast("No conversation logs found to export, Sir.", "warning");
      return;
    }
    const jsonStr = JSON.stringify(conversations, null, 2);
    downloadFile(jsonStr, `jarvis_chat_telemetry_${Date.now()}.json`, "application/json");
    addToast("Chat logs compiled and downloaded as structured JSON, Sir.", "success");
  };

  const handleExportChatTxt = () => {
    if (!conversations || conversations.length === 0) {
      addToast("No conversation logs found to export, Sir.", "warning");
      return;
    }
    let txtContent = `========================================================================
                      JARVIS CHAT TELEMETRY LOGS
========================================================================
GENERATED AT: ${new Date().toISOString()}
TOTAL ACTIVE ARCHIVES: ${conversations.length}
========================================================================\n\n`;

    conversations.forEach((conv, index) => {
      txtContent += `[CONVERSATION #${index + 1}: ${conv.title.toUpperCase()}]\n`;
      txtContent += `ID: ${conv.id}\n`;
      txtContent += `FOLDER: ${conv.folder || "UNSORTED"}\n`;
      txtContent += `CREATED AT: ${new Date(conv.createdAt).toLocaleString()}\n`;
      txtContent += `PINNED STATUS: ${conv.pin ? "PINNED" : "UNPINNED"}\n`;
      txtContent += `------------------------------------------------------------------------\n`;
      
      if (conv.messages.length === 0) {
        txtContent += `[NO MESSAGE TRANSMISSIONS RECORDED]\n`;
      } else {
        conv.messages.forEach((msg) => {
          const time = new Date(msg.timestamp).toLocaleString();
          const sender = msg.role === "user" ? "USER" : "JARVIS";
          txtContent += `[${time}] ${sender}:\n`;
          txtContent += `${msg.content}\n\n`;
        });
      }
      txtContent += `========================================================================\n\n`;
    });

    downloadFile(txtContent, `jarvis_chat_telemetry_${Date.now()}.txt`, "text/plain");
    addToast("Chat logs compiled and downloaded as plaintext archive, Sir.", "success");
  };

  const handleExportDiagnosticsJson = () => {
    let diagData: any = {};
    if (diagnosticsReport) {
      diagData = {
        timestamp: new Date().toISOString(),
        source: "ACTIVE_DIAGNOSTIC_RUN",
        report: diagnosticsReport,
        systemStatus: systemStatus
      };
    } else {
      diagData = {
        timestamp: new Date().toISOString(),
        source: "BASELINE_SYSTEM_METRICS",
        systemStatus: systemStatus
      };
    }
    const jsonStr = JSON.stringify(diagData, null, 2);
    downloadFile(jsonStr, `jarvis_diagnostics_telemetry_${Date.now()}.json`, "application/json");
    addToast("Diagnostic telemetry downloaded as JSON payload, Sir.", "success");
  };

  const handleExportDiagnosticsTxt = () => {
    let txtContent = `========================================================================
                      JARVIS DIAGNOSTIC BLUEPRINTS
========================================================================
GENERATED AT: ${new Date().toISOString()}
========================================================================\n\n`;

    if (diagnosticsReport) {
      txtContent += `[ACTIVE DIAGNOSTIC SWEEP REPORT]\n`;
      txtContent += `------------------------------------------------------------------------\n`;
      txtContent += diagnosticsReport;
      txtContent += `\n------------------------------------------------------------------------\n`;
    } else {
      txtContent += `[BASELINE SYSTEM RECONNAISSANCE REPORT]\n`;
      txtContent += `No explicit diagnostic override was actively cached during this session.\n`;
      txtContent += `Compiling fallback system status logs:\n\n`;
    }

    if (systemStatus) {
      txtContent += `[CORE SYSTEM INTEGRITY METRICS]\n`;
      txtContent += `STATUS: ${systemStatus.status?.toUpperCase() || "SECURED"}\n`;
      txtContent += `ACTIVE ENCRYPTION KEYS: ${systemStatus.activeKey ? "VERIFIED" : "UNSECURED"}\n`;
      txtContent += `UPTIME: ${systemStatus.uptime} seconds\n`;
      txtContent += `ACTIVE COROUTINE PROCESSES: ${systemStatus.activeTasksCount}\n\n`;

      if (systemStatus.serverMetrics) {
        txtContent += `[HARDWARE TELEMETRY]\n`;
        txtContent += `- CPU Utilization: ${systemStatus.serverMetrics.cpu}%\n`;
        txtContent += `- RAM Utilization: ${systemStatus.serverMetrics.ram}%\n`;
        txtContent += `- GPU Acceleration: ${systemStatus.serverMetrics.gpu}%\n`;
        txtContent += `- Thermal Register: ${systemStatus.serverMetrics.temperature}\n`;
        txtContent += `- Network Throughput: ${systemStatus.serverMetrics.networkSpeed}\n`;
        txtContent += `- Auxiliary Power Level: ${systemStatus.serverMetrics.battery}%\n\n`;
      }

      if (systemStatus.diagnostics) {
        txtContent += `[SUBSYSTEM COMPLIANCE STATUS]\n`;
        txtContent += `- System Integrity Check: ${systemStatus.diagnostics.integrity || "OPTIMAL"}\n`;
        if (systemStatus.diagnostics.subsystems) {
          txtContent += `- Hologrid Core Matrix: ${systemStatus.diagnostics.subsystems.hologrid || "OPERATIONAL"}\n`;
          txtContent += `- Arc Core Flux Chamber: ${systemStatus.diagnostics.subsystems.arcCore || "BALANCED"}\n`;
          txtContent += `- Central Mainframe Grid: ${systemStatus.diagnostics.subsystems.mainframe || "STABLE"}\n`;
          txtContent += `- Sentinel Defense Protocol: ${systemStatus.diagnostics.subsystems.sentinel || "ACTIVE"}\n`;
        }
      }
    } else {
      txtContent += `\n[MAINBOARD UNREACHABLE]\n`;
      txtContent += `Telemetry channel is offline. Direct mainframe connection required.\n`;
    }

    txtContent += `\n========================================================================\n`;
    txtContent += `Audit sweep fully compliant with Jarvis Security Protocols.\n`;
    txtContent += `========================================================================\n`;

    downloadFile(txtContent, `jarvis_diagnostics_report_${Date.now()}.txt`, "text/plain");
    addToast("Diagnostic report compiled and downloaded as plaintext log, Sir.", "success");
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await processUpload(file);
    }
  };

  const processUpload = async (file: File) => {
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64Data = reader.result as string;
      try {
        await uploadFile(file.name, file.type, base64Data);
        fetchFiles();
      } catch (err) {
        console.error("Upload process error:", err);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      await processUpload(file);
    }
  };

  const handlePreviewFile = async (fRecord: any) => {
    // If it is a text-like file, read it (since we can read directly or mock read of simple strings!)
    setPreviewName(fRecord.name);
    // Let's check extension
    const ext = fRecord.name.split(".").pop()?.toLowerCase();
    const textLike = ["txt", "json", "js", "ts", "css", "html", "md", "csv"];
    if (textLike.includes(ext || "")) {
      setPreviewContent(`[OMEGA SECURE STORAGE DECRYPTION COMPLETED]
=========================================
SOURCE: ${fRecord.name}
ID: ${fRecord.id}
TIMESTAMP: ${fRecord.timestamp}
=========================================

System simulation data placeholder for visual presentation:
{
  "integrity": "SECURED",
  "blueprint": "Omega Core Microservices Blueprint",
  "thermalLoad": "Optimal",
  "fluxEfficiency": 0.9982,
  "arcPowerDraw": "1.2 GW"
}`);
    } else {
      setPreviewContent(`[BINARY FILE DECRYPTION EXCEPTION]
=========================================
SOURCE: ${fRecord.name}
FORMAT: Binary stream [.${ext?.toUpperCase()}]
=========================================

Sir, this is a compiled binary payload. Decrypting raw binary structures on this holographic display grid may overload the terminal buffers. 

Please select 'Download' from the main control console to retrieve the intact payload.`);
    }
  };

  const filteredFiles = files.filter((f) =>
    f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getFileIcon = (fileName: string) => {
    const ext = fileName.split(".").pop()?.toLowerCase();
    if (["txt", "md"].includes(ext || "")) return <FileText className="w-8 h-8 text-cyan-400" />;
    if (["js", "ts", "html", "css", "json", "tsx", "py"].includes(ext || "")) return <FileCode className="w-8 h-8 text-yellow-400" />;
    if (["zip", "tar", "gz", "rar"].includes(ext || "")) return <FileArchive className="w-8 h-8 text-purple-400" />;
    return <File className="w-8 h-8 text-slate-400" />;
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  const holographicContainerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const holographicSectionVariants = {
    hidden: { 
      opacity: 0, 
      y: 20,
      filter: "hue-rotate(-15deg) brightness(1.3) contrast(1.1) drop-shadow(0 0 12px rgba(6,182,212,0.4))",
    },
    visible: { 
      opacity: 1, 
      y: 0,
      filter: "hue-rotate(0deg) brightness(1) contrast(1) drop-shadow(0 0 0px rgba(0,0,0,0))",
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15,
      },
    },
  };

  return (
    <div className="relative overflow-hidden w-full h-full rounded-2xl p-0.5">
      {/* Holographic Scanline Animations */}
      <div className="holographic-grid-overlay rounded-2xl" />
      <div className="holographic-sweep" />

      <motion.div
        id="jarvis_files_tab"
        initial="hidden"
        animate="visible"
        variants={holographicContainerVariants}
        className="grid grid-cols-1 lg:grid-cols-4 gap-4 overflow-visible lg:overflow-hidden h-auto lg:h-[550px] xl:h-full relative z-10"
      >
        {/* Side Upload Drag-And-Drop Panel */}
        <motion.div
          variants={holographicSectionVariants}
          className="lg:col-span-1 flex flex-col gap-4 h-auto lg:h-full overflow-y-auto lg:overflow-hidden"
        >
        {/* Holographic Disk Storage Details */}
        <div className="glassmorphism rounded-xl border border-cyan-500/20 p-4">
          <div className="flex items-center gap-2 mb-3.5">
            <HardDrive className="w-4 h-4 text-cyan-400" />
            <h3 className="font-display font-medium text-sm text-slate-200 uppercase tracking-widest">Core Storage</h3>
          </div>
          <div className="space-y-3.5">
            <div>
              <div className="flex justify-between text-[10px] font-mono text-slate-500 mb-1">
                <span>SECTOR_FILL_LEVEL</span>
                <span className="text-cyan-400">12.4% USED</span>
              </div>
              <div className="w-full bg-slate-950 border border-cyan-500/15 h-2 rounded-full overflow-hidden">
                <div className="bg-cyan-400 h-full rounded-full" style={{ width: "12.4%" }} />
              </div>
            </div>
            <div className="font-mono text-[10px] text-slate-400 space-y-1.5 pt-1">
              <div className="flex justify-between">
                <span>Allocated Capacity:</span>
                <span className="text-slate-300">512 TB</span>
              </div>
              <div className="flex justify-between">
                <span>Free Space:</span>
                <span className="text-slate-300">448.5 TB</span>
              </div>
              <div className="flex justify-between">
                <span>File Counts:</span>
                <span className="text-cyan-400">{files.length} registers</span>
              </div>
            </div>
          </div>
        </div>

        {/* Telemetry Exporters */}
        <div className="glassmorphism rounded-xl border border-cyan-500/20 p-4 flex flex-col gap-3">
          <div className="flex items-center gap-2 pb-2 border-b border-cyan-500/10">
            <Download className="w-4 h-4 text-cyan-400 animate-pulse" />
            <h3 className="font-display font-medium text-xs text-slate-200 uppercase tracking-widest">Telemetry Exporter</h3>
          </div>
          
          <div className="space-y-3">
            {/* Chat History Exporter */}
            <div className="space-y-1.5">
              <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400 uppercase">
                <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
                <span>Chat History Logs</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleExportChatJson}
                  className="px-2 py-1 bg-slate-950 border border-cyan-500/20 hover:border-cyan-400 hover:bg-cyan-950/20 text-[9px] font-mono font-semibold text-cyan-400 rounded-lg flex items-center justify-center gap-1 transition-all cursor-pointer"
                  title="Export active chat logs as structured JSON"
                >
                  <FileCode className="w-3 h-3" />
                  <span>JSON</span>
                </button>
                <button
                  onClick={handleExportChatTxt}
                  className="px-2 py-1 bg-slate-950 border border-cyan-500/20 hover:border-cyan-400 hover:bg-cyan-950/20 text-[9px] font-mono font-semibold text-cyan-400 rounded-lg flex items-center justify-center gap-1 transition-all cursor-pointer"
                  title="Export active chat logs as plaintext document"
                >
                  <FileText className="w-3 h-3" />
                  <span>TEXT</span>
                </button>
              </div>
            </div>

            {/* Diagnostics Exporter */}
            <div className="space-y-1.5 pt-1.5 border-t border-cyan-500/5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400 uppercase">
                  <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                  <span>System Diagnostics</span>
                </div>
                {diagnosticsReport ? (
                  <span className="text-[7px] font-mono px-1 bg-green-500/15 border border-green-500/25 text-green-400 rounded uppercase">Active Run</span>
                ) : (
                  <span className="text-[7px] font-mono px-1 bg-amber-500/15 border border-amber-500/25 text-amber-400 rounded uppercase">Baseline</span>
                )}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleExportDiagnosticsJson}
                  className="px-2 py-1 bg-slate-950 border border-cyan-500/20 hover:border-cyan-400 hover:bg-cyan-950/20 text-[9px] font-mono font-semibold text-cyan-400 rounded-lg flex items-center justify-center gap-1 transition-all cursor-pointer"
                  title="Export mainframe diagnostics as JSON payload"
                >
                  <FileCode className="w-3 h-3" />
                  <span>JSON</span>
                </button>
                <button
                  onClick={handleExportDiagnosticsTxt}
                  className="px-2 py-1 bg-slate-950 border border-cyan-500/20 hover:border-cyan-400 hover:bg-cyan-950/20 text-[9px] font-mono font-semibold text-cyan-400 rounded-lg flex items-center justify-center gap-1 transition-all cursor-pointer"
                  title="Export mainframe diagnostics as formatted report"
                >
                  <FileText className="w-3 h-3" />
                  <span>TEXT</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Upload Drop Zone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`flex-1 flex flex-col items-center justify-center border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
            isDragging
              ? "bg-cyan-950/20 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.15)]"
              : "border-cyan-500/25 bg-slate-950/30 hover:border-cyan-500/50 hover:bg-cyan-950/5"
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            className="hidden"
          />
          <div className="w-12 h-12 rounded-full bg-cyan-950/15 border border-cyan-500/20 flex items-center justify-center mb-4 text-cyan-400 group-hover:scale-110 transition-transform">
            <Upload className="w-5 h-5 animate-pulse" />
          </div>
          <h4 className="font-display font-medium text-xs text-slate-200 tracking-wide uppercase">Deploy Source Files</h4>
          <p className="text-[9px] font-mono text-slate-500 mt-2 leading-relaxed">
            Drag files here or tap to parse telemetry payload files locally.
          </p>
        </div>
        </motion.div>

        {/* Main Files Directory */}
        <motion.div
          variants={holographicSectionVariants}
          className="lg:col-span-3 flex flex-col glassmorphism rounded-xl border border-cyan-500/20 p-4 h-[480px] lg:h-full overflow-hidden"
        >
        {/* Header toolbar */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <Folder className="w-5 h-5 text-cyan-400 animate-pulse" />
            <div>
              <h2 className="font-display text-sm font-semibold text-slate-100 tracking-wider uppercase">File Repositories</h2>
              <p className="text-[10px] text-slate-500 font-mono">SECURED ENCRYPTED BLUEPRINT STORAGE ARCHIVES</p>
            </div>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-cyan-500/50" />
            <input
              type="text"
              placeholder="Search file database..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950/80 border border-cyan-500/20 rounded-lg pl-9 pr-3 py-1.5 font-sans text-xs text-slate-200 placeholder-cyan-500/40 focus:outline-none focus:border-cyan-400 transition-colors"
            />
          </div>
        </div>

        {/* Files Grid Grid */}
        <div className="flex-1 overflow-y-auto space-y-2 scrollbar-thin pr-1">
          {filesLoading && files.length === 0 ? (
            <div className="flex items-center justify-center py-16 font-mono text-xs text-cyan-400 animate-pulse">
              MOUNTING SECURE FILER CHANNELS...
            </div>
          ) : filteredFiles.length === 0 ? (
            <div className="text-center py-16 text-slate-500 font-mono text-xs">
              No files are currently recorded inside this repository sector.
            </div>
          ) : (
            filteredFiles.map((f) => (
              <div
                key={f.id}
                className="flex items-center justify-between p-3 border border-cyan-500/10 rounded-xl bg-slate-950/60 hover:bg-slate-950/90 hover:border-cyan-500/30 transition-all group"
              >
                <div className="flex items-center gap-3 w-[70%]">
                  <div className="flex-shrink-0">
                    {getFileIcon(f.name)}
                  </div>
                  <div className="overflow-hidden">
                    <h4 className="text-xs font-medium text-slate-200 truncate group-hover:text-cyan-400 transition-colors">
                      {f.name}
                    </h4>
                    <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500 mt-1">
                      <span>{formatSize(f.size)}</span>
                      <span>•</span>
                      <span>{f.type.split("/")[1] || "BINARY"}</span>
                      <span>•</span>
                      <span>{new Date(f.timestamp).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                {/* Operations */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handlePreviewFile(f)}
                    className="p-1.5 rounded-lg border border-cyan-500/20 hover:border-cyan-400 bg-cyan-950/10 text-cyan-400 hover:bg-cyan-900/20 transition-all cursor-pointer"
                    title="View file details"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                  <a
                    href={f.url}
                    download={f.name}
                    className="p-1.5 rounded-lg border border-cyan-500/20 hover:border-cyan-400 bg-cyan-950/10 text-cyan-400 hover:bg-cyan-900/20 transition-all flex items-center justify-center cursor-pointer"
                    title="Download file payload"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </a>
                  <button
                    onClick={() => deleteFile(f.id)}
                    className="p-1.5 rounded-lg border border-red-500/10 hover:border-red-400 bg-red-950/5 text-slate-500 hover:text-red-400 transition-all cursor-pointer"
                    title="Erase registry"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </motion.div>

      {/* Decrypted File Preview Modal overlay */}
      {previewContent && (
        <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-2xl bg-slate-950 border border-cyan-400 rounded-xl overflow-hidden flex flex-col h-[80%] shadow-2xl shadow-cyan-950/50 animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-cyan-500/20 bg-slate-900">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-cyan-400" />
                <span className="font-display text-xs font-semibold text-slate-200 truncate">{previewName}</span>
              </div>
              <button
                onClick={() => setPreviewContent(null)}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            {/* Scrollable file data */}
            <div className="flex-1 p-4 overflow-y-auto font-mono text-[10px] text-cyan-400/90 bg-black/60 scrollbar-thin">
              <pre className="whitespace-pre-wrap leading-relaxed">{previewContent}</pre>
            </div>
            {/* Footer */}
            <div className="px-4 py-2 bg-slate-900 border-t border-cyan-500/20 flex justify-end">
              <button
                onClick={() => setPreviewContent(null)}
                className="px-4 py-1.5 border border-cyan-400 text-cyan-400 hover:bg-cyan-500 hover:text-slate-950 font-display font-medium text-xs rounded transition-all cursor-pointer"
              >
                CLOSE GRID
              </button>
            </div>
          </div>
        </div>
      )}
      </motion.div>
    </div>
  );
}
