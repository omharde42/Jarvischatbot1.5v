import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Global error handling to catch and log WebSocket HMR connection issues gracefully
if (typeof window !== "undefined") {
  window.addEventListener("unhandledrejection", (event) => {
    const reason = event.reason;
    const msg = reason?.message || String(reason);
    if (msg.includes("WebSocket") || msg.includes("HMR") || msg.includes("websocket")) {
      console.warn("[Vite HMR Telemetry] WebSocket connection warning captured gracefully:", msg);
      event.preventDefault(); // Swallows the unhandled promise rejection error while logging it elegantly
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
