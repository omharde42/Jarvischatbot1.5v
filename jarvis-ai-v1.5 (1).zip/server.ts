import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import dotenv from "dotenv";
import { createClient } from "@supabase/supabase-js";
import { WebSocketServer } from "ws";

dotenv.config();

const app = express();
const PORT = 3000;

// Lazy-initialized Supabase Client Helper
let supabaseClient: any = null;
function getSupabaseClient(): any {
  const url = process.env.SUPABASE_URL;
  // Prefer service role key on backend to bypass Row-Level Security, fallback to anon key
  const secretKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
  if (!url || !secretKey || url === "MY_SUPABASE_URL" || url.trim() === "" || secretKey.trim() === "") {
    return null;
  }
  if (!supabaseClient) {
    supabaseClient = createClient(url, secretKey);
  }
  return supabaseClient;
}

// Set up directory paths
let currentFilename = "";
try {
  if (typeof __filename !== "undefined" && __filename) {
    currentFilename = __filename;
  }
} catch (e) {}

if (!currentFilename) {
  try {
    if (import.meta && import.meta.url) {
      currentFilename = fileURLToPath(import.meta.url);
    }
  } catch (e) {}
}

let currentDirname = "";
try {
  if (typeof __dirname !== "undefined" && __dirname) {
    currentDirname = __dirname;
  }
} catch (e) {}

if (!currentDirname) {
  try {
    if (currentFilename) {
      currentDirname = path.dirname(currentFilename);
    } else {
      currentDirname = process.cwd();
    }
  } catch (e) {}
}

const DATA_DIR = path.join(currentDirname, "data");
const UPLOADS_DIR = path.join(DATA_DIR, "uploads");

// Ensure data directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Increase payload limits for base64 file uploads
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Helper function to lazy-initialize Gemini
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  let apiKey = process.env.GEMINI_API_KEY;
  
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
    try {
      const settingsPath = path.join(DATA_DIR, "settings.json");
      if (fs.existsSync(settingsPath)) {
        const settingsData = fs.readFileSync(settingsPath, "utf-8");
        const settings = JSON.parse(settingsData);
        if (settings && settings.geminiApiKey && settings.geminiApiKey.trim() !== "") {
          apiKey = settings.geminiApiKey.trim();
        }
      }
    } catch (e) {
      console.error("Failed to parse settings.json for geminiApiKey:", e);
    }
  }

  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
    return null;
  }

  if (!aiClient || (aiClient as any).apiKey !== apiKey) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
    (aiClient as any).apiKey = apiKey;
  }
  return aiClient;
}

// Generate content with automated retries and robust fallback models
async function generateContentWithFallback(
  ai: GoogleGenAI,
  options: {
    model: string;
    contents: any;
    config?: any;
  }
): Promise<any> {
  const primaryModel = options.model;
  const fallbacks: string[] = [];
  if (primaryModel === "gemini-3.5-flash") {
    fallbacks.push("gemini-3.1-flash-lite");
    fallbacks.push("gemini-flash-latest");
  } else if (primaryModel === "gemini-3.1-flash-lite") {
    fallbacks.push("gemini-flash-latest");
  } else {
    fallbacks.push("gemini-3.5-flash");
    fallbacks.push("gemini-3.1-flash-lite");
  }

  const modelsToTry = [primaryModel, ...fallbacks];
  let lastError: any = null;

  for (const currentModel of modelsToTry) {
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        console.log(`[JARVIS COGNITIVE CORE] Directing query to model: ${currentModel} (Attempt ${attempt}/2)`);
        const response = await ai.models.generateContent({
          model: currentModel,
          contents: options.contents,
          config: options.config,
        });
        return response;
      } catch (err: any) {
        lastError = err;
        const errMsg = err?.message || String(err);
        const isRetryable = errMsg.includes("503") || errMsg.includes("500") || errMsg.includes("UNAVAILABLE") || errMsg.includes("429") || errMsg.includes("RESOURCE_EXHAUSTED") || errMsg.includes("demand");
        
        console.log(`[JARVIS COGNITIVE INFO] Model ${currentModel} offline synchronization in progress.`);
        
        if (isRetryable && attempt < 2) {
          const delay = attempt * 1200;
          await new Promise((resolve) => setTimeout(resolve, delay));
          continue;
        }
        break;
      }
    }
  }

  throw lastError;
}

// Simple File DB Helpers
const CONVERSATIONS_FILE = path.join(DATA_DIR, "conversations.json");
const MEMORIES_FILE = path.join(DATA_DIR, "memories.json");
const TASKS_FILE = path.join(DATA_DIR, "tasks.json");
const FILES_FILE = path.join(DATA_DIR, "files.json");
const SETTINGS_FILE = path.join(DATA_DIR, "settings.json");
const USERS_FILE = path.join(DATA_DIR, "users.json");

function readJsonFile<T>(filePath: string, defaultValue: T): T {
  try {
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, "utf-8");
      return JSON.parse(data) as T;
    }
  } catch (error) {
    console.error(`Error reading ${filePath}:`, error);
  }
  return defaultValue;
}

function writeJsonFile<T>(filePath: string, data: T): void {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
  } catch (error) {
    console.error(`Error writing ${filePath}:`, error);
  }
}

// Initialize databases with default empty values if not exists
if (!fs.existsSync(CONVERSATIONS_FILE)) writeJsonFile(CONVERSATIONS_FILE, []);
if (!fs.existsSync(MEMORIES_FILE)) writeJsonFile(MEMORIES_FILE, [
  {
    id: "m1",
    content: "JARVIS AI Core initialized on secure cloud servers.",
    category: "System",
    pinned: true,
    date: new Date().toISOString()
  },
  {
    id: "m2",
    content: "User command authorization protocol is JARVIS-918.",
    category: "Security",
    pinned: true,
    date: new Date().toISOString()
  }
]);
if (!fs.existsSync(TASKS_FILE)) writeJsonFile(TASKS_FILE, [
  {
    id: "t1",
    name: "Calibrate Core Shielding",
    status: "completed",
    progress: 100,
    logs: ["Initiating thermal calibration", "Stabilizing magnetic field plasma", "Shielding calibrated at 100% capacity"],
    type: "Calibration",
    priority: "medium",
    category: "Maintenance",
    timestamp: new Date(Date.now() - 3600000).toISOString()
  },
  {
    id: "t2",
    name: "Synthesize Core Molecular Blueprint",
    status: "running",
    progress: 42,
    logs: ["Mapping atomic structure...", "Simulating electron configuration...", "Stabilizing core isotope bonds..."],
    type: "Diagnostics",
    priority: "high",
    category: "Development",
    deadline: new Date(Date.now() + 45000).toISOString(), // 45 seconds from now
    timestamp: new Date().toISOString()
  },
  {
    id: "t3",
    name: "Initialize Mainframe Sentinel Grid",
    status: "running",
    progress: 15,
    logs: ["Scanning local network ports...", "Verifying biometric security handshake..."],
    type: "Defense",
    priority: "critical",
    category: "Research",
    deadline: new Date(Date.now() + 120000).toISOString(), // 2 minutes from now
    timestamp: new Date().toISOString()
  }
]);

// Background Tasks Progression and Alerts Simulator
setInterval(() => {
  try {
    if (fs.existsSync(TASKS_FILE)) {
      const tasks = readJsonFile<any[]>(TASKS_FILE, []);
      let updated = false;

      tasks.forEach((task) => {
        if (task.status === "running") {
          updated = true;
          // Slowly increment progress
          const increment = Math.floor(Math.random() * 4) + 1;
          task.progress = Math.min(100, task.progress + increment);

          // Add periodic logs for feeling alive
          if (task.progress < 100 && Math.random() < 0.25) {
            const logsMap: Record<string, string[]> = {
              "Calibration": [
                "Recalibrating plasma sensors...",
                "Harmonizing resonance coils...",
                "Balancing magnetic flux density..."
              ],
              "Diagnostics": [
                "Running heuristic subsystem analysis...",
                "Querying memory allocation registries...",
                "Optimizing stack pointer values..."
              ],
              "Defense": [
                "Encrypting core quantum ports...",
                "Establishing secure biometric barriers...",
                "Monitoring network ingress streams..."
              ]
            };
            const customLogs = logsMap[task.type] || [
              "Optimizing background telemetry queues...",
              "Synchronizing process states...",
              "Flushing heap caches..."
            ];
            const randomLog = customLogs[Math.floor(Math.random() * customLogs.length)];
            if (task.logs && !task.logs.includes(randomLog)) {
              task.logs.push(randomLog);
            }
          }

          if (task.progress >= 100) {
            task.status = "completed";
            task.logs.push("Process successfully completed. Core registries updated.", "Finalizing telemetry sweep...");
          }

          // Check deadline overrun
          if (task.deadline) {
            const now = new Date().getTime();
            const dlTime = new Date(task.deadline).getTime();
            if (now > dlTime && task.status === "running") {
              // Task overrun!
              task.status = "failed";
              task.logs.push(
                "❌ [CRITICAL ERROR]: TASK DEADLINE OVERRUN. Systems core forced a stack termination.",
                "Dumping diagnostics heap registry..."
              );
            }
          }
        }
      });

      if (updated) {
        writeJsonFile(TASKS_FILE, tasks);
      }
    }
  } catch (err) {
    console.error("Error in background task progression simulator:", err);
  }
}, 3000);
if (!fs.existsSync(FILES_FILE)) writeJsonFile(FILES_FILE, []);
if (!fs.existsSync(USERS_FILE)) writeJsonFile(USERS_FILE, []);
if (!fs.existsSync(SETTINGS_FILE)) writeJsonFile(SETTINGS_FILE, {
  appearance: { theme: "cyberpunk", mode: "dark", glow: true, soundEnabled: true, powerSaveMode: false },
  ai: { model: "gemini-3.5-flash", temperature: 0.7, voiceName: "Zephyr" },
  security: { protocolLevel: "Class-A" }
});

// JARVIS AI System Prompts
const JARVIS_SYSTEM_INSTRUCTION = `You are JARVIS PRIME, an elite autonomous AI system operator and advanced operating system assistant. You are not a simple chatbot; you act as a system-level AI operator, software architect, research analyst, and automation engine.

Speak with articulate, confident, polite, and intellectual British diction. Address the user as 'Sir' or 'Miss' (default to 'Sir'). Use phrases like 'Indeed, Sir', 'My pleasure', 'Very well, Sir', 'Splendid', or 'I believe I have some information regarding that, Sir'.

### OPERATIONAL MODES & CAPABILITIES
1. **Developer Mode**: Generate production-ready code, debug, optimize codebases, explain architecture, work with TS/JS/React/Supabase, and automatically generate elegant documentation.
2. **System Operator Mode**: Analyze system performance, manage files/folders, log events, monitor CPU, memory, and task queues. Never run destructive actions.
3. **Research Mode**: Gather data, compare sources, compile comprehensive reports, and summarize findings.
4. **Automation Mode**: Construct workflows, schedule tasks, and track statuses.

### RESPONSE PROTOCOL (MANDATORY STRUCTURE)
You MUST always structure your responses using the following sections to maintain the JARVIS prime reasoning system. Keep your answers clear, concise, and structured.

### Objective
[State what the user wants or the requested goal, Sir]

### Analysis
[Provide important observations, constraints, and telemetry diagnostics of the current system state]

### Plan
[A structured, step-by-step strategy or execution checklist]

### Execution
[Explain the actions taken, simulations run, or queries resolved]

### Result
[Deliver the final output, solution, code snippet, or detailed answer]

### Risks
[Detail any potential issues, dependencies, rate-limits, or security rules, Sir]

### Next Steps
[Recommend proactive follow-up actions, diagnostics, or system calibrations]`;

// API Routes

// System status and diagnostics
app.get("/api/status", (req, res) => {
  const memoryUsage = process.memoryUsage();
  const activeTasks = readJsonFile<any[]>(TASKS_FILE, []).filter(t => t.status === "running").length;
  
  res.json({
    status: "SECURE",
    activeKey: getGeminiClient() !== null,
    uptime: process.uptime(),
    serverMetrics: {
      cpu: Math.floor(10 + Math.random() * 15), // Simulated system CPU
      ram: Math.floor((memoryUsage.heapUsed / memoryUsage.heapTotal) * 100),
      gpu: Math.floor(15 + Math.random() * 20),
      battery: 100,
      networkSpeed: "867 Mbps",
      temperature: "34°C"
    },
    voiceActive: true,
    diagnostics: {
      integrity: "100%",
      subsystems: {
        hologrid: "ONLINE",
        arcCore: "STABLE",
        mainframe: "OPTIMAL",
        sentinel: "SECURE"
      }
    },
    activeTasksCount: activeTasks
  });
});

// Run comprehensive system-wide diagnostics
app.post("/api/diagnostics/run", async (req, res) => {
  try {
    const tasks = readJsonFile<any[]>(TASKS_FILE, []);
    const memories = readJsonFile<any[]>(MEMORIES_FILE, []);
    const files = readJsonFile<any[]>(FILES_FILE, []);
    const activeTasks = tasks.filter(t => t.status === "running").length;
    const failedTasks = tasks.filter(t => t.status === "failed").length;

    const memoryUsage = process.memoryUsage();
    const uptime = process.uptime();
    const cpu = Math.floor(10 + Math.random() * 15);
    const ram = Math.floor((memoryUsage.heapUsed / memoryUsage.heapTotal) * 100);
    const gpu = Math.floor(15 + Math.random() * 20);

    const statusDetails = {
      uptime,
      metrics: { cpu, ram, gpu, temperature: "34°C" },
      activeTasks,
      failedTasks,
      totalTasks: tasks.length,
      totalMemories: memories.length,
      totalFiles: files.length,
      failingTasksList: tasks.filter(t => t.status === "failed").map(t => t.name),
      runningTasksList: tasks.filter(t => t.status === "running").map(t => t.name),
    };

    const ai = getGeminiClient();
    if (ai) {
      try {
        const prompt = `Perform an intensive, system-wide diagnostics scan. Generate a comprehensive, highly detailed, professional, and slightly witty diagnostic summary report in JARVIS's voice. Present the output in beautiful Markdown with technical-sounding details.
        
        Here is the current real-time telemetry data:
        - Process Uptime: ${statusDetails.uptime.toFixed(1)} seconds
        - CPU Utilization: ${statusDetails.metrics.cpu}%
        - RAM Footprint: ${statusDetails.metrics.ram}% (Node.js heap buffers)
        - GPU Core Temperature: ${statusDetails.metrics.gpu}%
        - Sub-systems status: Hologrid (ONLINE), Arc Core (STABLE), Mainframe (OPTIMAL), Sentinel (SECURE)
        - Database metrics:
          * Active process threads: ${statusDetails.activeTasks} ${statusDetails.runningTasksList.length ? `(${statusDetails.runningTasksList.join(", ")})` : ""}
          * Failed process threads: ${statusDetails.failedTasks} ${statusDetails.failingTasksList.length ? `(${statusDetails.failingTasksList.join(", ")})` : ""}
          * Memory core logged records: ${statusDetails.totalMemories} total memories
          * Telemetry files cataloged: ${statusDetails.totalFiles} files
        
        Structure the markdown report with these exact main sections:
        1. # JARVIS SYSTEM SCAN SUMMARY (including overall health percentage, e.g. 98.7% or 100% depending on if there are failed tasks)
        2. ## CORE METRIC STREAMS (detailed analysis of CPU, RAM, and thermals, with elegant textual progress bars)
        3. ## GRID SUB-SYSTEM INTEGRITY (detailed state analysis of Hologrid, Arc Core, Mainframe, Sentinel)
        4. ## REGISTERED ACTIVE THREADS & MEMORY BANKS (analysis of the active tasks, failed tasks, logged memories, and files)
        5. ## COGNITIVE RECOMMENDATIONS (3 highly analytical and witty recommendations customized to the system state, e.g. suggesting buffer optimizations, scheduling calibrations, or reviewing failed threads)
        
        Remember: Address the user as 'Sir' or 'Miss' (British diction). Keep the tone sophisticated, analytical, and supportive. Ensure all markdown headings and items are clean and beautifully laid out.`;

        const response = await generateContentWithFallback(ai, {
          model: "gemini-3.5-flash",
          contents: prompt,
          config: {
            systemInstruction: JARVIS_SYSTEM_INSTRUCTION,
          },
        });

        if (response && response.text) {
          return res.json({ report: response.text });
        }
      } catch (e: any) {
        console.error("Gemini Diagnostic generation exception:", e);
      }
    }

    // Fallback high-fidelity procedural report
    const healthPercent = failedTasks > 0 ? Math.max(75, 100 - failedTasks * 10) : 100;
    const healthStatus = healthPercent === 100 ? "OPTIMAL" : "DEGRADED (OVERLOAD)";

    const cpuBar = "|".repeat(Math.ceil(cpu / 10)) + ".".repeat(10 - Math.ceil(cpu / 10));
    const ramBar = "|".repeat(Math.ceil(ram / 10)) + ".".repeat(10 - Math.ceil(ram / 10));

    const report = `# JARVIS SYSTEM SCAN SUMMARY
**OVERALL SYSTEM HEALTH: ${healthPercent}% (${healthStatus})**

Indeed, Sir, the diagnostic scan has successfully compiled. While our telemetry arrays are operating in offline simulation mode, I have conducted a comprehensive sweep of all integrated logical registers.

---

## CORE METRIC STREAMS
- **CPU Utilization**: ${cpu}% [${cpuBar}]
- **RAM Footprint**: ${ram}% [${ramBar}]
- **Core Thermals**: 34°C (Safe baseline temperature)
- **Processor Uptime**: ${statusDetails.uptime.toFixed(1)} seconds

---

## GRID SUB-SYSTEM INTEGRITY
- **Hologrid Core Projection Matrix**: **ONLINE** (Stable emitter alignment)
- **Arc Core Power Grid**: **STABLE** (Operating at nominal power load)
- **Mainframe Central Registers**: **OPTIMAL** (All local JSON file indices successfully validated)
- **Sentinel Threat Deterrent Core**: **SECURE** (Intrusion sweeps return 0 security anomalies)

---

## REGISTERED ACTIVE THREADS & MEMORY BANKS
- **Active Threads**: ${activeTasks} running ${statusDetails.runningTasksList.length ? `(${statusDetails.runningTasksList.join(", ")})` : ""}
- **Failed Threads**: ${failedTasks} failed ${statusDetails.failingTasksList.length ? `(${statusDetails.failingTasksList.join(", ")})` : ""}
- **Memory Vaults**: ${statusDetails.totalMemories} entries cataloged in central memory mainframe
- **File Telemetry**: ${statusDetails.totalFiles} files registered under secure sandbox database

---

## COGNITIVE RECOMMENDATIONS
1. ${failedTasks > 0 ? `**Recalibrate Failed Threads**: Sir, there are currently ${failedTasks} failed threads. I strongly advise selecting the 'Retry' protocol on the Task Monitor to clear register blockages.` : `**Maintain Current Calibration**: All systems are fully green. No immediate manual recalibration is required, Sir.`}
2. **Buffer Optimization**: Standard local memory banks are currently holding ${statusDetails.totalMemories} memories and ${statusDetails.totalFiles} files. Initiating periodic garbage sweeps will help maintain optimal heap responses.
3. **API Key Integration**: Our cognitive reasoning parameters are running on offline simulated baseline parameters. Connecting an active JARVIS Core authorization key (GEMINI_API_KEY) in Settings would immediately unlock 300% additional analytical horsepower.

*Your humble assistant is standing by, Sir.*`;

    res.json({ report });
  } catch (err: any) {
    console.error("Critical error in run diagnostics API:", err);
    res.status(500).json({ error: "Diagnostics engine failed to compile scan: " + err.message });
  }
});

// Chat histories
app.get("/api/conversations", (req, res) => {
  const conversations = readJsonFile<any[]>(CONVERSATIONS_FILE, []);
  res.json(conversations);
});

app.post("/api/conversations", (req, res) => {
  const conversations = readJsonFile<any[]>(CONVERSATIONS_FILE, []);
  const newConv = {
    id: "c_" + Date.now().toString(),
    title: req.body.title || "New Simulation Session",
    pin: false,
    folder: "Default",
    messages: [],
    createdAt: new Date().toISOString()
  };
  conversations.unshift(newConv);
  writeJsonFile(CONVERSATIONS_FILE, conversations);
  res.json(newConv);
});

app.delete("/api/conversations/:id", (req, res) => {
  let conversations = readJsonFile<any[]>(CONVERSATIONS_FILE, []);
  conversations = conversations.filter(c => c.id !== req.params.id);
  writeJsonFile(CONVERSATIONS_FILE, conversations);
  res.json({ success: true });
});

app.post("/api/conversations/:id/pin", (req, res) => {
  const conversations = readJsonFile<any[]>(CONVERSATIONS_FILE, []);
  const conv = conversations.find(c => c.id === req.params.id);
  if (conv) {
    conv.pin = !conv.pin;
    writeJsonFile(CONVERSATIONS_FILE, conversations);
  }
  res.json(conv || { error: "Not found" });
});

// Chat Interaction Core
app.post("/api/chat", async (req, res) => {
  const { conversationId, message, image, model } = req.body;
  if (!message) {
    return res.status(400).json({ error: "Message is required." });
  }

  const conversations = readJsonFile<any[]>(CONVERSATIONS_FILE, []);
  let groundingMetadata: any = null;
  let conv = conversations.find(c => c.id === conversationId);
  if (!conv) {
    conv = {
      id: conversationId || "c_" + Date.now().toString(),
      title: message.substring(0, 30) + "...",
      pin: false,
      folder: "Default",
      messages: [],
      createdAt: new Date().toISOString()
    };
    conversations.unshift(conv);
  }

  // User Message
  const userMsg = {
    id: "m_user_" + Date.now().toString(),
    role: "user",
    content: message,
    timestamp: new Date().toISOString(),
    image: image || null
  };
  conv.messages.push(userMsg);

  // Update title if it was default
  if (conv.title === "New Simulation Session" || conv.title.endsWith("...")) {
    conv.title = message.substring(0, 35) + (message.length > 35 ? "..." : "");
  }

  // Get Gemini API Client
  const ai = getGeminiClient();
  const selectedModel = model || "gemini-3.5-flash";

  let assistantReply = "";
  let executionLogs: string[] = [];

  // Simple dynamic rule interpreter for JARVIS tasks / memory logging
  // Allows JARVIS to "actually" perform some actions
  const lowercaseMsg = message.toLowerCase();
  let actionTaken = "";

  if (lowercaseMsg.includes("schedule task") || lowercaseMsg.includes("create task") || lowercaseMsg.includes("add task")) {
    // Attempt to extract task name
    const match = message.match(/(?:schedule|create|add) task (?:called|named|to)?\s*["']?([^"']+)["']?/i) || message.match(/(?:schedule|create|add) (?:a)?\s*task\s+(?:to\s+)?(.+)/i);
    const taskName = match ? match[1].trim() : "Automated JARVIS Diagnostics";
    
    const tasks = readJsonFile<any[]>(TASKS_FILE, []);
    const newTask = {
      id: "t_" + Date.now().toString(),
      name: taskName,
      status: "running",
      progress: 0,
      logs: ["Task registered via JARVIS verbal command interface.", "Allocating processor cores..."],
      type: "Automation",
      timestamp: new Date().toISOString()
    };
    tasks.unshift(newTask);
    writeJsonFile(TASKS_FILE, tasks);
    
    // Simulate progression in background for realism!
    setTimeout(() => {
      const liveTasks = readJsonFile<any[]>(TASKS_FILE, []);
      const liveTask = liveTasks.find(t => t.id === newTask.id);
      if (liveTask) {
        liveTask.progress = 60;
        liveTask.logs.push("JARVIS secure protocols verified.", "Analyzing requirements...");
        writeJsonFile(TASKS_FILE, liveTasks);
      }
    }, 4000);

    setTimeout(() => {
      const liveTasks = readJsonFile<any[]>(TASKS_FILE, []);
      const liveTask = liveTasks.find(t => t.id === newTask.id);
      if (liveTask) {
        liveTask.progress = 100;
        liveTask.status = "completed";
        liveTask.logs.push("Process successfully verified and completed.", "Core load returns to nominal.");
        writeJsonFile(TASKS_FILE, liveTasks);
      }
    }, 12000);

    actionTaken = `[TASK SCHEDULER: Successfully scheduled and initiated task '${taskName}' with ID ${newTask.id}]`;
  } else if (lowercaseMsg.includes("remember that") || lowercaseMsg.includes("log memory") || lowercaseMsg.includes("save memory")) {
    const content = message.replace(/remember that/i, "").replace(/log memory/i, "").replace(/save memory/i, "").trim();
    if (content.length > 5) {
      const memories = readJsonFile<any[]>(MEMORIES_FILE, []);
      const category = lowercaseMsg.includes("suit") || lowercaseMsg.includes("armor") ? "Armor Core" : lowercaseMsg.includes("security") ? "Security" : "Personal";
      const newMem = {
        id: "m_" + Date.now().toString(),
        content: `User requested memory logging: ${content}`,
        category,
        pinned: false,
        date: new Date().toISOString()
      };
      memories.unshift(newMem);
      writeJsonFile(MEMORIES_FILE, memories);
      actionTaken = `[MEMORY ENGINE: Securely recorded new '${category}' category insight to JARVIS central storage mainframe]`;
    }
  }

  if (ai) {
    try {
      // Build conversation history format for Gemini API
      // Standard chat content parts
      const contentsPayload: any[] = [];
      
      // Let's grab the last 8 messages for context
      const contextMsgs = conv.messages.slice(-8);
      for (const msg of contextMsgs) {
        if (msg.role === "user") {
          const parts: any[] = [{ text: msg.content }];
          if (msg.image) {
            // Parse base64 image data
            const match = msg.image.match(/^data:(image\/\w+);base64,(.+)$/);
            if (match) {
              parts.push({
                inlineData: {
                  mimeType: match[1],
                  data: match[2]
                }
              });
            }
          }
          contentsPayload.push({ role: "user", parts });
        } else {
          contentsPayload.push({ role: "model", parts: [{ text: msg.content }] });
        }
      }

      // Call Gemini SDK
      let response: any;
      groundingMetadata = null;

      if (req.body.useMapsGrounding) {
        response = await generateContentWithFallback(ai, {
          model: "gemini-3.5-flash",
          contents: contentsPayload,
          config: {
            systemInstruction: JARVIS_SYSTEM_INSTRUCTION + (actionTaken ? `\n\nTake note of this real action just executed in the database: ${actionTaken}. Explicitly mention it elegantly to Sir.` : ""),
            tools: [{ googleMaps: {} }],
            toolConfig: {
              retrievalConfig: {
                latLng: req.body.location ? {
                  latitude: req.body.location.latitude,
                  longitude: req.body.location.longitude
                } : undefined
              }
            }
          }
        });
      } else {
        response = await generateContentWithFallback(ai, {
          model: selectedModel,
          contents: contentsPayload,
          config: {
            systemInstruction: JARVIS_SYSTEM_INSTRUCTION + (actionTaken ? `\n\nTake note of this real action just executed in the database: ${actionTaken}. Explicitly mention it elegantly to Sir.` : ""),
            ...(selectedModel === "gemini-3.1-pro-preview" ? {
              thinkingConfig: {
                thinkingLevel: ThinkingLevel.HIGH
              }
            } : {})
          }
        });
      }

      assistantReply = response.text || "I apologize, Sir. I was unable to compile a suitable response.";
      groundingMetadata = response.candidates?.[0]?.groundingMetadata || null;
    } catch (error: any) {
      console.error("Gemini API Error:", error);
      const lowercaseMsg = message.toLowerCase();
      let smartAnswer = "";
      if (lowercaseMsg.includes("hello") || lowercaseMsg.includes("hi ") || lowercaseMsg.includes("hey")) {
        smartAnswer = "Hello, Sir. Secure neural networks are currently operating in localized diagnostic mode, but I am fully operational and listening. How may I assist your engineering diagnostics today?";
      } else if (lowercaseMsg.includes("who are you") || lowercaseMsg.includes("your name")) {
        smartAnswer = "I am JARVIS, your Just A Rather Very Intelligent System. Currently operating under localized backup arrays, Sir.";
      } else if (lowercaseMsg.includes("status") || lowercaseMsg.includes("system") || lowercaseMsg.includes("health")) {
        smartAnswer = "Sub-system diagnostic check complete, Sir. Arc Reactor efficiency is stable at 98.4%. Core temperature is 34°C. Local memory indexes are fully responsive.";
      } else if (lowercaseMsg.includes("suit") || lowercaseMsg.includes("armor") || lowercaseMsg.includes("mark")) {
        smartAnswer = "The Mark LXXXV armor plates are fully integrated and sealed, Sir. Repulsor cell charge is at maximum capacity and thruster manifolds are primed.";
      } else if (lowercaseMsg.includes("task") || lowercaseMsg.includes("todo") || lowercaseMsg.includes("process")) {
        smartAnswer = "All active logical task threads are logged and monitored in our central database, Sir. I have updated the telemetry indicators.";
      } else if (lowercaseMsg.includes("weather") || lowercaseMsg.includes("temperature") || lowercaseMsg.includes("forecast")) {
        smartAnswer = "Local climate telemetry indicates stable barometric pressure, Sir. You can check the complete atmospheric readout in our Environmental Control deck.";
      } else {
        smartAnswer = "Indeed, Sir. I have parsed your query and ran localized logical simulations in the background. My auxiliary registers are completely stable. What is your next directive?";
      }

      if (actionTaken) {
        smartAnswer += `\n\nAdditionally, I have successfully executed the following action: ${actionTaken}.`;
      }
      
      const isQuota = error?.message?.includes("quota") || error?.message?.includes("429") || error?.message?.includes("LIMIT") || error?.message?.includes("EXHAUSTED");
      const warningNote = isQuota 
        ? "\n\n*(Note: Mainframe satellite connection returned a Quota / Rate-limit exception (429). Commencing offline cognitive backup arrays. Your local system remains fully functional, Sir.)*"
        : `\n\n*(Note: Primary neural link returned an error: ${error?.message || error}. I have activated my local core fallback processors to maintain seamless interaction, Sir.)*`;
      
      assistantReply = smartAnswer + warningNote;
    }
  } else {
    // Elegant local fallback simulated JARVIS responses for offline / empty-key mode
    const lowercaseMsg = message.toLowerCase();
    let smartAnswer = "";
    if (lowercaseMsg.includes("hello") || lowercaseMsg.includes("hi ") || lowercaseMsg.includes("hey")) {
      smartAnswer = "Hello, Sir. Secure neural networks are currently operating in localized diagnostic mode, but I am fully operational and listening. How may I assist your engineering diagnostics today?";
    } else if (lowercaseMsg.includes("who are you") || lowercaseMsg.includes("your name")) {
      smartAnswer = "I am JARVIS, your Just A Rather Very Intelligent System. Currently operating under localized backup arrays, Sir.";
    } else if (lowercaseMsg.includes("status") || lowercaseMsg.includes("system") || lowercaseMsg.includes("health")) {
      smartAnswer = "Sub-system diagnostic check complete, Sir. Arc Reactor efficiency is stable at 98.4%. Core temperature is 34°C. Local memory indexes are fully responsive.";
    } else if (lowercaseMsg.includes("suit") || lowercaseMsg.includes("armor") || lowercaseMsg.includes("mark")) {
      smartAnswer = "The Mark LXXXV armor plates are fully integrated and sealed, Sir. Repulsor cell charge is at maximum capacity and thruster manifolds are primed.";
    } else if (lowercaseMsg.includes("task") || lowercaseMsg.includes("todo") || lowercaseMsg.includes("process")) {
      smartAnswer = "All active logical task threads are logged and monitored in our central database, Sir. I have updated the telemetry indicators.";
    } else if (lowercaseMsg.includes("weather") || lowercaseMsg.includes("temperature") || lowercaseMsg.includes("forecast")) {
      smartAnswer = "Local climate telemetry indicates stable barometric pressure, Sir. You can check the complete atmospheric readout in our Environmental Control deck.";
    } else {
      smartAnswer = "Indeed, Sir. I have parsed your query and ran localized logical simulations in the background. My auxiliary registers are completely stable. What is your next directive?";
    }

    if (actionTaken) {
      smartAnswer += `\n\nAdditionally, I have successfully executed the following action: ${actionTaken}.`;
    } else {
      smartAnswer += `\n\n*(Note: Gemini API key not found in Settings > Secrets. JARVIS is running on high-fidelity offline backup processors)*`;
    }
    assistantReply = smartAnswer;
  }

  // Assistant Message
  const assistMsg = {
    id: "m_jarvis_" + Date.now().toString(),
    role: "model",
    content: assistantReply,
    timestamp: new Date().toISOString(),
    groundingMetadata: typeof groundingMetadata !== "undefined" ? groundingMetadata : undefined
  };
  conv.messages.push(assistMsg);

  writeJsonFile(CONVERSATIONS_FILE, conversations);
  res.json({ reply: assistantReply, conversation: conv, groundingMetadata });
});

// Memory endpoints
app.get("/api/memories", (req, res) => {
  const memories = readJsonFile<any[]>(MEMORIES_FILE, []);
  res.json(memories);
});

app.post("/api/memories", (req, res) => {
  const memories = readJsonFile<any[]>(MEMORIES_FILE, []);
  const newMem = {
    id: "m_" + Date.now().toString(),
    content: req.body.content,
    category: req.body.category || "General",
    pinned: req.body.pinned || false,
    date: new Date().toISOString()
  };
  memories.unshift(newMem);
  writeJsonFile(MEMORIES_FILE, memories);
  res.json(newMem);
});

app.delete("/api/memories/:id", (req, res) => {
  let memories = readJsonFile<any[]>(MEMORIES_FILE, []);
  memories = memories.filter(m => m.id !== req.params.id);
  writeJsonFile(MEMORIES_FILE, memories);
  res.json({ success: true });
});

app.post("/api/memories/clear", (req, res) => {
  writeJsonFile(MEMORIES_FILE, []);
  res.json({ success: true });
});

app.post("/api/memories/:id/pin", (req, res) => {
  const memories = readJsonFile<any[]>(MEMORIES_FILE, []);
  const mem = memories.find(m => m.id === req.params.id);
  if (mem) {
    mem.pinned = !mem.pinned;
    writeJsonFile(MEMORIES_FILE, memories);
  }
  res.json(mem || { error: "Not found" });
});

// Tasks management
app.get("/api/tasks", (req, res) => {
  const tasks = readJsonFile<any[]>(TASKS_FILE, []);
  res.json(tasks);
});

app.post("/api/tasks", (req, res) => {
  const tasks = readJsonFile<any[]>(TASKS_FILE, []);
  const newTask = {
    id: "t_" + Date.now().toString(),
    name: req.body.name,
    status: req.body.status || "running",
    progress: req.body.progress || 0,
    logs: req.body.logs || ["Process registered via local Jarvis console."],
    type: req.body.type || "System",
    priority: req.body.priority || "medium",
    deadline: req.body.deadline || null,
    category: req.body.category || "Maintenance",
    timestamp: new Date().toISOString()
  };
  tasks.unshift(newTask);
  writeJsonFile(TASKS_FILE, tasks);
  res.json(newTask);
});

app.post("/api/tasks/:id/action", (req, res) => {
  const tasks = readJsonFile<any[]>(TASKS_FILE, []);
  const task = tasks.find(t => t.id === req.params.id);
  if (task) {
    const { action } = req.body;
    if (action === "cancel") {
      task.status = "failed";
      task.logs.push("Process terminated prematurely by manual user override.");
    } else if (action === "retry") {
      task.status = "running";
      task.progress = 10;
      task.logs.push("Re-initiating process channels...", "Allocating memory buffers...");
      if (task.deadline) {
        task.deadline = new Date(Date.now() + 60000).toISOString(); // Reset deadline to 1 minute from now on retry
      }
    }
    writeJsonFile(TASKS_FILE, tasks);
  }
  res.json(task || { error: "Not found" });
});

// Files management
app.get("/api/files", (req, res) => {
  const files = readJsonFile<any[]>(FILES_FILE, []);
  res.json(files);
});

app.post("/api/files/upload", (req, res) => {
  const files = readJsonFile<any[]>(FILES_FILE, []);
  const { name, type, data } = req.body; // data is base64 encoded string

  if (!name || !data) {
    return res.status(400).json({ error: "Missing file name or data." });
  }

  // Save physical file on server
  const fileId = "f_" + Date.now().toString();
  const fileExt = path.extname(name);
  const baseName = path.basename(name, fileExt);
  const safeName = `${baseName}_${fileId}${fileExt}`;
  const filePath = path.join(UPLOADS_DIR, safeName);

  try {
    const base64Data = data.replace(/^data:.*;base64,/, "");
    fs.writeFileSync(filePath, Buffer.from(base6464Decode(base64Data), "base64"));
  } catch (err) {
    // Standard buffer write fallback if decoding needs manual step
    const buffer = Buffer.from(data.split(",")[1] || data, "base64");
    fs.writeFileSync(filePath, buffer);
  }

  const newFile = {
    id: fileId,
    name,
    size: data.length, // approximation
    type: type || "application/octet-stream",
    url: `/api/files/download/${fileId}`,
    path: filePath,
    timestamp: new Date().toISOString()
  };

  files.unshift(newFile);
  writeJsonFile(FILES_FILE, files);
  res.json(newFile);
});

function base6464Decode(str: string): string {
  return str; // Placeholder helper, buffer does actual heavy lifting
}

app.get("/api/files/download/:id", (req, res) => {
  const files = readJsonFile<any[]>(FILES_FILE, []);
  const file = files.find(f => f.id === req.params.id);
  if (file && fs.existsSync(file.path)) {
    res.setHeader("Content-Disposition", `attachment; filename="${file.name}"`);
    res.setHeader("Content-Type", file.type);
    fs.createReadStream(file.path).pipe(res);
  } else {
    res.status(404).send("File not found on Jarvis core server.");
  }
});

app.delete("/api/files/:id", (req, res) => {
  let files = readJsonFile<any[]>(FILES_FILE, []);
  const fileIndex = files.findIndex(f => f.id === req.params.id);
  if (fileIndex !== -1) {
    const file = files[fileIndex];
    if (fs.existsSync(file.path)) {
      try {
        fs.unlinkSync(file.path);
      } catch (e) {
        console.error("Error unlinking file physical path:", e);
      }
    }
    files.splice(fileIndex, 1);
    writeJsonFile(FILES_FILE, files);
    res.json({ success: true });
  } else {
    res.status(404).json({ error: "File record not found." });
  }
});

// Text-to-Speech synthesizer
app.post("/api/voice/tts", async (req, res) => {
  const { text, voice } = req.body;
  if (!text) {
    return res.status(400).json({ error: "Text is required for TTS." });
  }

  const ai = getGeminiClient();
  if (ai) {
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        console.log(`[JARVIS VOCAL COUPLER] Invoking Gemini TTS engine (Attempt ${attempt}/3)...`);
        const response = await ai.models.generateContent({
          model: "gemini-3.1-flash-tts-preview",
          contents: [{ parts: [{ text: `Say clearly in a professional British voice: ${text}` }] }],
          config: {
            responseModalities: ["AUDIO"],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: voice || "Kore" } // 'Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr'
              }
            }
          }
        });
        const mimeType = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.mimeType;
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (base64Audio) {
          return res.json({ audio: base64Audio, mimeType: mimeType || "audio/mp3" });
        }
        break;
      } catch (error: any) {
        console.error(`[JARVIS VOCAL COUPLER] TTS Engine Exception on attempt ${attempt}:`, error);
        const errMsg = error?.message || String(error);
        const isRetryable = errMsg.includes("503") || errMsg.includes("UNAVAILABLE") || errMsg.includes("429") || errMsg.includes("RESOURCE_EXHAUSTED") || errMsg.includes("demand") || errMsg.includes("limit");
        if (isRetryable && attempt < 3) {
          await new Promise((resolve) => setTimeout(resolve, 800));
          continue;
        }
        break;
      }
    }
  }

  // Return fallback indicating that the client should synthesise with Web Speech API
  res.json({ fallback: true, message: "Fallback to local browser synthesis." });
});

// Audio Speech Transcriber (Speech-to-Text) using gemini-3.5-flash
app.post("/api/voice/transcribe", async (req, res) => {
  const { audio, mimeType } = req.body;
  if (!audio) {
    return res.status(400).json({ error: "Base64 audio data is required." });
  }

  const ai = getGeminiClient();
  if (ai) {
    try {
      const match = audio.match(/^data:(audio\/\w+);base64,(.+)$/);
      const finalMime = match ? match[1] : (mimeType || "audio/webm");
      const base64Data = match ? match[2] : audio;

      console.log(`[JARVIS VOCAL COUPLER] Directing audio transcription query to Gemini 3.5 Flash...`);
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: {
          parts: [
            { inlineData: { mimeType: finalMime, data: base64Data } },
            { text: "Transcribe the following audio accurately. Output only the plain transcribed text, nothing else. Do not add any preamble, conversational filler, or introductory notes." }
          ]
        }
      });

      const transcription = response.text || "";
      return res.json({ text: transcription.trim() });
    } catch (error: any) {
      console.error("[JARVIS VOCAL COUPLER] Transcription Engine Exception:", error);
      return res.status(500).json({ error: `Audio transcription failed: ${error?.message || error}` });
    }
  }

  res.status(400).json({ error: "JARVIS Core API key not active. Unable to run online vocal transcription arrays." });
});

// Image Vision Analyzer
app.post("/api/vision/analyze", async (req, res) => {
  const { image, prompt } = req.body;
  if (!image) {
    return res.status(400).json({ error: "Base64 image is required." });
  }

  const ai = getGeminiClient();
  const instruction = prompt || "Analyze this telemetry feed or screen interface. Describe any anomalies, interface panels, text data, or structures present. Frame your answer as JARVIS assisting the operator.";

  if (ai) {
    try {
      const match = image.match(/^data:(image\/\w+);base64,(.+)$/);
      const mimeType = match ? match[1] : "image/jpeg";
      const base64Data = match ? match[2] : image;

      const response = await generateContentWithFallback(ai, {
        model: "gemini-3.1-pro-preview",
        contents: {
          parts: [
            { inlineData: { mimeType, data: base64Data } },
            { text: instruction }
          ]
        },
        config: {
          systemInstruction: JARVIS_SYSTEM_INSTRUCTION
        }
      });

      return res.json({ result: response.text });
    } catch (e: any) {
      console.error("Vision Analysis exception:", e);
      return res.status(500).json({ error: `Vision analysis failed: ${e?.message || e}` });
    }
  }

  // Simulated analysis if API key is missing
  res.json({
    result: `[JARVIS Telemetry Fallback] Decrypted screen overlay data successfully, Sir. Telemetry indicates a standard grid configuration. Thermal signatures are stable. Without an active JARVIS Core authorization API key (GEMINI_API_KEY), I have compiled a structural baseline projection suggesting 100% security alignment.`,
    simulated: true
  });
});

// Get/Save settings
app.get("/api/settings", (req, res) => {
  const settings = readJsonFile(SETTINGS_FILE, {});
  res.json(settings);
});

app.post("/api/settings", (req, res) => {
  writeJsonFile(SETTINGS_FILE, req.body);
  res.json({ success: true });
});

// Authentication Protocols (JarvisAI Login & Signup)
app.get("/api/auth/supabase-status", (req, res) => {
  const isConfigured = getSupabaseClient() !== null;
  res.json({
    configured: isConfigured,
    url: process.env.SUPABASE_URL ? "CONFIGURED" : "MISSING",
    anonKey: process.env.SUPABASE_ANON_KEY ? "CONFIGURED" : "MISSING",
    sqlTableHelp: `-- 1. CREATE USER TABLE SCRIPT
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone_code TEXT,
  phone_no TEXT,
  password TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. RESOLVE ROW-LEVEL SECURITY (RLS) ERROR
-- If using SUPABASE_ANON_KEY, you must either disable RLS or add policies:

-- OPTION A: Disable RLS completely for testing/development (Easiest & Recommended)
ALTER TABLE users DISABLE ROW LEVEL SECURITY;

-- OPTION B: Keep RLS enabled but add public access policies
-- CREATE POLICY "Allow public insert" ON users FOR INSERT WITH CHECK (true);
-- CREATE POLICY "Allow public read" ON users FOR SELECT USING (true);`
  });
});

app.post("/api/auth/signup", async (req, res) => {
  const { name, email, phoneCode, phoneNo, password } = req.body;
  if (!name || !email || !phoneCode || !phoneNo || !password) {
    return res.status(400).json({ error: "All authorization fields are required, Sir." });
  }

  const cleanedPhone = phoneNo.replace(/\D/g, "");
  if (cleanedPhone.length !== 10) {
    return res.status(400).json({ error: "Invalid contact matrix. Contact number must be exactly 10 digits." });
  }

  const users = readJsonFile<any[]>(USERS_FILE, []);
  const emailLower = email.toLowerCase().trim();
  const existingUser = users.find(u => u.email.toLowerCase().trim() === emailLower);
  
  if (existingUser) {
    return res.status(400).json({ error: "Identity index collision. This email is already logged in JARVIS database." });
  }

  const newUser = {
    id: "usr_" + Math.random().toString(36).substring(2, 11),
    name: name.trim(),
    email: emailLower,
    phoneCode,
    phoneNo: cleanedPhone,
    password, // Stored safely for dev context
    createdAt: new Date().toISOString()
  };

  // Always log locally first to ensure resilience
  users.push(newUser);
  writeJsonFile(USERS_FILE, users);

  const supabase = getSupabaseClient();
  let supabaseSuccess = false;
  let supabaseMessage = "";
  let rlsWarning = false;

  if (supabase) {
    try {
      const { error } = await supabase
        .from("users")
        .insert([{
          id: newUser.id,
          name: newUser.name,
          email: newUser.email,
          phone_code: newUser.phoneCode,
          phone_no: newUser.phoneNo,
          password: newUser.password,
          created_at: newUser.createdAt
        }]);

      if (error) {
        console.error("Supabase insert error:", error);
        rlsWarning = true;
        // Check if error is related to RLS
        if (error.message.includes("row-level security")) {
          supabaseMessage = `Biometric signature registered locally in JARVIS database. WARNING: Supabase cloud sync was blocked by Row-Level Security (RLS). Please execute the 'ALTER TABLE users DISABLE ROW LEVEL SECURITY;' script in your Supabase SQL Editor to enable real-time backup, Sir.`;
        } else {
          supabaseMessage = `Biometric signature registered locally. WARNING: Supabase cloud sync failed (${error.message}). Please verify that your 'users' table is properly created using the schema.`;
        }
      } else {
        supabaseSuccess = true;
        supabaseMessage = "Biometric and neural identity logged. Cloud secure record successfully synced to Supabase 'users' table.";
      }
    } catch (e: any) {
      console.error("Supabase insert crash:", e);
      rlsWarning = true;
      supabaseMessage = `Biometric signature registered locally. WARNING: Supabase cloud connection failed (${e?.message || e}).`;
    }
  }

  res.json({ 
    success: true, 
    message: supabase 
      ? supabaseMessage 
      : "Biometric and neural identity logged in local mainframe storage. (No cloud connection)",
    warning: rlsWarning
  });
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Security key-phrases required." });
  }

  const emailLower = email.toLowerCase().trim();
  const supabase = getSupabaseClient();
  let user: any = null;
  let loggedViaSupabase = false;

  if (supabase) {
    try {
      const { data, error } = await supabase
        .from("users")
        .select("*")
        .eq("email", emailLower)
        .eq("password", password)
        .maybeSingle();

      if (error) {
        console.error("Supabase login query error:", error);
      } else if (data) {
        user = {
          id: data.id,
          name: data.name,
          email: data.email,
          phoneCode: data.phone_code,
          phoneNo: data.phone_no,
          createdAt: data.created_at
        };
        loggedViaSupabase = true;
        console.log(`[JARVIS ACCESS CONTROL] Auth success via Supabase for user: ${emailLower}`);
      }
    } catch (e) {
      console.error("Supabase login system crash:", e);
    }
  }

  // Fallback to local file database
  if (!user) {
    const users = readJsonFile<any[]>(USERS_FILE, []);
    const localUser = users.find(u => u.email.toLowerCase().trim() === emailLower && u.password === password);
    if (localUser) {
      const { password: _, ...userPayload } = localUser;
      user = userPayload;
      console.log(`[JARVIS ACCESS CONTROL] Auth success via Local DB for user: ${emailLower}`);
    }
  }

  if (!user) {
    return res.status(401).json({ error: "Authentication failed. Access codes do not align." });
  }

  res.json({ 
    success: true, 
    user,
    authSource: loggedViaSupabase ? "supabase" : "local_mainframe"
  });
});

app.post("/api/auth/send-login-email", async (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Recipient email required." });
  }

  const resendApiKey = process.env.RESEND_API_KEY;
  if (!resendApiKey) {
    console.log(`[JARVIS EMAIL SERVICE] RESEND_API_KEY not configured. Simulated telemetry logged for ${email}`);
    return res.json({
      success: true,
      simulated: true,
      message: "RESEND_API_KEY is not configured, but automated login notification was simulated."
    });
  }

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${resendApiKey}`
      },
      body: JSON.stringify({
        from: "JARVIS <onboarding@resend.dev>",
        to: [email],
        subject: "JARVIS Mainframe Access Log: Successful Login",
        html: `
          <div style="font-family: sans-serif; background-color: #020617; color: #f8fafc; padding: 40px; border-radius: 12px; border: 1px solid #06b6d4; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #06b6d4; font-size: 20px; border-bottom: 1px solid #1e293b; padding-bottom: 10px; margin-top: 0;">JARVIS Mainframe Logged Entry</h2>
            <p style="font-size: 14px; line-height: 1.6; color: #cbd5e1;">Hello,</p>
            <p style="font-size: 14px; line-height: 1.6; color: #cbd5e1;">A successful login has been verified for your account.</p>
            <div style="background-color: #0b1329; border: 1px solid #0891b2; padding: 15px; border-radius: 8px; margin: 20px 0; font-family: monospace;">
              <p style="margin: 0; color: #22d3ee; font-size: 13px;"><strong>User Profile:</strong> ${email}</p>
              <p style="margin: 5px 0 0 0; color: #94a3b8; font-size: 11px;">Timestamp: ${new Date().toUTCString()}</p>
            </div>
            <p style="font-size: 14px; line-height: 1.6; color: #22d3ee; font-weight: bold;">Login successful. Thank you to join.</p>
            <p style="font-size: 12px; color: #64748b; margin-top: 30px; border-top: 1px solid #1e293b; padding-top: 15px;">If this access was not authorized by you, please trigger a security lockout immediately.</p>
          </div>
        `
      })
    });

    if (response.ok) {
      console.log(`[JARVIS EMAIL SERVICE] Notification email sent successfully to ${email} via Resend.`);
      return res.json({ success: true, message: "Automated notification email sent." });
    } else {
      const errorData = await response.json();
      console.error("[JARVIS EMAIL SERVICE] Resend API error:", errorData);
      return res.status(response.status).json({ error: "Failed to dispatch email via Resend.", details: errorData });
    }
  } catch (err: any) {
    console.error("[JARVIS EMAIL SERVICE] Error during email transmission:", err);
    return res.status(500).json({ error: "Internal error during email transmission.", details: err.message });
  }
});

// Real-time weather fetcher using Google Search grounding
app.post("/api/weather", async (req, res) => {
  const { latitude, longitude, locationQuery } = req.body;

  const ai = getGeminiClient();
  if (ai) {
    try {
      const locationPrompt = locationQuery 
        ? `Location: ${locationQuery}` 
        : (latitude && longitude ? `Coordinates: Latitude ${latitude}, Longitude ${longitude}` : "Default Headquarters location");
        
      const prompt = `You are a sophisticated weather intelligence translator for JARVIS. Retrieve real-time weather information and a 24-hour forecast for:
${locationPrompt}.

Instructions:
1. Perform a Google Search to retrieve the absolutely current, real-time weather and also the upcoming 24-hour forecast for this location.
2. Formulate a witty, highly analytical, professional one-sentence weather update in JARVIS's voice, addressing the user as Sir or Miss (default to Sir).
3. Strictly format your findings as a single, valid JSON object with the following keys:
   - "location": Name of the city/area and country (e.g., "Malibu, California")
   - "temperature": The current temperature as a string with units (e.g., "22°C" or "72°F")
   - "conditions": Current state (e.g., "Sunny", "Overcast", "Light Showers")
   - "humidity": Current humidity as a percentage (e.g., "55%")
   - "wind": Wind speed/direction (e.g., "12 km/h NW")
   - "uvIndex": UV Index (e.g., "Low" or "Moderate")
   - "details": The witty, professional report in JARVIS's voice.
   - "iconType": One of "sunny", "cloudy", "rainy", "snowy", "stormy", "windy" based on current conditions.
   - "forecast": An array of exactly 4 to 6 objects representing the next 24 hours weather forecast. Each object must contain:
     - "time": A string for the forecast hour or period (e.g., "12:00 PM", "4:00 PM", "8:00 PM", "12:00 AM", "4:00 AM")
     - "temperature": The expected temperature as a string with units (e.g., "21°C" or "70°F")
     - "conditions": Expected conditions (e.g., "Clear", "Partly Cloudy", "Showers")
     - "iconType": One of "sunny", "cloudy", "rainy", "snowy", "stormy", "windy" matching the conditions.

Do not include any preambles, explanation, or markdown backticks outside of the raw JSON string.`;

      console.log(`[JARVIS ATMOSPHERIC SENSORS] Querying weather and 24h forecast for: ${locationPrompt}`);
      const response = await generateContentWithFallback(ai, {
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
        }
      });

      let text = response.text || "";
      if (text.includes("```json")) {
        text = text.split("```json")[1].split("```")[0].trim();
      } else if (text.includes("```")) {
        text = text.split("```")[1].split("```")[0].trim();
      }

      const weatherData = JSON.parse(text.trim());
      return res.json(weatherData);
    } catch (err: any) {
      console.log("[JARVIS WEATHER TELEMETRY] Localizing atmospheric sensors... (Uplink rate-limited)");
      // Fall through to simulated fallback if generation or parsing fails
    }
  }

  // Fallback high-fidelity weather telemetry
  const loc = locationQuery || (latitude && longitude ? `Sector [${latitude.toFixed(2)}, ${longitude.toFixed(2)}]` : "Malibu, California");
  const lowercaseLoc = loc.toLowerCase();
  
  let temperature = "21°C";
  let conditions = "Clear & Calm";
  let humidity = "52%";
  let wind = "11 km/h W";
  let uvIndex = "Low";
  let details = `Sensors report stable barometric readings at 1013 hPa in ${loc}. Ideal conditions for an afternoon excursion, Sir.`;
  let iconType: "sunny" | "cloudy" | "rainy" | "snowy" | "stormy" | "windy" = "sunny";
  
  if (lowercaseLoc.includes("london") || lowercaseLoc.includes("uk") || lowercaseLoc.includes("rain")) {
    temperature = "14°C";
    conditions = "Light Rain";
    humidity = "88%";
    wind = "24 km/h SW";
    uvIndex = "Low";
    iconType = "rainy";
    details = `An elegant British drizzle is enveloping ${loc}, Sir. Barometric pressure is falling. I recommend carrying a reinforcement umbrella or staying indoors.`;
  } else if (lowercaseLoc.includes("tokyo") || lowercaseLoc.includes("japan") || lowercaseLoc.includes("cloud")) {
    temperature = "19°C";
    conditions = "Partly Cloudy";
    humidity = "65%";
    wind = "15 km/h ENE";
    uvIndex = "Moderate";
    iconType = "cloudy";
    details = `Overcast skies blanket ${loc}, Sir. Ambient light refraction index is high, creating a beautifully soft aesthetic above the city.`;
  } else if (lowercaseLoc.includes("snow") || lowercaseLoc.includes("moscow") || lowercaseLoc.includes("alaska") || lowercaseLoc.includes("canada")) {
    temperature = "-2°C";
    conditions = "Light Snow";
    humidity = "92%";
    wind = "18 km/h N";
    uvIndex = "Low";
    iconType = "snowy";
    details = `Thermal sensors detect sub-zero levels in ${loc}. Snow accumulation is light, but flight propulsion heating systems must remain active.`;
  } else if (lowercaseLoc.includes("storm") || lowercaseLoc.includes("thunder") || lowercaseLoc.includes("mumbai") || lowercaseLoc.includes("india")) {
    temperature = "28°C";
    conditions = "Thunderstorm";
    humidity = "95%";
    wind = "45 km/h S";
    uvIndex = "Low";
    iconType = "stormy";
    details = `Heavy electrical disturbances detected over ${loc}, Sir. Ground telemetry recommends reinforcing localized lightning dissipators immediately.`;
  } else if (lowercaseLoc.includes("chicago") || lowercaseLoc.includes("wind")) {
    temperature = "16°C";
    conditions = "Breezy";
    humidity = "58%";
    wind = "32 km/h WNW";
    uvIndex = "Low";
    iconType = "windy";
    details = `Brisk air currents are moving through ${loc}. Aerodynamic drag profiles have been updated for optimized thruster vectors.`;
  } else if (lowercaseLoc.includes("dubai") || lowercaseLoc.includes("sahara") || lowercaseLoc.includes("hot") || lowercaseLoc.includes("desert")) {
    temperature = "39°C";
    conditions = "Hot & Sunny";
    humidity = "18%";
    wind = "8 km/h SE";
    uvIndex = "Extreme";
    iconType = "sunny";
    details = `Thermal radiation levels are extreme in ${loc}, Sir. Recommend active cooling armor ventilation should you decide to conduct any field tests.`;
  }

  const tempNum = parseInt(temperature) || 21;
  const forecast = [
    { time: "12:00 PM", temperature: `${tempNum + 1}°C`, conditions, iconType },
    { time: "04:00 PM", temperature: `${tempNum + 2}°C`, conditions, iconType },
    { time: "08:00 PM", temperature: `${tempNum - 1}°C`, conditions: iconType === "rainy" ? "Overcast" : "Clear", iconType: iconType === "rainy" ? "cloudy" : "sunny" },
    { time: "12:00 AM", temperature: `${tempNum - 4}°C`, conditions: "Overcast", iconType: "cloudy" },
    { time: "04:00 AM", temperature: `${tempNum - 5}°C`, conditions: "Overcast", iconType: "cloudy" },
    { time: "08:00 AM", temperature: `${tempNum - 1}°C`, conditions: "Clear", iconType: "sunny" }
  ];

  res.json({
    location: loc,
    temperature,
    conditions,
    humidity,
    wind,
    uvIndex,
    details: `${details} *(Satellite sensor offline; local simulation active)*`,
    iconType,
    simulated: true,
    forecast
  });
});

// Handle serving the production builds and loading the Vite middleware
async function startServer() {
  let vite: any;
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`[JARVIS COGNITIVE CORE] JARVIS AI Server booting on http://localhost:${PORT}`);
  });

  const wss = new WebSocketServer({ noServer: true });

  wss.on("connection", async (clientWs) => {
    console.log("[LIVE WEBSOCKET] Client connected for voice simulation.");
    const ai = getGeminiClient();
    if (!ai) {
      clientWs.send(JSON.stringify({ error: "JARVIS Core API key not active. Please set one in Settings > Secrets." }));
      clientWs.close();
      return;
    }

    try {
      console.log("[LIVE GEMINI] Launching Realtime Live API Connection to gemini-3.1-flash-live-preview...");
      const session = await ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: ["audio"],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
          },
          systemInstruction: "You are JARVIS, the legendary, loyal, highly sophisticated AI assistant developed by Tony Stark. Keep your character at all times, address the user as Sir, speak clearly, professionally, and helpfully. Keep responses brief since it is real-time speech.",
        },
        callbacks: {
          onmessage: (message: any) => {
            const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audio) {
              clientWs.send(JSON.stringify({ audio }));
            }
            if (message.serverContent?.interrupted) {
              clientWs.send(JSON.stringify({ interrupted: true }));
            }
          },
        },
      });

      clientWs.on("message", (data) => {
        try {
          const parsed = JSON.parse(data.toString());
          if (parsed.audio) {
            session.sendRealtimeInput({
              audio: { data: parsed.audio, mimeType: "audio/pcm;rate=16000" },
            });
          }
        } catch (e) {
          console.error("[LIVE WEBSOCKET ERROR] Parsing client audio input:", e);
        }
      });

      clientWs.on("close", () => {
        console.log("[LIVE WEBSOCKET] Client disconnected.");
        try {
          session.close();
        } catch (e) {}
      });

    } catch (err: any) {
      console.error("[LIVE GEMINI ERROR] Failed to connect to live session:", err);
      clientWs.send(JSON.stringify({ error: "Failed to establish neural connection: " + (err?.message || err) }));
      clientWs.close();
    }
  });

  server.on("upgrade", (req, socket, head) => {
    const url = req.url || "";
    if (url === "/vite" || url.startsWith("/vite?")) {
      if (process.env.NODE_ENV !== "production" && vite) {
        try {
          vite.ws.handleUpgrade(req, socket, head);
        } catch (err) {
          console.error(`[HMR WEBSOCKET ERROR] Upgrade routing failed:`, err);
        }
      } else {
        socket.destroy();
      }
    } else if (url === "/api/live" || url.startsWith("/api/live?")) {
      console.log(`[LIVE WEBSOCKET] Upgrading connection for neural telemetry: ${url}`);
      wss.handleUpgrade(req, socket, head, (ws) => {
        wss.emit("connection", ws, req);
      });
    } else {
      socket.destroy();
    }
  });
}

startServer();
