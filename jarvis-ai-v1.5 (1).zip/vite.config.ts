import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      host: "0.0.0.0",
      port: 3000,
      strictPort: true,
      // Automatically switch between ws:// and wss:// based on the APP_URL protocol
      hmr: process.env.DISABLE_HMR === "true" ? false : {
        protocol: process.env.APP_URL?.startsWith("https") ? "wss" : "ws",
        clientPort: process.env.APP_URL?.startsWith("https") ? 443 : 3000,
      },
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === "true" ? null : {},
    },
    css: {
      devSourcemap: false,
    },
    build: {
      sourcemap: false,
    },
  };
});
